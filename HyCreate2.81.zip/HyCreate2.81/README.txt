HyCreate2 by Stanley Bak (stanleybak@gmail.com)

To run the tool you can use the executable jar file HyCreate2.81.jar which should be run from the current directory. You can open a terminal and do "java -jar HyCreate2.81.jar"

Setup:
To create the reachability plot, you need gnuplot installed.

To run display the reachability result you need an image viewer installed. In Options -> HyCreate Options can can put the command name of your image viewer, as well as extra paths (if the executable is not reacahble from your PATH environment variable).

You also need javac and java to be available.

If your model contains nonlinear dynamics, you will need to specify the points where the derivatives are zero for each direction, for method soundness. There is a Matlab script in the doc folder (critical_point_finder_2d.m) which shows how this was done for the Brussellator and the Van Der Pol Oscillator. You can compare the output of matlab to the code in the .hyc files which specify the critical points. There is an option in the GUI (Attempt to detect min/max errors) which will sample hyperrectangles in different places in order to try to detect if you've specified the critical points wrong. You can use this to help debug errors when developing models with nonlinear dynamics.

HyCreate uses mixed face lifting to compute reachable sets. See the doc folder for some additional information on how this works. The representation used is a union of boxes, so it probably won't work for more than 2 or 3 dimensions (unless you disable splitting, in which case you'll get lots of error over long time bounds). Due to these fundumental limitations, I no longer update the tool and instead have been working on better methods (such as those in the Hylaa tool).

If you want to cite this work, please use:

@misc{bak2013hsccposter,
  title={Computing Reachability for Nonlinear Systems with HyCreate},
  author={Bak, Stanley and Caccamo, Marco},
  booktitle={16th International Conference on Hybrid Systems: Computation and Control Poster Session},
  year={2013},
  organization={ACM}
}

-----------------

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

