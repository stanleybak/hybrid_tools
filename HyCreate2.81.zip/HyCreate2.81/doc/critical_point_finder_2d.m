% Critical point finder using Matlab symbolic toolbox
% Stanley Bak

syms x y

% van der pol system
%x_der = y;
%y_der = (1 - x*x)*y-x;

% brussellator system
x_der = 1 + x^2*y-2.5*x;
y_der = 1.5 * x - x^2*y;



% x der
disp('X Derivative critical points')
solve(diff(x_der,x) == 0, x)
solve (diff(x_der,y) == 0, y)

% y der
disp('Y Derivative critical points')
solve(diff(y_der,x) == 0, x)
solve (diff(y_der,y) == 0, y)

% global min/max

disp('Global Min/Max')
S = solve (0 == diff(y_der,x), 0 == diff(y_der,y));
size(S)
S = [S.x, S.y]
