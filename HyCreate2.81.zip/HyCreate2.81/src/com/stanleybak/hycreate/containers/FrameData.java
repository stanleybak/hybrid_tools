package com.stanleybak.hycreate.containers;


import java.awt.Dimension;
import java.awt.Point;
import java.util.ArrayList;

import javax.swing.JFrame;


public class FrameData
{
	private Point location = new Point(0,0);
	private Dimension size = new Dimension(800,600);
	private int extendedState = JFrame.NORMAL;
	private int selectedTab = 0;
	private String latestOpen = null;
	private HyCreateOptions options = new HyCreateOptions();
	
	private ArrayList <String> recentFiles = new ArrayList <String>();
	
	public FrameData()
	{
		
	}
	
	public String getLatestOpen()
	{
		return latestOpen;
	}

	public void setLatestOpen(String latestOpen)
	{
		this.latestOpen = latestOpen;
	}

	public Point getLocation()
	{
		return location;
	}

	public void setLocation(Point location)
	{
		this.location = location;
	}

	public Dimension getSize()
	{
		return size;
	}

	public void setSize(Dimension size)
	{
		this.size = size;
	}

	public int getExtendedState()
	{
		return extendedState;
	}

	public void setExtendedState(int extendedState)
	{
		this.extendedState = extendedState;
	}

	public int getSelectedTab()
	{
		return selectedTab;
	}

	public void setSelectedTab(int selectedTab)
	{
		this.selectedTab = selectedTab;
	}

	public ArrayList<String> getRecentFiles()
	{
		return recentFiles;
	}

	public void setRecentFiles(ArrayList<String> recentFiles)
	{
		this.recentFiles = recentFiles;
	}

	public HyCreateOptions getOptions()
	{
		return options;
	}

	public void setOptions(HyCreateOptions options)
	{
		this.options = options;
	}
}
