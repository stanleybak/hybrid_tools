package compiler;

@SuppressWarnings("serial")
public class CompilationException extends Exception
{

	public CompilationException(String s)
	{
		super(s);
	}

}
