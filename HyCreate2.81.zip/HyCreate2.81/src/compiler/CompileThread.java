package compiler;

import gui.hycreate.HyCreateFrame;
import gui.partial.PartialResultsVisualizer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Map.Entry;

import com.stanleybak.hycreate.containers.HyCreateData;
import com.stanleybak.hycreate.containers.ModeData;
import com.stanleybak.hycreate.containers.ModelPlotOptions;
import com.stanleybak.hycreate.containers.ReachParams;
import com.stanleybak.hycreate.containers.TransitionData;

import main.BatchMode;
import main.FileOperations;
import main.Main;
import main.Util;
import untrusted.UntrustedMain;

public class CompileThread extends Thread
{
	private final static String AUTOMATON_PACKAGE_NAME = "automaton";
	private final static String GENERATE_DIR_NAME = "generate";
	private final static String EXTERNAL_CODE_ENTRY_POINT_CLASS = "main.Main";
	
	private static boolean testedCompiler = false;
	private String baseDirectory; // guaranteed to end with separator
	private final HyCreateData data;
	
	String automatonName;
	String automatonDir;
	String reachabilityTimeString = "Double.MAX_VALUE";
	
	String[] dimensions;
	public HyCreateFrame parent;
	HyCompile compileParent;
	String codeSourcePath; // will end in .jar if jar file, otherwise a directory
	String jarDir;
	LinkedList <String> generatedFiles = new LinkedList <String>();
	boolean doCompile;
	boolean doCompute;
	
	ProcessBuilder builder = new ProcessBuilder();
	
	private Object currentProcessLock = new Object();
	public Process currentProcess = null; // protected by currentProcessLock
	private boolean manuallyStopped = false;
	
	public ReachParams reachParams = null; // assigned once we start doing the computation
	
	public CompileThread(HyCompile compileParent, HyCreateFrame parent, HyCreateData data, 
			boolean doCompile, boolean doCompute)
	{
		this.data = data;
		this.parent = parent;
		this.compileParent = compileParent;
		this.doCompile = doCompile;
		this.doCompute = doCompute;
		
		String path = this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
		try
		{
			codeSourcePath = URLDecoder.decode(path, "UTF-8");
			jarDir = codeSourcePath;
			
			// pop one directory if a generate folder doesn't exist
			String genDir = jarDir + GENERATE_DIR_NAME;
			
			if (!new File(genDir).exists())
			{
				jarDir = new File(jarDir).getParent() + File.separator;
				genDir = jarDir + GENERATE_DIR_NAME;
			}
			
			if (!new File(genDir).exists())
			{
				jarDir = new File(".") + File.separator;
				genDir = jarDir + GENERATE_DIR_NAME;
			}
			
			if (!new File(genDir).exists())
			{
				// give up
				Main.error("Could not locate 'generate' directory.");
			} 
		} 
		catch (UnsupportedEncodingException e)
		{
			Main.error("Problem getting jar directory: " + e);
			jarDir = "." + File.separator;
		}
	}
	
	public void addOutput(final String text)
	{
		parent.addOutput(text);
	}
	
	public void killExternalProcess()
	{
		synchronized (currentProcessLock)
		{
			if (currentProcess != null)
			{
				addOutput("Attempting to kill external process...");
				manuallyStopped = true;
				
				currentProcess.destroy();
			}
			else
				addOutput("No external process running to kill");
		}
	}
	
	public void run()
	{
		if (isInputValid())
		{
			try
			{
				createDirectories();
				
				builder.redirectErrorStream(true);
				
				if (doCompile)
				{
					testCompile();
					
					//create directory tmp/compute_<<AutomatonName>>
					//create directory tmp/compute_<<AutomatonName>>/automaton
					//create directory tmp/compute_<<AutomatonName>>/<<AutomatonName>>/
					//create directories for packages
					makeDirectories();
					
					//create java source files
					createSourceFiles();
	
					// produces .class files from .java files (may need to run on each file)
					compileFiles();
					
					parent.compiledSuccessfully();
					addOutput("");
					addOutput("Compilation task completed successfully.");
				}
				else
				{
					addOutput("");
					addOutput("Model was not modified, skipping compilation.");
				}
	
				if (doCompute)
				{
					String resultDir = makeResultDir();
					String resultPath = resultDir + File.separator + UntrustedMain.RESULT_FILENAME;
					
					reachParams = new ReachParams(parent.options, parent.modelOptions);
					ModelPlotOptions pOptions = parent.modelOptions.getPlotOptions();
					boolean visualizeAfter = pOptions.isVisualizeAfterComputation();
					boolean visualizeDuring = pOptions.isVisualizeDuringComputation();
					
					if (visualizeDuring)
					{
						addOutput("");
						
						PartialResultsVisualizer.begin(this, reachParams);
						addOutput("Partial results visualizer listening on localhost::" + reachParams.visualizerPort);
					}
					
					runReachabilityComputation(resultPath);

					// save reachability result
					if (visualizeAfter)
					{
						GnuPlotVisualizer.visualize(this, resultPath);
					
						addOutput("");
						addOutput("Computation+Visualization task completed successfully.");
					}
					else
					{
						addOutput("Visualization after compilation was disabled in model options.");
						addOutput("Computation task completed successfully.");
					}
				}
			}
			catch (CompilationException e)
			{
				addOutput("ERROR: " + e);
				
				Main.error(e.getMessage());
			}
			catch (Exception e)
			{
				e.printStackTrace();
				
				Main.error("Exception in compilation thread.");
			}
		}
		
		compileParent.finishedComputing();
		parent.finishedCompiling();
	}
	
	/**
	 * Create the directory for the reachability results and plot files,
	 * if it doesn't already exist
	 * @return the path to the result directory
	 * @throws CompilationException if making the directory fails
	 */
	private String makeResultDir() throws CompilationException
	{
		File resultDir = new File(new File(compileParent.openPath).getAbsoluteFile().getParent() 
				+ File.separator + "result");
		
		if (!resultDir.exists())
		{
			if (!resultDir.mkdirs())
				throw new CompilationException("Could not make result directory: " + 
						resultDir.getAbsolutePath());
		}
		
		// clear results from last computation
		for (File f : resultDir.listFiles())
		{
			String name = f.getName();
			if (f.isFile() && name.endsWith(".txt"))
			{
				if (name.startsWith("initial"))
					f.delete();
				else if (name.endsWith(".gnuplot.txt"))
					f.delete();
			}
		}
		
		return resultDir.getAbsolutePath();
	}

	private void createDirectories() throws CompilationException
	{
		baseDirectory = parent.hyCreateTempPath + File.separator;
		
		automatonName = Util.cleanName(data.getAutomatonName());
		automatonDir = baseDirectory + "compute_" + automatonName + File.separator;
	}

	private void testCompile() throws CompilationException
	{
		if (!testedCompiler && BatchMode.runningInBatchMode == false)
		{
			final String CLASS_NAME = "TestCompile";
			
			addOutput("\nTesting Java compiler and Java Runtime Environment (JRE)");
			
			try
			{
				String tmpDir = FileOperations.getTempDirPath("hycreate_test_compile").toString() 
						+ File.separator;
				
				String[] content = 
					{
						"public class " + CLASS_NAME +" {",
						"public static void main(String[] args) { System.exit(0); }",
						"}",
					};
				
				String path = tmpDir + CLASS_NAME + ".java";
				
				BufferedWriter out = new BufferedWriter(new FileWriter(path));
				
				for (String s : content)
					out.write(s);
				
				out.close();
				
				addOutput("Successfully generated '" + path + "'");
				
				// compile it
				String[] commands = new String[2];
				
				int index = 0;
				
				commands[index++] = compileParent.javacPath;
				commands[index++] = path;
				
				runProcess(commands, tmpDir);
				addOutput("Successfully compiled '" + path + "'");
				
				// run it
				commands = new String[2];
				
				index = 0;
				
				commands[index++] = compileParent.javaPath;
				commands[index++] = CLASS_NAME;
				
				runProcess(commands, tmpDir);
				
				addOutput("Successfully ran '" + tmpDir + CLASS_NAME + "'");
				testedCompiler = true; // only run once per session
			}
			catch (IOException e)
			{
				throw new CompilationException("Error while generating test file for javac: " + e);
			}
			catch (CompilationException e)
			{
				throw new CompilationException("Error while compiling/running test file using javac: " + e);
			}
		}
	}

	private boolean isInputValid()
	{
		boolean checksPassed = true;
		
		String[] dims = getCleanDimList();
		
		/////////////////////////////////////////////////////////
		// make sure dimension names are unique
		for (int a = 0; a < dims.length; ++a)
		{
			for (int b = a + 1; b < dims.length; ++b)
			{
				if (dims[a].toLowerCase().equals(dims[b].toLowerCase()))
				{
					checksPassed = false;
					
					String msg = "Dimension names are too similar: " + dims[a] + " and " + dims[b];
					addOutput("Error: " + msg);
					Main.error(msg);
				}
			}
		}
		
		//////////////////////////////////////////////////////
		// make sure reachability time is a number
		
		if (checksPassed)
		{
			reachabilityTimeString = data.getOptions().getReachabilityTime().trim();
							
			if (reachabilityTimeString.length() == 0)
			{
				checksPassed = false;
				String msg = "Time-bound for reachability computation must be provided";
				addOutput("Error: " + msg);
				Main.error(msg);
			}
		}
					
		///////////////////////////////////////////////////////
		// make sure grid size / face size / regrid ratio have the right number of dimensions
		
		if (checksPassed)
		{
			for (Entry<String, ModeData> e : data.getModes().entrySet())
			{
				ModeData md = e.getValue();
				
				String[] names = { "Grid Size", "Regrid Ratio" };
				String[] values = {md.getGridSize(), md.getRegridRatio() };
				
				for (int i = 0; i < names.length; ++i)
				{
					String line = values[i];
					
					if (i == 0 && line.trim().length() == 0) 
						continue; // grid size can be blank
					
					String[] parts = line.split(",");
					
					if (parts.length != dims.length)
					{
						checksPassed = false;
						
						String msg = names[i] + " in mode '" + e.getKey() + "' should have " + dims.length + 
								" parts, but it has " + parts.length + ". Entry:\n" + line;
						addOutput("Error: " + msg);
						Main.error(msg);
						break;
					}
				
					for (String part : parts)
					{
						try
						{
							Double.parseDouble(part.trim());
						}
						catch (NumberFormatException e2)
						{
							checksPassed = false;
							
							String msg = 
							names[i] + " in mode '" + e.getKey() + "' should be a list of numbers. \n" +
							"Problem with entry \"" + part.trim() + "\" in list:\n" + line;
							
							addOutput("Error: " + msg);
							Main.error(msg);
							
							break;
						}
					}
				}
				
				if (checksPassed == false)
					break;
			}
		}
		
		return checksPassed;
	}

	/**
	 * Run the reachability computation
	 * @param resultFilePath the path to the result file
	 * @param visPort the port for the visualizer
	 * @throw CompilationException if the external process runs exits with an error
	 */
	private void runReachabilityComputation(String resultFilePath) throws CompilationException
	{
		addOutput("");
		addOutput("Running reachability computation");
		
		String compileBaseDir = automatonDir;
		String hyCreateDirPath = new File(jarDir).getAbsolutePath();
		
		String[] commands = 
		{
			compileParent.javaPath,
			"-cp",
			codeSourcePath,
			EXTERNAL_CODE_ENTRY_POINT_CLASS,
			Main.RUN_EXTERNAL_PARAM,
			compileBaseDir,
			hyCreateDirPath,
			resultFilePath,
			reachParams.createParamString()
		};
		
		try
		{
			runProcess(commands, automatonDir);
		}
		catch (CompilationException e)
		{
			throw new CompilationException(e.getMessage());
		}
	}

	private void compileFiles() throws CompilationException
	{
		int numFiles = generatedFiles.size();
		
		addOutput("");
		addOutput("Compiling generated java code files (" + numFiles + " files)");
		
		String[] commands = new String[3+numFiles];
		
		int index = 0;
		
		commands[index++] = compileParent.javacPath;
		commands[index++] = "-classpath";
		commands[index++] = getCompileClassPath();
		
		for (String name : generatedFiles)
			commands[index++] = AUTOMATON_PACKAGE_NAME + File.separator + name;
		
		//javac automaton/*.java <other files here>
		try
		{
			runProcess(commands, automatonDir);
		}
		catch (CompilationException e)
		{
			throw new CompilationException("Error compiling generated java code.");
		}
	}
	
	private String getCompileClassPath()
	{
		String path = HyCompile.class.getProtectionDomain().getCodeSource().getLocation().getPath();
		
		return path + File.pathSeparator + ".";
	}

	public void runProcess(String[] command, String workingDir) throws CompilationException
	{
		/*String msg = "Running process (working directory = '" + workingDir + "'): ";
		
		for (String s : command)
			msg += s + " ";
		
		addOutput(msg);*/
		
		if (workingDir != null)
			builder.directory(new File(workingDir));
		else
			builder.directory(null);
		
		builder.command(command);
		
		try
		{
			manuallyStopped = false;
			String errorString = null;
			
			try
			{
				Process p = builder.start();
				
				synchronized (currentProcessLock)
				{
					currentProcess = p;
				}
				
				parent.setExternalProcessRunning(true);
							
				BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
				
				for (String line = in.readLine(); line != null; line = in.readLine())
					addOutput(line);
			}
			catch (IOException e)
			{
				// stream may have been forcefully closed
				if (manuallyStopped)
					errorString = "External process was manually stopped.";
			}
			
			parent.setExternalProcessRunning(false);
			
			int code = currentProcess.waitFor();
			
			synchronized (currentProcessLock)
			{
				currentProcess = null;
			}
			
			if (errorString != null)
			{
				throw new CompilationException(errorString);
			}
			else if (code != 0)
			{
				throw new CompilationException("External Process " + command[0] + 
						" exited with abnormal exit code: " + code);
			}
		}
		catch (InterruptedException e)
		{
			throw new CompilationException("While running external process: " + e);
		}
	}

	private void createSourceFiles() throws CompilationException
	{
		addOutput("");
		String fromDir = getGenerateDir();
		String toDir = automatonDir + AUTOMATON_PACKAGE_NAME + File.separator;
		
		// create initial states file
		String initialText = createInitialStatesCode(data.getInitialStates());
		copyGenerateFile(fromDir + "InitialStates.java.generate", 
				toDir + "InitialStates.java", new String[]{initialText});
		
		// create global values file
		String globalText = data.getGlobalText();
		copyGenerateFile(fromDir + "Global.java.generate", 
				toDir + "Global.java", new String[]{globalText});
		
		// create dimension names file
		dimensions = getCleanDimList();
		
		copyGenerateFile(fromDir + "DimensionNames.java.generate", 
						toDir + "DimensionNames.java", new String[]{makeSeparated(dimensions, ",\n")});
		
		// create automaton file
		String reachTimeStr;
		
		if (!reachabilityTimeString.equals("0"))
			reachTimeStr = reachabilityTimeString;
		else
			reachTimeStr = "Double.MAX_VALUE";
		
		String stepString = data.getOptions().getTimeStep(); // global time step for all modes (for now)
		
		copyGenerateFile(fromDir + "Automaton.java.generate", toDir + "Automaton.java", 
				new String[]{automatonName, getAddModeString(), reachTimeStr, stepString});
		
		createModeFiles(fromDir, toDir);
	
		// for each transition
		createTransitionFiles(fromDir, toDir);
	}

	private String createInitialStatesCode(String enteredText) throws CompilationException
	{
		String rv = "";
		
		try
		{
			BufferedReader r = new BufferedReader(new StringReader(enteredText));
			
			boolean first = true;
			
			for (String line = r.readLine(); line != null; line = r.readLine())
			{
				int commentStart = line.indexOf("#");
				
				if (commentStart != -1)
					line = line.substring(0, commentStart);
				
				line = line.trim();
				
				if (line.length() == 0)
					continue;
				
				if (!first)
					rv += "+ ";
				
				rv += "\"" + line + "\\n\"\n";
				
				first = false;
			}
		
			r.close();
		}
		catch (IOException e)
		{
			throw new CompilationException("Extracting initial states: " + e);
		}
		
		return rv;
	}

	/**
	 * Get the path to the generate directory (including the '/')
	 * @return the path to the generate directory
	 */
	String getGenerateDir()
	{
		String genDir = jarDir + GENERATE_DIR_NAME + File.separator;
		
		if (!new File(genDir).exists())
			genDir = "." + File.separator + GENERATE_DIR_NAME + File.separator;
		
		return genDir;
	}

	private void createTransitionFiles(String fromDir, String toDir) throws CompilationException
	{
		for (int tIndex = 0; tIndex < data.getTransitions().size(); ++tIndex)
		{
			TransitionData tData = data.getTransitions().get(tIndex);
			String from = Util.cleanName(tData.getFrom());
			String to = Util.cleanName(tData.getTo());

			// create transition file
			// gen0 example: 0_off_to_on
			String transitionName = tIndex + "_" + from + "_to_" + to;
			
			copyGenerateFile(fromDir + "Transition.java.generate",
					toDir + "Transition" + transitionName + ".java", 
					new String[]{transitionName, to});
			
			// create guard
			String title = "transition " + transitionName + "'s " + " guard";
			
			String guardStr = tData.getGuard();
			
			copyGenerateFile(fromDir + "Transition_Guard.java.generate",
					toDir + "Transition" + transitionName + "_Guard.java", 
					new String[]{transitionName, replaceDimensions(
							guardStr, title)});
			
			// create reset
			title = "transition " + transitionName + "'s " + " reset";
			copyGenerateFile(fromDir + "Transition_Reset.java.generate",
					toDir + "Transition" + transitionName + "_Reset.java", 
					new String[]{transitionName, replaceDimensions(
							tData.getReset(), title)});
		}
		
	}

	private String makeSeparated(String[] d, String delimiter)
	{
		String rv = "";
		
		for (String s : d)
		{
			rv += s + delimiter;
		}
		
		return rv;
	}

	private void createModeFiles(String fromDir, String toDir) throws CompilationException
	{
		for (Entry<String, ModeData> e : data.getModes().entrySet())
		{
			ModeData d = e.getValue();
			
			// for each mode
			
			// create mode file
			
			String gen0 = Util.cleanName(e.getKey());
			String gen1 = d.getGridSize();
			String gen2 = d.getRegridRatio();
			
			// gen4 is transitions
			String gen3 = "";
			//this.successors.add(new Transition0_off_to_on());
			for (int tIndex = 0; tIndex < data.getTransitions().size(); ++tIndex)
			{
				TransitionData t = data.getTransitions().get(tIndex);
				
				if (t.getFrom().equals(e.getKey()))
				{
					String toClean = Util.cleanName(t.getTo());
					
					gen3 += "\t\tthis.successors.add(new Transition" + tIndex + "_" + 
							gen0 + "_to_" + toClean + "());\n";
				}
			}
			
			// gen5 is derivative bounds
			String gen4 = "";
			//if (dimensionIndex == 0)
			//	rv = Mode_off_Derivative_TEMP.getDerivativeBounds(point);
			for (int dim = 0; dim < dimensions.length; ++dim)
			{
				if (dim == 0)
					gen4 += "\t\t\t";
				else
					gen4 += "\t\t\telse ";
				
				gen4 += "if (dimensionIndex == " + dim + ")\n";
				
				gen4 += "\t\t\t\trv = Mode_" + gen0 + "_Derivative_" + dimensions[dim] 
						+ ".getDerivativeBounds(point);\n";
			}
			
			// gen6 is min max points
			String gen5 = "";
			for (int dim = 0; dim < dimensions.length; ++dim)
			{
				if (dim == 0)
					gen5 += "\t\t\t";
				else
					gen5 += "\t\t\telse ";
				
				gen5 += "if (dimensionIndex == " + dim + ")\n";
				
				gen5 += "\t\t\t\trv = Mode_" + gen0 + "_MinMaxPoints_" + dimensions[dim] 
						+ ".getMinMaxPoints(hr);\n";
			}
			
			copyGenerateFile(fromDir + "Mode.java.generate", 
					toDir + "Mode_" + gen0 + ".java", 
					new String[]{gen0, gen1, gen2, gen3, gen4, gen5});
			
			// create invariant
			String title = "mode " + gen0 + "'s " + " invariant";
			copyGenerateFile(fromDir + "Mode_Invariant.java.generate",
					toDir + "Mode_" + gen0 + "_Invariant.java", 
					new String[]{gen0, replaceDimensions(d.getInvariant(), title)});
			
			// create time trigger
			title = "mode " + gen0 + "'s " + " time trigger";
			copyGenerateFile(fromDir + "Mode_TimeTrigger.java.generate",
					toDir + "Mode_" + gen0 + "_TimeTrigger.java", 
					new String[]{gen0, replaceDimensions(d.getTimeTrigger(), title)});
			
			// for each dimension
			for (int dim = 0; dim < dimensions.length; ++dim)
			{
				String dimName = dimensions[dim];
				
				// create derivative
				title = "mode " + gen0 + "'s " + dimName + " derivative";
				copyGenerateFile(fromDir + "Mode_Derivative.java.generate",
						toDir + "Mode_" + gen0 + "_Derivative_" + dimName + ".java", 
						new String[]{gen0, dimName, replaceDimensions(
								d.getDerivative().get(dim), title)});
				
				
				// create min/max points
				title = "mode " + gen0 + "'s " + dimName + " min max points";
				copyGenerateFile(fromDir + "Mode_MinMaxPoints.java.generate",
						toDir + "Mode_" + gen0 + "_MinMaxPoints_" + dimName + ".java", 
						new String[]{gen0, dimName, replaceDimensions(
								d.getMinMaxPoints().get(dim), title)});
			}
		}
	}

	// replace a string's $DIMNAME constants with the corresponding code
	// title is a text description for error reporting
	private String replaceDimensions(String str, String title) throws CompilationException
	{
		String originalLine = str;
		
		// first replace exact matches, in decreasing order of length
		LinkedList <String> dimensionsDecreasing = new LinkedList <String>(); 
		
		for (String d : dimensions)
			dimensionsDecreasing.add(d);
		
		Collections.sort(dimensionsDecreasing, new DecreasingLengthComparator());
		
		for (String d : dimensionsDecreasing)
			str = str.replace("$" + d, "_input.dims[DimensionNames." + d + ".ordinal()]");
		
		// next replace any matches
		for (int i = 0; i < str.length(); ++i)
		{
			char c = str.charAt(i);
			
			if (c == '$')
			{
				// check if it's one of the dimensions
				String remainingLcase = str.substring(i + 1);
				remainingLcase = remainingLcase.toLowerCase();
				boolean found = false;
				
				for (String d : dimensions)
				{
					if (remainingLcase.startsWith(d.toLowerCase()))
					{
						// this is the match, replace it!
						String replaceString = "_input.dims[DimensionNames." + d + ".ordinal()]";
						int replaceLength = d.length();
						
						str = 	str.substring(0, i) +  // before the cut
								replaceString + 
								str.substring(i + 1 + replaceLength); // after the cut
						found = true;
						
						break;
					}
				}
				
				if (!found)
				{
					String error = 
							"Could not replace a $<<VARIABLE>> in " + title + ".\n" +
							"" +
							"Does a dimension with that name exist? Problem starts with:\n" +
							str.substring(i) + "\n\nIn entry:\n" + originalLine;
					
					throw new CompilationException(error);
				}
			}
		}
		
		return str;
	}

	private String getAddModeString()
	{
		String rv = "";
		
		// modes.add(new Mode_off(this));
		for (String s : data.getModes().keySet())
		{
			String cleanModeName = Util.cleanName(s);
			
			rv += "\t\tmodes.add(new Mode_" + cleanModeName + "(this));\n";
		}
			
		return rv;
	}

	/**
	 * Copy a file, but replacing "#GENERATE<NUM>#" in the file with a specified string
	 * @param from the origin filename
	 * @param to the destination filename
	 * @param replaceString array of replacement strings, first one will replace #GENERATE0#
	 */
	void copyGenerateFile(String from, String to,	String[] replaceString) throws CompilationException
	{
		String filename = new File(to).getName();
		addOutput("Generating file '" + filename + "'");
		
		File inputFile = new File(from);
		File outputFile = new File(to);
	
		try
		{
			BufferedReader in = new BufferedReader(new FileReader(inputFile));
			BufferedWriter out = new BufferedWriter(new FileWriter(outputFile));
			boolean[] replaced = new boolean[replaceString.length];

			for (String line = in.readLine(); line != null; line = in.readLine())
			{
				for (int g = 0; g < replaceString.length; ++g)
				{
					String generateString = "#GENERATE" + g + "#";
					
					if (line.contains(generateString))
					{
						line = line.replace(generateString, replaceString[g]);
						
						replaced[g] = true;
					}
				}
				
				if (line.contains("#GENERATE"))
				{
					in.close();
					out.close();
					
					throw new CompilationException("No replacement given for line: " + line);
				}
				
				out.write(line + "\n");
			}
			
			in.close();
			out.close();

			for (int g = 0; g < replaced.length; ++g)
			{
				if (!replaced[g])
					throw new CompilationException("copyGenerateFile(" + filename 
							+ ") did not encounter #GENERATE" + g + "#");
			}
			
			// update last modified
			outputFile.setLastModified(inputFile.lastModified());
			
			generatedFiles.add(filename);
		}
		catch (IOException e)
		{
			throw new CompilationException(e.toString());
		}
	}

	private String[] getCleanDimList()
	{
		String[] dims = data.getDimensions().split(",");
		
		for (int i = 0; i < dims.length; ++i)
			dims[i] = Util.cleanName(dims[i].trim());
		
		return dims;
	}

	private void makeDirectories() throws CompilationException
	{
		addOutput("");
		//baseDirectory
		
		//create directory compute_<<AutomatonName>>
		addOutput("Creating base directory: " + automatonDir);
		
		File f = new File(automatonDir);
		if (!f.isDirectory() && !f.mkdir())
			throw new CompilationException("mkdir failed for " + f.getAbsolutePath());
		
		
		//create directory compute_<<AutomatonName>>/automaton
		
		addOutput("Creating directory: " + AUTOMATON_PACKAGE_NAME);
		f = new File(automatonDir + AUTOMATON_PACKAGE_NAME);
		
		if (!f.isDirectory() && !f.mkdir())
			throw new CompilationException("mkdir failed for " + f.getAbsolutePath());
	}

}