package compiler;

import java.util.Comparator;

public class DecreasingLengthComparator implements Comparator<String> {

	@Override
	public int compare(String left, String right) 
	{
		int rv = 0;
		
		if (left.length() > right.length())
			rv = -1;
		else if (left.length() < right.length())
			rv = 1;
		
		return rv;
	}

}
