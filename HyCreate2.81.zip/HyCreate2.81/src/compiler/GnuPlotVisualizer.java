package compiler;

import java.io.File;

import com.stanleybak.hycreate.containers.ModelPlotOptions;
import com.stanleybak.hycreate.containers.ModelSimulationOptions.SimulationType;

import main.BatchMode;
import main.Util;
import reachability.compute.Simulator;

public class GnuPlotVisualizer
{
	private static final String PLOT_FILENAME = "showReach.gnuplot";
	private static final char[] extraAllowed = 
	{
		'!','@','#','$','%','^','&','*','(',')','-','+','=',' ',
		'+',',','.','<','>','~','/',':',';','[',']','{','}','|'
	};
	
	/**
	 * Visualize the reachability result
	 * @param parent the parent HyCompile instance, used to print output and generate plot file
	 * @param outputPath the path to the output.hrm file
	 * @throws CompilationException if an IO error occurs, or external process error occurs
	 */
	public static void visualize(CompileThread parent, String outputHrmPath) 
			throws CompilationException
	{
		parent.addOutput("Creating Gnuplot Plot File...");
		String directory = new File(outputHrmPath).getAbsoluteFile().getParent();
		String gnuplotFilePath = createGnuplotFiles(parent, directory);
		parent.addOutput("Created Gnuplot Plot File at: " + gnuplotFilePath);
		
		// run gnuplot on the file
		if (parent.compileParent.gnuplotPath == null)
			parent.addOutput("Gnuplot executable not found, skipping visualization.");
		else
		{
			parent.addOutput("Running Gnuplot to Create Image...");
			runProgramOnFile(parent, 
					new String[]{parent.compileParent.gnuplotPath}, gnuplotFilePath);
			String imagePath = new File(gnuplotFilePath).getParent() + File.separator +
					"reachability.png";
			parent.addOutput("Created Image at " + imagePath);
			
			if (BatchMode.runningInBatchMode)
				parent.addOutput("Running in batch mode, skipping visualization.");
			else if (parent.compileParent.viewerPath == null)
				parent.addOutput("Image viewer executable not found, skipping visualization.");
			else
			{
				String imageViewerName = new File(parent.compileParent.viewerPath[0]).getName();
				
				parent.addOutput("Running External Image Viewer (" + imageViewerName + ")...");
				runProgramOnFile(parent, parent.compileParent.viewerPath, imagePath);
				parent.addOutput("Image viewer exited normally");
			}
		}
	}
	
	/**
	 * Run an executable with a single param
	 * @param parent the compile thread generating the visualization
	 * @param execPath the path to the executable
	 * @param filePath the argument to the executable, a path to a file
	 * @throws CompilationException if error occurs while running the external process
	 */
	private static void runProgramOnFile(CompileThread parent, String execPath[], String filePath)
			throws CompilationException
	{
		String fileDir = new File(filePath).getAbsoluteFile().getParent();
		String[] commands = new String[execPath.length + 1];
		
		int index = 0;
		
		for (int i = 0; i < execPath.length; ++i)
			commands[index++] = execPath[i];
		
		commands[index++] = filePath;
		
		parent.runProcess(commands, fileDir);
	}

	/**
	 * Create the .gnuplot file
	 * @param parent the compile thread (axis names and such taken from here)
	 * @param outDir the directory where to create the file
	 * @return the path to the generated file
	 * @throws CompilationException if file error occurs
	 */
	private static String createGnuplotFiles(CompileThread parent, String outDir) 
			throws CompilationException
	{
		String rv = null;
		String plotContent = "plot ";
		
		ModelPlotOptions pOptions = parent.compileParent.data.getOptions().getPlotOptions();
		
		String plotColors = pOptions.getPlotModeColors();
		String allDimensions = parent.compileParent.data.getDimensions();
		String[] dimensions = allDimensions.split(",");
		
		int xDim = pOptions.getPlotXDimensionIndex();
		int yDim = pOptions.getPlotYDimensionIndex();
		
		// make sure dimension is in bounds
		if (xDim < 0 || xDim >= dimensions.length)
			xDim = 0;
		
		if (yDim < 0 || yDim >= dimensions.length)
			yDim = dimensions.length - 1;
		
		int modeIndex = 0;
		String colors[] = plotColors.split(",");
		
		if (parent.reachParams.simulationType != SimulationType.SIMULATION_ONLY)
		{
			for (String m : parent.compileParent.data.getModes().keySet())
			{
				String modeName = Util.cleanName(m);
				String color = Util.cleanName(colors[modeIndex % colors.length], extraAllowed);
				
				if (plotContent.contains("\n"))
					plotContent += ",";
				
				plotContent += "\\\n";
				
				plotContent += "   1/0 lw 4 lc rgb '" + color + "' with lines t '" + makePretty(modeName) + "', \\\n";
				plotContent += "   '" + modeName + ".gnuplot.txt' with points " +
						"lc rgb '" + color + "' pt 0 notitle";
				
				modeIndex++;
			}
		}
		
		// add simulation if wanted
		if (parent.reachParams.simulationType != SimulationType.REACHABILITY_ONLY)
		{
			String color = Util.cleanName(colors[parent.compileParent.data.getModes().size() % colors.length], 
					extraAllowed);
			
			if (parent.reachParams.simulationType != SimulationType.SIMULATION_ONLY)
				plotContent += ", \\\n";
			
			plotContent += "   '" + Simulator.SIMULATION_FILENAME + 
							"' using 1:2 with lines lw 2 lc rgb '" + color + "' t 'Simulation'";
		}
		
		// create plot file
		String xLabelUnsanitized = pOptions.getxAxisLabel().trim();
		
		if (xLabelUnsanitized.length() == 0)
			xLabelUnsanitized =  makePretty(dimensions[xDim]);
		
		String xLabel = Util.cleanName(xLabelUnsanitized, extraAllowed);
		
		String yLabelUnsanitized = pOptions.getyAxisLabel().trim();
		
		if (yLabelUnsanitized.length() == 0)
			yLabelUnsanitized =  makePretty(dimensions[yDim]);
		
		String yLabel = Util.cleanName(yLabelUnsanitized, extraAllowed);
		
		String titleUnsanitized = pOptions.getPlotTitle().trim();
		
		if (titleUnsanitized.length() == 0)
			titleUnsanitized =  makePretty(parent.compileParent.data.getAutomatonName());
		
		String graphTitle = Util.cleanName(titleUnsanitized, extraAllowed);
		
		String genPlotFilename = PLOT_FILENAME + ".generate";
		String genDir = parent.getGenerateDir();
		
		String outPath = outDir + File.separator + PLOT_FILENAME;
		String fromPath = genDir + genPlotFilename;
		
		String gen0 = graphTitle;
		String gen1 = xLabel;
		String gen2 = yLabel;
		String gen3 = plotContent;
		String gen4 = parent.reachParams.visualizeWidth + ", " + parent.reachParams.visualizeHeight;
		
		parent.copyGenerateFile(fromPath, outPath,	
				new String[] {  gen0, gen1, gen2, gen3, gen4 });
		
		rv = outPath;
		
		return rv;
	}

	/**
	 * Trim spaces, remove underscores and capitalize first letters.
	 * @param str the string to make pretty
	 * @return the pretty string
	 */
	private static String makePretty(String str)
	{
		String rv = "";
		
		str = str.trim();
		str = str.replace("_", " ");
		
		boolean nextCap = true;
		
		for (int i = 0; i < str.length(); ++i)
		{
			char c = str.charAt(i);
			
			if (nextCap)
				c = Character.toUpperCase(c); 

			rv += c;
			
			if (c == ' ')
				nextCap = true;
			else
				nextCap = false;
		}
		
		return rv;
	}

}
