package compiler;

import gui.hycreate.HyCreateFrame;

import java.io.FileNotFoundException;

import com.stanleybak.hycreate.containers.HyCreateData;

import main.FileOperations;
import main.Main;

public class HyCompile
{
	final HyCreateData data;
	String openPath;
	
	// indicates whether compile thread is running (or will run), or it has already existed
	public boolean compileComputeThreadRunning = false;
	
	// these are valid after compile is called once
	public String javacPath = null;
	public String javaPath = null;
	public String gnuplotPath = null;
	public String[] viewerPath = null;

	private final HyCreateFrame parent;
	
	private CompileThread compileThread = null;
	
	public HyCompile(HyCreateFrame parent, HyCreateData data, String openPath)
	{
		this.parent = parent;
		
		// probably should do a deep copy here, in case they change
		// the automaton while the computation is in progress
		// skip this for now, not worth the programming time
		this.data = data; 
		this.openPath = openPath;
	}
	
	public void kill()
	{
		if (compileThread != null)
			compileThread.killExternalProcess();
	}

	public void begin(boolean doCompile, boolean doCompute)
	{
		parent.clearOutput();
		
		if (loadPaths(doCompute))
		{
			compileThread = new CompileThread(this, parent, data, doCompile, doCompute);
			
			compileComputeThreadRunning = true;
			
			compileThread.start();
		}
		else 
			parent.finishedCompiling();
	}

	private boolean loadPaths(boolean visualizeAfter)
	{
		boolean foundAll = false;
		String extraPath = parent.options.getExtraPath();
		
		addOutput("Looking for executables on system...");
		
		try
		{
			javacPath = FileOperations.locate("javac", "Java Compiler (javac)", extraPath)[0];
			javaPath = FileOperations.locate("java", "Java Executable (java)", extraPath)[0];
			
			if (visualizeAfter)
			{
				try
				{
					gnuplotPath = FileOperations.locate("gnuplot", "gnuplot", extraPath)[0];
				}
				catch (FileNotFoundException e)
				{
					String text = "WARNING: Gnuplot not found! Please add the gnuplot executable" + 
						" to your PATH environment variable or\n" +
						"add its directory to Options->HyCreate Options->Extra Search Directories.";
					
					addOutput(text);
				}
				
				String allImageViewers = parent.options.getPngViewer();
				
				for (String viewer : allImageViewers.split(","))
				{
					viewer = viewer.trim();
					
					if (viewer.length() == 0)
						continue;
					
					try
					{
						viewerPath = FileOperations.locate(viewer, viewer, extraPath);
					}
					catch (FileNotFoundException e)
					{
						continue;
					}
					
					// viewer found, break
					break;
				}
				
				if (viewerPath == null)
				{
					addOutput("WARNING: .PNG image viewer not found (searched for '" 
								+ allImageViewers +"').");
					addOutput("Please set Options->HyCreate Options->.PNG Image Viewer Executable");
				}
				
			}
			
			
			foundAll = true;
		}
		catch (FileNotFoundException e)
		{
			if (javacPath == null) // javac gets a special error since I guess it will be more common
				Main.error(
					"Could not find a Java compiler (javac) in the directories given\n"+
					"by your PATH environment variable.\n\n" +
					"Do you have a Java compiler installed?\n\n" + e.toString());
			else
				Main.error(e.toString());
		}
		
		return foundAll;
	}

	void addOutput(final String text)
	{
		parent.addOutput(text);
	}

	public void finishedComputing()
	{
		compileComputeThreadRunning = false;
	}
}
