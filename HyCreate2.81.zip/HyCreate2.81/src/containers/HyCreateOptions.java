package containers;


import java.io.File;


/**
 * Saveable Options specific to this installation of HyCreate
 * @author Stanley Bak
 *
 */
public class HyCreateOptions implements GenericOptions
{
	private boolean useSandbox = true;
	
	private String extraPath = "";
	private String pngViewer = "mspaint,eog";
	private String codeEditor = "notepad,gedit -s"; 
	
	private static final String USE_SANDBOX_LABEL = 
			"Run Untrusted Code in Security Sandbox";
	
	private static final String PNG_VIEWER_LABEL = 
			".PNG Image Viewer Executable";
	
	private static final String CODE_EDITOR_LABEL = 
			"External Code Editor";
	
	private static final String EXTRA_PATH_LABEL = 
			"Extra Search Directories ('" + File.pathSeparator + "' separated)";
	
	private static final String USE_SANDBOX_HELP = 
			"Code entered by the user or loaded from .hyc2 files, by default, runs with\n" +
			"restricted privilages. Disabling this will allow the code to do anything\n" +
			"it wants. If the code is malicious, for example, it may delete your\n" +
			"entire harddrive. Only disable this if you have a strong reason.\n";
	
	private static final String PNG_VIEWER_HELP = 
			"HyCreate will use a .png image viewer to display the output of gnuplot.\n" +
			"Here, you can specify the executable name of the image viewer to use.\n" +
			"The list is comma separated list of executables to look for.";
	
	private static final String CODE_EDITOR_HELP = 
			"This is the program to run when an external editor is invoked for editing code.";
	
	private static final String EXTRA_PATH_HELP = 
			"HyCreate relies on various external tools such as java, javac, and gnuplot.\n" +
			"By default, your PATH environment variable is searched for the execurables.\n" +
			"You can use this option to add other directories to be searched before your PATH.\n";
	
	public String guiTitle()
	{
		return "HyCreate Options";
	}
	
	public HyCreateOptions()
	{
		
	}
	
	public String getExtraPath()
	{
		return extraPath;
	}
	
	public String getExtraPathLabel()
	{
		return EXTRA_PATH_LABEL;
	}
	
	public String getExtraPathHelp()
	{
		return EXTRA_PATH_HELP;
	}

	public void setExtraPath(String extraPath)
	{
		this.extraPath = extraPath;
	}

	public String getPngViewer()
	{
		return pngViewer;
	}
	
	public String getPngViewerLabel()
	{
		return PNG_VIEWER_LABEL;
	}
	
	public String getPngViewerHelp()
	{
		return PNG_VIEWER_HELP;
	}

	public void setPngViewer(String pngViewer)
	{
		this.pngViewer = pngViewer;
	}
	
	public String getCodeEditor()
	{
		return codeEditor;
	}

	public void setCodeEditor(String codeEditor)
	{
		this.codeEditor = codeEditor;
	}
	
	public String getCodeEditorLabel()
	{
		return CODE_EDITOR_LABEL;
	}
	
	public String getCodeEditorHelp()
	{
		return CODE_EDITOR_HELP;
	}
	
	public boolean isUseSandbox()
	{
		return useSandbox;
	}
	
	public String getUseSandboxLabel()
	{
		return USE_SANDBOX_LABEL;
	}
	
	public String getUseSandboxHelp()
	{
		return USE_SANDBOX_HELP;
	}

	public void setUseSandbox(boolean useSandbox)
	{
		this.useSandbox = useSandbox;
	}

	
}
