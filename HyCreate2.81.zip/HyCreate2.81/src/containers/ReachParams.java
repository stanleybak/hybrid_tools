package containers;

import containers.ModelOptions.AggregationMethod;
import containers.ModelOptions.ReachabilityMethod;
import containers.ModelSimulationOptions.EnumDerivativesType;
import containers.ModelSimulationOptions.SimulationType;
import containers.ModelSimulationOptions.StartingPositionsType;


/**
 * Container for parameters related to the reachability computation
 * @author Stanley Bak
 *
 */
public class ReachParams
{
	public boolean useSandbox = true;
	public boolean detectMinMaxErrors = false;
	public boolean saveInitialStates = false;
	public boolean saveReachSet = false;
	public boolean saveVisualization = true;
	public int visualizeWidth = 100;
	public int visualizeHeight = 100;
	public int visualizeXDim = -1;
	public int visualizeYDim = -1;
	private String plotRange = "-1, 1; -1, 1";
	public double bloatFactor;
	public boolean usePseudoInvariant = true;
	public int visualizerPort = 0;
	public int maxRectangles = 500;
	
	// for simulation
	public String simulationStep = "auto";
	public SimulationType simulationType;
	public EnumDerivativesType enumerateDerivatives;
	public StartingPositionsType startingPositions;
	public boolean enumerateTransitions = false;
	public int maxJumps = 10000;
	
	public AggregationMethod aggregationMethod;
	public ReachabilityMethod reachMethod;
	
	public boolean splitLargeRectangles = true;
	
	/**
	 * Create a new params object from the container java beans
	 * @param hOptions the HyCreate options being used
	 * @param mOptions the model options being used
	 */
	public ReachParams(HyCreateOptions hOptions, ModelOptions mOptions)
	{
		this.useSandbox = hOptions.isUseSandbox();
		this.detectMinMaxErrors = mOptions.isDetectMinMaxErrors();
		this.aggregationMethod = mOptions.getSuccessorAggregationMethod();
		this.reachMethod = mOptions.getReachabilityMethod();
		
		ModelPlotOptions pOptions = mOptions.getPlotOptions();
		
		saveReachSet = mOptions.isSaveReachableFile();
		saveVisualization = pOptions.isVisualizeAfterComputation() || pOptions.isVisualizeDuringComputation();
		saveInitialStates = mOptions.isSaveInitialStates();
		
		visualizeWidth = pOptions.getPlotWidth();
		visualizeHeight = pOptions.getPlotHeight();
		
		visualizeXDim = pOptions.getPlotXDimensionIndex();
		visualizeYDim = pOptions.getPlotYDimensionIndex();
		
		plotRange = pOptions.getPlotRange();
		bloatFactor = pOptions.getPlotBloatFactor();
		
		ModelSimulationOptions sOptions = mOptions.getSimulationOptions();
		simulationType = sOptions.getSimulationType();
		simulationStep = sOptions.getSimulationStep();
		enumerateDerivatives = sOptions.getEnumerateDerivatives();
		startingPositions = sOptions.getStartingPositions();
		enumerateTransitions = sOptions.isEnumerateTransitions();
		maxJumps = sOptions.getMaxDiscreteTransitions();
		
		splitLargeRectangles = mOptions.isSplitLargeRectangles();
		usePseudoInvariant = mOptions.isUsePseudoInvariants();
		maxRectangles = mOptions.getMaxRectangles();
	}
	
	/**
	 * Reconstruct the ReachParams from a string created using createParamString
	 * @param paramString the output get createParamString
	 */
	public ReachParams(String paramString)
	{
		String[] parts = paramString.split(",");
		
		if (parts.length != 23)
			throw new RuntimeException("ParamString parts count(" + parts.length + ") incorrect");
		
		int index = 0;
		
		useSandbox = 				"1".equals(parts[index++]);
		detectMinMaxErrors = 		"1".equals(parts[index++]);
		saveReachSet = 				"1".equals(parts[index++]);
		saveVisualization = "1".equals(parts[index++]);
		visualizeWidth = 			Integer.parseInt(parts[index++]);
		visualizeHeight = 			Integer.parseInt(parts[index++]);
		visualizeXDim = 			Integer.parseInt(parts[index++]);
		visualizeYDim = 			Integer.parseInt(parts[index++]);
		visualizerPort =			Integer.parseInt(parts[index++]);
		plotRange = parsePlotRange(parts[index++]);
		splitLargeRectangles = "1".equals(parts[index++]);
		maxRectangles = Integer.parseInt(parts[index++]);
		
		usePseudoInvariant = "1".equals(parts[index++]);
		
		simulationType = SimulationType.values()[Integer.parseInt(parts[index++])];
		simulationStep = parts[index++];
		enumerateDerivatives = EnumDerivativesType.values()[Integer.parseInt(parts[index++])]; 
		startingPositions = StartingPositionsType.values()[Integer.parseInt(parts[index++])];
		enumerateTransitions = "1".equals(parts[index++]);
		
		saveInitialStates = "1".equals(parts[index++]);
		
		aggregationMethod = AggregationMethod.values()[Integer.parseInt(parts[index++])];
		reachMethod = ReachabilityMethod.values()[Integer.parseInt(parts[index++])];
		
		maxJumps = Integer.parseInt(parts[index++]);
		
		bloatFactor = Double.parseDouble(parts[index++]);
		
		
		/// error check
		
		if (visualizeWidth < ModelPlotOptions.PLOT_SIZE_MIN)
			visualizeWidth = ModelPlotOptions.PLOT_SIZE_MIN;
		
		else if (visualizeWidth > ModelPlotOptions.PLOT_SIZE_MAX)
			visualizeWidth = ModelPlotOptions.PLOT_SIZE_MAX;
		
		if (visualizeHeight < ModelPlotOptions.PLOT_SIZE_MIN)
			visualizeHeight = ModelPlotOptions.PLOT_SIZE_MIN;
		
		else if (visualizeHeight > ModelPlotOptions.PLOT_SIZE_MAX)
			visualizeHeight = ModelPlotOptions.PLOT_SIZE_MAX;
	}

	/**
	 * Parse a plot range that was created with createParsablePlotRange. This returns the
	 * original String
	 * @param paramString the string output by createParsablePlotRange
	 * @return the string that was passed into createParsablePlotRange
	 */
	public String parsePlotRange(String paramString)
	{
		String rv = paramString.replace('`', ','); // backticks replaced with commas
		
		return rv;
	}
	
	/**
	 * Extract the plot range from the plotRange class variable. Parse errors printed to 
	 * System.out
	 * @return four values, the min/max in the x direction, and the min/max in the y direction
	 */
	public double[] getPlotRange()
	{
		double [] rv = null;
		boolean error = false;
		
		if (plotRange.trim().length() > 0)
		{
			try
			{
				String[] parts = plotRange.split(";");
				
				if (parts.length != 2)
					throw new NumberFormatException("Exactly one semicolon (';') is expected");
				
				String[] xParts = parts[0].split(",");
				
				if (xParts.length != 2)
					throw new NumberFormatException("Exactly one comma (',') is expected in x range: '" +
							parts[0] + "'");
				
				String[] yParts = parts[1].split(",");
				
				if (yParts.length != 2)
					throw new NumberFormatException("Exactly one comma (',') is expected in y range: '" + 
								parts[1] + "'");
				
				double xMin = Double.parseDouble(xParts[0]);
				double xMax = Double.parseDouble(xParts[1]);
				double yMin = Double.parseDouble(yParts[0]);
				double yMax = Double.parseDouble(yParts[1]);
				
				rv = new double[]{xMin, xMax, yMin, yMax};
			}
			catch (NumberFormatException e)
			{
				System.out.println("Error parsing Model Options -> Plot Range. Was it of the form " +
						"'x_min, x_max; y_min, y_max' ?");
				System.out.println("Exception was: " + e);
				error = true;
			}
			
			if (rv[1] < rv[0])
			{
				System.out.println("Model Options -> Plot Range x_max was less than x_min.");
				error = true;
			}
			
			if (rv[3] < rv[2])
			{
				System.out.println("Model Options -> Plot Range y_max was less than y_min.");
				error = true;
			}
			
			if (error)
			{
				System.out.println("Malformed plot range was: '" + plotRange + "'");
				System.out.println("Using simulation-determined range instead.");
				
				rv = null;
			}
		}
		
		return rv;
	}
	
	/**
	 * Create a parseable plot range from the plotRange class variable
	 * @return a string without commas which can be parsed using parsePlotRange
	 */
	public String createParsablePlotRange()
	{
		String rv = plotRange;
		
		// don't allow backticks in the string. Permanently replace them with underscores
		rv.replace('`', '_');
		
		rv = rv.replace(',', '`'); // commas replaced with back ticks
		
		return rv;
	}

	/**
	 * Create a parameter string based on the values in this container
	 * @return a string which can be used as a parameter when spawning a process which
	 *         describes the reach parameters
	 */
	public String createParamString()
	{
		String rv = "";
		
		boolean[] bools = 
		{
			useSandbox, detectMinMaxErrors,
			saveReachSet, saveVisualization
		};

		// append all the booleans
		for (boolean b : bools)
			rv += (b ? "1" : "0") + ",";
		
		// append the visualization size
		rv += visualizeWidth + ",";
		rv += visualizeHeight + ",";
		
		// append the x and y dimension index
		rv += visualizeXDim + ",";
		rv += visualizeYDim + ",";
		
		rv += visualizerPort + ",";
		
		rv += createParsablePlotRange() + ",";
		
		rv += (splitLargeRectangles ? "1" : "0") + ",";
		rv += maxRectangles + ",";
		
		rv += (usePseudoInvariant ? "1" : "0") + ","; 
		
		rv += simulationType.ordinal() + ",";
		rv += simulationStep + ",";
		
		rv += enumerateDerivatives.ordinal() + ",";
		rv += startingPositions.ordinal() + ",";
		rv += (enumerateTransitions ? "1" : "0") + ",";
		

		rv += (saveInitialStates ? "1" : "0") + ",";
		rv += aggregationMethod.ordinal() + ",";
		rv += reachMethod.ordinal() + ",";
		rv += maxJumps + ",";
		rv += bloatFactor;
		
		return rv;
	}

}
