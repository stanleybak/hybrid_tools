package gui.hycreate;

public interface DimNamesChangedListener
{
	public void dimensionNamesChanged(String[] names);
}
