package gui.hycreate;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import main.FileOperations;

@SuppressWarnings("serial")
public class ExternalEditorPane extends JDialog implements ActionListener
{
	private String tempFilePath;
	
	private StringBuffer outputText = new StringBuffer();
	private JTextArea outputArea;
	
	private ExternalEditorThread eet;

	private ExternalEditorPane(HyCreateFrame parent, String editorPath[], String codeText) throws IOException
	{
		super(parent.frame, true);
		setTitle("Editing in External Process");
		setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
		
		setLayout(new BorderLayout());
		JLabel l = new JLabel("<html><b>When you are finished editing, " + 
				"save the file and close the editor.</b></html>");
		JPanel p = new JPanel();
		p.setLayout(new FlowLayout());
		p.add(l);
		p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		add(p, BorderLayout.PAGE_START);
		
		outputArea = new JTextArea();
		outputArea.setEditable(false);
		
		// arg, this seems harder than it needs to be
		outputArea.setEnabled(false);
		Color trColor = outputArea.getBackground();
		outputArea.setEnabled(true);
		
		// setBackground doesn't seem to react to textResource colors
		Color color = new Color(trColor.getRed(), trColor.getGreen(), trColor.getBlue());
		outputArea.setBackground(color);
		
		outputArea.setText(" ");
		outputArea.setPreferredSize(new Dimension(500, 300));
		
		JScrollPane sp = new JScrollPane(outputArea);
		sp.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
		
		add(sp, BorderLayout.CENTER);
		
		JButton b = new JButton("Kill External Process and Cancel Changes");
		p = new JPanel();
		p.setLayout(new FlowLayout());
		p.add(b);
		p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		add(p, BorderLayout.PAGE_END);
		b.addActionListener(this);
		
		pack();
		
		// start up external editor
		tempFilePath = writeCodeToTempFile(codeText);
		eet = new ExternalEditorThread(this, editorPath, tempFilePath);
		eet.start();
	}

	/**
	 * Run the external editor and return new code text. Returns null if canceled
	 * @param parent
	 * @param codeText
	 * @return
	 */
	public static String showExternalEditor(HyCreateFrame parent, String codeText)
	{
		String rv = null;
		String[] path = getExternalEditorPath(parent);
		
		if (path == null)
		{
			JOptionPane.showMessageDialog(parent.frame, "Could not find external code editor.\n" +
					"Please set the path and binary name in Options->HyCreate Options."
					, "External Code Editor Error", JOptionPane.ERROR_MESSAGE);
		}
		else
		{
			try
			{
				ExternalEditorPane e = new ExternalEditorPane(parent, path, codeText);
				
				e.setVisible(true);
				
				if (e.eet.exitedGracefully)
					rv = e.getSavedCodeText();
			}
			catch (IOException error) 
			{
				JOptionPane.showMessageDialog(parent.frame, "File error while saving/loading code text:\n" + error
						, "File Error", JOptionPane.ERROR_MESSAGE);
				
				rv = null;
			}
		}
		
		return rv;
	}
	
	/**
	 * Write code text to a temporary file and return that file's path
	 * @param codeText
	 * @return
	 */
	private String writeCodeToTempFile(String codeText) throws IOException
	{
		String path = makeTempPath("code.java");
		
		BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path), "UTF-8"));
		
		out.write(codeText);
		out.close();
		
		return path;
	}

	/**
	 * Return a path to a temporary location (doesn't create the file)
	 * @param filename the name of the file to use
	 * @return a path that ends in filename to a temporary location
	 */
	private String makeTempPath(String filename)
	{
		String tmpDir = FileOperations.getTempDirPath("hycreate_external").toString() 
				+ File.separator;
		
		return tmpDir + filename;
	}

	private String getSavedCodeText() throws IOException
	{
		StringBuffer content = new StringBuffer();
		
		BufferedInputStream bis = new BufferedInputStream(new FileInputStream(tempFilePath));
		
		for (int ch = bis.read(); ch != -1; ch = bis.read())
			content.append((char)ch);
			
		bis.close();
		
		return content.toString();
	}

	private synchronized void addOutput(String line)
	{
		if (outputText.length() > 0)
			outputText.append("\n");
		
		int carrotPos = outputText.length();
		
		if (line.length() > 0)
			carrotPos += 1;
		
		final int setCarrotPos = carrotPos;
		
		outputText.append(line);
		
		SwingUtilities.invokeLater(new Runnable(){
			public void run()
			{
				outputArea.setText(outputText.toString());
				outputArea.setCaretPosition(setCarrotPos);
			}
		});
	}
	
	/**
	 * Gets the path to the external code editor, or null
	 * @return
	 */
	private static String[] getExternalEditorPath(HyCreateFrame parent)
	{
		String rv[] = null;
		String all = parent.options.getCodeEditor();
		
		for (String editor : all.split(","))
		{
			editor = editor.trim();
			
			if (editor.length() == 0)
				continue;
			
			try
			{
				rv = FileOperations.locate(editor, "Code Editor", parent.options.getExtraPath());
			}
			catch (FileNotFoundException e)
			{
				continue;
			}
			
			// viewer found, break
			break;
		}
		
		return rv;
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		// cancel and kill was pressed
		eet.kill();
	}
	
	private class ExternalEditorThread extends Thread
	{
		private boolean killed = false;
		private Process currentProcess = null;
		private String[] binaryPath = null;
		private String codePath = null;
		public boolean exitedGracefully = false;
		private ExternalEditorPane pane;
		
		public ExternalEditorThread(ExternalEditorPane pane, String binaryPath[], String codePath)
		{
			this.pane = pane;
			this.binaryPath = binaryPath;
			this.codePath = codePath;
		}
		
		@Override
		public void run()
		{
			ProcessBuilder builder = new ProcessBuilder();
			
			builder.redirectErrorStream(true);
			builder.directory(null);
			
			String[] command = new String[binaryPath.length + 1];
			int index = 0;		
			
			for (int i = 0; i < binaryPath.length; ++i)
				command[index++] = binaryPath[i];
				
			command[index++] = codePath;
			builder.command(command);
			
			addOutput("Starting process: " + prettyString(binaryPath));
			
			try
			{
				currentProcess = builder.start();
									
				BufferedReader in = new BufferedReader(new InputStreamReader(currentProcess.getInputStream()));
			
				for (String line = in.readLine(); line != null; line = in.readLine())
					addOutput(line);
				
				int code = currentProcess.waitFor();
				
				if (code == 0)
				{
					exitedGracefully = true;
				}
				else
				{
					addOutput("External Process " + command[0] +
							" exited with abnormal exit code: " + code);
				}
			}
			catch (IOException | InterruptedException e)
			{
				addOutput("Error while running external process" + command[0] + ": " + e);
			}
			
			pane.setVisible(false);
		}
		
		private String prettyString(String[] s)
		{
			String rv = "";
			
			for (int i = 0; i < s.length; ++i)
			{
				if (i > 0)
					rv += " ";
				
				rv += s[i];
			}
			
			return rv;
		}

		public void kill()
		{
			exitedGracefully = false;
			addOutput("Attempting to kill external process...");
			
			if (killed)
			{
				// they pressed kill twice, the process is not cooperating, no way to kill it so just
				// hide the pane (this may leave behind a zombie thread/process though :()
				pane.setVisible(false);
			}
			else
			{
				currentProcess.destroy();
				killed = true;
			}
		}
	}

	public static JButton createButton(final HyCreateFrame parent, final JEditorPane editor, JFrame frame)
	{
		JButton b = new JButton("<html><center>Edit<br />Externally</center></html>");
		
		b.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e)
			{
				String initText = editor.getText();
				
				int pos = editor.getCaretPosition();
				
				String newText = ExternalEditorPane.showExternalEditor(parent, initText);
				
				if (newText != null && !newText.equals(initText))
				{
					editor.setText(newText);
					
					if (pos > newText.length())
						pos = newText.length() - 1;
					
					if (pos < 0)
						pos = 0;
					
					editor.setCaretPosition(pos);
				}
			}
			
		});
		
		return b;
	}
}
