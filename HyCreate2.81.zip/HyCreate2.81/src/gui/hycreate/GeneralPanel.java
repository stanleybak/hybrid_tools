package gui.hycreate;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedList;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import com.stanleybak.hycreate.containers.HyCreateData;


import main.Util;

public class GeneralPanel implements ActionListener
{
	//////// PRIVATE VARIABLES ///////////
	private HyCreateFrame parent;
	private JPanel panel;
	private JTextField name;
	private JTextField dimensions;
	private JTextArea output;
	private JButton compile;
	private JButton compute;
	public JButton killExternal;
	private JEditorPane initialStates;
	private JButton editDimensions;
	private JButton editName;
	
	//////// PRIVATE CONSTANTS //////////
	private static String INIT_HELP_TEXT = 
			"The initial states for the reachability computation ('#' is the comment character).\n" +
			"This is specified as a list of hyperrectangles with modes, one on each line.\n" +
			"For each dimension, provide an (inclusive) interval, with a comma\n" +
			"separating the minimum and maximum value in that dimension. After the last\n" +
			"dimension, provide the string name of the mode. Each entry (dimension / mode)\n"+
			"is to be separated by a semicolon. Quotes are automatically added around the\n" +
			"entries, so if you want to refer to Global values, you need to close and reopen\n" +
			"the quotes. Thus, remember to escape quotes with '\\' if you want to include them\n" +
			"inside comments.\n\n" +
			"For example, if you have two dimensions x and y, and you want an initial state\n" + 
			"to be the rectangle x=[2,3], y=[-5,-4] in the discrete mode named 'on', you\n" +
			"would write on a single line:\n" +
			"2,3  ;  -5,-4  ;  on\n\n"
			+"Alternatively, if you want dimension y to be initialized using Global variables that\n"
			+ "you named yStart and yEnd, you could write on a single line:\n" +
			"2,3  ;  \" + Global.yStart + \",\" + Global.yEnd + \" ;  on";
	
	private static String DEFAULT_INIT = 
			"# initial states as a list of hyperrectangles with discrete modes";
	
	/////////// OUTPUT DISPLAY THREAD ////////////
	LinkedList <String> outputStrings = new LinkedList <String>();
	boolean modifiedOutputStrings = false;
	
	Thread outputStringThread = new Thread() {
		public void run()
		{
			while (parent.frame != null && parent.frame.isVisible())
			{
				if (modifiedOutputStrings)
				{
					StringBuffer str = new StringBuffer();
					int lastLineStartPos = 0;
					
					synchronized (outputStrings)
					{
						for (String s : outputStrings)
						{
							if (str.length() > 0)
								str.append("\n");
							
							lastLineStartPos = str.length();
								
							str.append(s);
						}
						
						modifiedOutputStrings = false;
					}
					
					final StringBuffer finalStringBuffer = str;
					final int finalLastLineStartPos = lastLineStartPos;
					
					SwingUtilities.invokeLater(new Runnable(){
						public void run()
						{
							output.setText(finalStringBuffer.toString());
							output.setCaretPosition(finalLastLineStartPos);
						}
					});
				}
				
				try
				{
					Thread.sleep(50);
				}
				catch (InterruptedException e) {}
			}
		}
	};

	public GeneralPanel(HyCreateFrame parent)
	{
		this.parent = parent;
		
		panel = new JPanel();		
		panel.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = c.gridy = 0;
		c.fill = GridBagConstraints.BOTH;
		c.weighty = 0.2;
		c.weightx = 1.0;
		
		panel.add(makeTopPanel(), c);
		
		c.gridy = 1;
		c.weighty = 0.8;
		panel.add(makeCenterPanel(), c);
	}
	
	public void startUpdateOutputThread()
	{
		outputStringThread.start();
	}
	
	private JPanel makeButtonPanel()
	{
		JPanel rv = new JPanel();
		
		rv.setLayout(new FlowLayout());
		
		compile = new JButton("Compile");
		compile.addActionListener(this);
		rv.add(compile);
		
		rv.add(Box.createRigidArea(new Dimension(20,0)));
		
		compute = new JButton("Compile and Compute");
		compute.addActionListener(this);
		rv.add(compute);
		
		killExternal = new JButton("Kill External Process");
		killExternal.addActionListener(this);
		killExternal.setEnabled(false);
		rv.add(killExternal);
		
		return rv;
	}

	private JPanel makeCenterPanel()
	{
		JPanel rv = new JPanel();
		rv.setLayout(new BorderLayout());
		
		output = new JTextArea();
		output.setEditable(false);
		
		// arg, this seems harder than it needs to be
		output.setEnabled(false);
		Color trColor = output.getBackground();
		output.setEnabled(true);
		
		// setBackground doesn't seem to react t textResource colors
		Color color = new Color(trColor.getRed(), trColor.getGreen(), trColor.getBlue());
		output.setBackground(color);
		
		output.setText(" ");
		
		JScrollPane sp = new JScrollPane(output);
		
		rv.add(sp, BorderLayout.CENTER);
		rv.add(makeButtonPanel(), BorderLayout.PAGE_END);
		
		return HyCreateFrame.addFrame("Output", rv);
	}

	private JPanel makeTopPanel()
	{
		JPanel p = new JPanel();
		
		//Add input to top panel
		
		p.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.insets = new Insets(0,5,10,5);
		
		c.gridx = 0; c.gridy = 0; c.weightx = 0;
		p.add(new JLabel("Automaton Name:", JLabel.RIGHT), c);
		
		c.gridx = 1; c.gridy = 0; c.weightx = 1; c.gridwidth = 1;
		name = new JTextField(20);
		name.setEnabled(false);
		name.setDisabledTextColor(name.getForeground());
		name.setText("automaton_name");
		name.getDocument().addDocumentListener(parent.modListen);
		p.add(name, c);
		
		c.gridx = 2; c.gridy = 0; c.weightx = 0; c.gridwidth = 1;
		editName = new JButton("Edit Automaton Name");
		editName.addActionListener(this);
		p.add(editName,c);
		
		c.gridx = 0; c.gridy = 1; c.weightx = 0; c.gridwidth = 1;
		p.add(new JLabel("Dimension Names:", JLabel.RIGHT), c);
		
		c.gridx = 1; c.gridy = 1; c.weightx = 1;
		dimensions = new JTextField(20);
		dimensions.setEnabled(false);
		dimensions.setDisabledTextColor(dimensions.getForeground());
		dimensions.setText("x,y");
		dimensions.getDocument().addDocumentListener(parent.modListen);
		p.add(dimensions, c);
		
		c.gridx = 2; c.gridy = 1; c.weightx = 0;
		editDimensions = new JButton("Edit Dimension Names");
		editDimensions.addActionListener(this);
		p.add(editDimensions,c);
		
		JPanel upper =  HyCreateFrame.addFrame("General Settings", p);
		
		initialStates = new JEditorPane();
		JPanel lower = parent.createCodePanel(initialStates, DEFAULT_INIT,
										"Initial States", INIT_HELP_TEXT);
		
		JPanel rv = new JPanel();
		rv.setLayout(new BorderLayout());
		rv.add(upper, BorderLayout.PAGE_START);
		rv.add(lower, BorderLayout.CENTER);
		
		return rv;
	}

	////////////// public methods below ////////////////
	
	public JPanel getPanel()
	{
		return panel;
	}
	
	public void setInitialStates(String s)
	{
		initialStates.setText(s);
	}
	
	public void clearOutput()
	{
		synchronized (outputStrings)
		{
			outputStrings.clear();
			modifiedOutputStrings = true;
			
			outputStringThread.interrupt();
		}
	}
	
	public void addOutput(final String msg)
	{
		synchronized (outputStrings)
		{
			final int MAX_SIZE = 1000;
			
			while (outputStrings.size() > MAX_SIZE)
				outputStrings.removeFirst();
			
			outputStrings.addLast(msg);
			modifiedOutputStrings = true;
			
			// don't interrupt here since we may call addOutput
			// many times in a row and it would stall each time constructing the 
			// new stringbuffer to assign
			//outputStringThread.interrupt();
		}
	}
	
	public void importFrom(HyCreateData data)
	{
		name.setText(data.getAutomatonName());
		dimensionNamesUpdated(data.getDimensions());

		initialStates.setText(data.getInitialStates());
		
		clearOutput();
		
		panel.revalidate();
		panel.repaint();
	}

	public void exportTo(HyCreateData data)
	{
		data.setAutomatonName(name.getText());
		data.setDimensions(dimensions.getText());
		data.setInitialStates(initialStates.getText());
	}
	
	/**
	 * Reparse the dimension names as if they were just input by the user
	 * This may have the effect of launching dimension name change listeners.
	 */
	public void forceDimensionNamesUpdated()
	{
		dimensionNamesUpdated(dimensions.getText());
	}
	
	//////////// private methods below ///////////////	
	private void dimensionNamesUpdated(String names)
	{
		String[] parts = names.split(",");
		
		ArrayList <String> result = new ArrayList<String>();
		
		for (String part : parts)
		{
			part = Util.cleanName(part);
			
			if (part.length() > 0)
				result.add(part);
		}
		
		String[] dimNames = result.toArray(new String[result.size()]);
		
		// update the GUI
		dimensions.setText(toCommaSeparated(dimNames));
		
		parent.dimensionsUpdated(dimNames);
	}

	private String toCommaSeparated(String[] strings)
	{
		String rv = "";
		
		for (int x = 0; x < strings.length; ++x)
		{
			if (x != 0)
				rv += ", ";
			
			rv += strings[x];
		}
		
		return rv;
	}
	
	///////////////// EVENTS BELOW //////////////

	@Override
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == compile)
		{
			parent.startCompile(false);
		}
		else if (e.getSource() == compute)
		{
			parent.startCompile(true);
		}
		else if (e.getSource() == editName)
		{
			String title = "Edit Automaton Names";
			String curText = name.getText();
			
			String output = (String)JOptionPane.showInputDialog(panel, 
					"Please enter the automaton name:", 
					title, JOptionPane.QUESTION_MESSAGE, null, null, curText);
			
			if (output != null)
			{
				output = Util.cleanName(output);
				
				if (output.length() > 0)
					name.setText(output);
				else
					name.setText("automaton_name");
			}
		}
		else if (e.getSource() == editDimensions)
		{
			String title = "Edit Dimension Names";
			String curText = dimensions.getText();
			
			String output = (String)JOptionPane.showInputDialog(panel, 
					"Please enter a comma-separated list of dimension names:", 
					title, JOptionPane.QUESTION_MESSAGE, null, null, curText);
			
			if (output != null)
			{
				dimensionNamesUpdated(output);
			}
		}
		else if (e.getSource() == killExternal)
		{
			parent.killExternal();
		}
	}
	
	public boolean isCompilingComputing()
	{
		return !compute.isEnabled();
	}

	public void setCompilingComputing(boolean isCompilingComputing)
	{
		compute.setEnabled(!isCompilingComputing);
		compile.setEnabled(!isCompilingComputing);
	}
}
