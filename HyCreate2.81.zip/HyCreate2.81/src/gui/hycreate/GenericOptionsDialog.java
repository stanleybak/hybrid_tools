package gui.hycreate;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import com.stanleybak.hycreate.containers.GenericOptions;


import main.Main;

/**
 * GenericOptionsDialog will generate a GUI based on a JavaBean-like object and
 * allow the user to make modifications and press Ok or Cancel
 * 
 * It uses reflection to check for getters and setters. Additionally, if the getter is called
 * getAbc, it will check for:
 * 
 * String getAbcLabel - the string label used in the GUI.
 * String getAbcHelp - a message to display if the "help" button is pressed
 * 
 * @author Stanley Bak
 *
 */
@SuppressWarnings("serial")
public class GenericOptionsDialog extends JDialog 
	implements ActionListener, ItemListener, DocumentListener, ChangeListener
{
	public boolean changed = false;
	public boolean okPressed = false;
	
	private Object bean;
	
	private JButton okButton = new JButton("Ok");
	private JButton cancelButton = new JButton("Cancel");
	
	// Data extracted through reflection
	ArrayList <BeanData> beanData = new ArrayList <BeanData>();
	
	/**
	 * Create a GenericOptionsDialog with the given parent, title, and data object
	 * @param parent the parent jframe, can be null
	 * @param title the title to use
	 * @param bean the java-bean like object which stores the initial values and gets
	 *             assigned the result
	 */
	private GenericOptionsDialog(JFrame parent, String title, Object bean)
	{
		super(parent, title, true);
		
		this.bean = bean;
		
		// this is done in response to a user action, so it is in the event thread,
		// so we can just create the GUI directly without using invokeLater
		
		Container pane = this.getContentPane();
		pane.setLayout(new BorderLayout());
		
		JPanel body = new JPanel();
		createBodyGui(body);
		pane.add(body, BorderLayout.CENTER);
		
		JPanel bottom = new JPanel();
		pane.add(bottom, BorderLayout.PAGE_END);
		bottom.setLayout(new FlowLayout());
		bottom.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
		
		Dimension buttonDimension = new Dimension(80, 25);
		this.getRootPane().setDefaultButton(okButton);
		okButton.addActionListener(this);
		okButton.setPreferredSize(buttonDimension);
		bottom.add(okButton);
		
		bottom.add(Box.createRigidArea(new Dimension(35,0)));
		
		cancelButton.addActionListener(this);
		cancelButton.setPreferredSize(buttonDimension);
		bottom.add(cancelButton);
		
		pack();
		
		if (parent == null)
			setLocation(100,100);
		else
		{
			// center around parent
			int x = parent.getX() + parent.getWidth() / 2 - getWidth() / 2;
			int y = parent.getY() + parent.getHeight() / 2 - getHeight() / 2;
			
			setLocation(x, y);
		}
	}
	
	/**
	 * Create the gui based on the java bean
	 * @param body the jpanel where to put the GUI
	 */
	private void createBodyGui(JPanel body)
	{
		populateBeanData();
		
		body.setLayout(new GridBagLayout());
		
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridy = 0;
		c.insets = new Insets(5,10,5,10);
	
		for (BeanData bd : beanData)
		{
			String labelText = bd.getLabel();
			
			if (bd.type == MethodType.STRING)
			{
				// add label
				JLabel l = new JLabel(labelText);
				c.weightx = 0;
				c.gridx = 0;
				body.add(l, c);
				
				// add text field
				String init = (String)bd.getValue();
				JTextField tf = new JTextField(init);
				tf.getDocument().addDocumentListener(this);
				bd.comp = tf;
				c.gridx = 1;
				c.weightx = 1;
				body.add(bd.comp, c);
			}
			else if (bd.type == MethodType.BOOLEAN)
			{
				boolean init = (Boolean)bd.getValue();
				
				// add check box
				JCheckBox cb = new JCheckBox(labelText);
				cb.setSelected(init);
				cb.addItemListener(this);
				bd.comp = cb;
				c.weightx = 1;
				c.gridx = 0;
				c.gridwidth = 2;
				body.add(cb, c);
				c.gridwidth = 1;
			}
			else if (bd.type == MethodType.INTEGER)
			{
				// add label
				JLabel l = new JLabel(labelText);
				c.weightx = 0;
				c.gridx = 0;
				body.add(l, c);
				
				// add spinner
				int init = (Integer)bd.getValue();
				int[] range = (int[])bd.getRange();
				
				int min = range == null ? Integer.MIN_VALUE : range[0];
				int max = range == null ? Integer.MAX_VALUE : range[1];
				
				SpinnerModel model = new SpinnerNumberModel(init, min, max, 1);  
				
				JSpinner s = new JSpinner(model);
				s.addChangeListener(this);
				bd.comp = s;
				
				c.weightx = 1;
				c.gridx = 1;
				body.add(s, c);
			}
			else if (bd.type == MethodType.DOUBLE)
			{
				// add label
				JLabel l = new JLabel(labelText);
				c.weightx = 0;
				c.gridx = 0;
				body.add(l, c);
				
				// add text field
				String init = "" + (Double)bd.getValue();
				JTextField tf = new JTextField(init);
				tf.getDocument().addDocumentListener(this);
				bd.comp = tf;
				c.gridx = 1;
				c.weightx = 1;
				body.add(bd.comp, c);
			}
			else if (bd.type == MethodType.ENUM)
			{
				// add label
				JLabel l = new JLabel(labelText);
				c.weightx = 0;
				c.gridx = 0;
				body.add(l, c);
				
				// add combo box
				String[] enumNames = new String[bd.enumConstants.length];
				
				for (int i = 0; i < bd.enumConstants.length; ++i)
					enumNames[i] = prettyEnumString(bd.enumConstants[i].toString());
				
				JComboBox <String> cb = new JComboBox <String>(enumNames);
				Object init = bd.getValue();
				cb.setSelectedIndex(indexOf(bd.enumConstants, init));
				cb.addItemListener(this);
				
				bd.comp = cb;
				c.weightx = 1;
				c.gridx = 1;
				body.add(cb, c);
			}
			else if (bd.type == MethodType.SUBOPTIONS)
			{
				// add label
				JLabel l = new JLabel(labelText);
				c.weightx = 0;
				c.gridx = 0;
				body.add(l, c);
				
				// add button
				JButton b = new JButton("Edit " + labelText);
				b.addActionListener(this);
				bd.comp = b;
				c.gridx = 1;
				c.weightx = 0;
				c.fill = GridBagConstraints.NONE;
				body.add(bd.comp, c);
				c.fill = GridBagConstraints.HORIZONTAL;
			}
			
			final String helpText = bd.getHelp();
			
			if (helpText != null)
			{
				c.gridx = 2;
				c.weightx = 0;
				JButton helpButton = HelpButton.create(helpText, body);
				body.add(helpButton, c);
			}
			
			++c.gridy;
		}
		
	}

	/**
	 * Get the first index of object a in array objs. Use -1 if not found.
	 * @param objs the array of objects
	 * @param a the object we're looking for
	 * @return the index, or -1 if not found
	 */
	private int indexOf(Object[] objs, Object a)
	{
		int rv = -1;
		
		for (int i = 0; i < objs.length; ++i)
		{
			if (objs[i].equals(a))
			{
				rv = i;
				break;
			}
		}
		
		return rv;
	}

	private String prettyEnumString(String string)
	{
		String rv = "";
		boolean nextCap = true;
		
		for (int i = 0; i < string.length(); ++i)
		{
			char c = string.charAt(i);
			
			if (c == '_')
			{
				nextCap = true;
				rv += " ";
			}
			else if (nextCap)
			{
				rv += Character.toUpperCase(c);
				nextCap = false;
			}
			else
			{
				rv += Character.toLowerCase(c);
			}
		}
		
		return rv;
	}

	private void populateBeanData()
	{
		Class<? extends Object> c = bean.getClass();
		
		for (Method getter : c.getMethods())
		{
			if (isGetter(getter))
			{
				MethodType type = null;
				
				if (getter.getReturnType() == String.class)
					type = MethodType.STRING;
				else if (getter.getReturnType() == boolean.class)
					type = MethodType.BOOLEAN;
				else if (getter.getReturnType() == int.class)
					type = MethodType.INTEGER;
				else if (getter.getReturnType() == double.class)
					type = MethodType.DOUBLE;
				else if (getter.getReturnType().isEnum())
					type = MethodType.ENUM;
				else if (GenericOptions.class.isAssignableFrom(getter.getReturnType()))
					type = MethodType.SUBOPTIONS;
				else
					continue;
				
				BeanData bd = new BeanData(type);
				String getterFullName = getter.getName();
				bd.getter = getter;
				
				if (getterFullName.startsWith("is"))
					bd.name = getterFullName.substring("is".length());
				else
					bd.name = getterFullName.substring("get".length());
				
				// look for a setter, description, and help
				for (Method m : c.getMethods())
				{
					if (isSetter(m, bd.name))
						bd.setter = m;
					else if (isFunc(m, bd.name, "Label"))
						bd.labelFunc = m;
					else if (isFunc(m, bd.name, "Help"))
						bd.helpFunc = m;
					else if (isFunc(m, bd.name, "Range"))
						bd.rangeFunc = m;
				}
				
				// if it's an enum, assign the enum names
				if (type == MethodType.ENUM)
					bd.enumConstants = getter.getReturnType().getEnumConstants();
				
				if (type == MethodType.SUBOPTIONS)
				{
					bd.unsavedSubOptions = (GenericOptions)copyBean((GenericOptions)bd.getValue());
				}
				
				// if there is a setter, add the bean to the objects
				if (bd.setter != null)
					beanData.add(bd);
			}
		}		
	}
	
	private static Object copyBean(Object fromBean)
	{
		Class<? extends Object> c = fromBean.getClass();
		Object rv = null;
		
		try
		{
			rv = c.newInstance();
			
			for (Method getter : c.getMethods())
			{
				if (isGetter(getter))
				{
					String getterFullName = getter.getName();
					String getterVariableName;
					
					if (getterFullName.startsWith("is"))
						getterVariableName = getterFullName.substring("is".length());
					else
						getterVariableName = getterFullName.substring("get".length());
					
					// now find the corresponding setter
					for (Method setter : c.getMethods())
					{
						if (isSetter(setter, getterVariableName))
						{
							Object val = getter.invoke(fromBean);
							
							setter.invoke(rv, val);
							
						}
					}	
				}
			}
		}
		catch (IllegalArgumentException | IllegalAccessException | 
				InvocationTargetException | InstantiationException e)
		{
			// shouldn't happen
			throw new RuntimeException(e);
		}
		
		return rv;
	}

	private static boolean isGetter(Method m)
	{
		boolean nameOk = false;
		
		nameOk = m.getName().startsWith("is") && m.getReturnType().equals(boolean.class);
		
		if (!nameOk)
			nameOk = m.getName().startsWith("get");
		
		return  nameOk && 
				m.getParameterTypes().length == 0 &&
				!m.getReturnType().equals(void.class);
	}
	
	private static boolean isSetter(Method m, String name)
	{
		return 	m.getName().equals("set" + name) && 
				m.getParameterTypes().length == 1;
	}
	
	/**
	 * Is the method an optional function, like getAbcHelp or getAbcLabel
	 * @param m the method
	 * @param name the name of the field, like "Abc" in the above examples
	 * @param suffix the suffix, like "Help" or "Label" in the above examples
	 * 
	 * @return true iff m matches the name, takes no args, and returns a single string 
	 */
	private boolean isFunc(Method m, String name, String suffix)
	{
		boolean rv = m.getName().equals("get" + name + suffix) && 
				m.getParameterTypes().length == 0;
		
		return rv;
	}

	/**
	 * Show an options dialog, use the following bean object to
	 * generate the GUI
	 * @param dialogTitle the title of the dialog
	 * @param bean the object where to get the initial values, and to save to
	 * @return true iff a change was made and then ok was pressed
	 */
	public static boolean showOptionsDialog(GenericOptions bean)
	{
		JFrame parent = null;
		
		if (Main.hcf != null)
			parent = Main.hcf.frame;
		
		String title = bean.guiTitle();
		
		GenericOptionsDialog dialog = new GenericOptionsDialog(parent, title, bean);
		dialog.setVisible(true);
		
		return dialog.okPressed && dialog.changed;
	}
	
	/**
	 * Save all the data from the gui back to the java bean
	 */
	private void saveDataToBean()
	{
		for (BeanData bd : beanData)
		{
			if (bd.type == MethodType.STRING)
			{
				JTextField tf = (JTextField)bd.comp;
				String text = tf.getText();
				
				bd.set(text);
			}
			else if (bd.type == MethodType.BOOLEAN)
			{
				JCheckBox cb = (JCheckBox)bd.comp;
				boolean val = cb.isSelected();
				
				bd.set(val);
			}
			else if (bd.type == MethodType.INTEGER)
			{
				JSpinner s = (JSpinner)bd.comp;
				int val = (Integer)s.getValue();
				
				bd.set(val);
			}
			else if (bd.type == MethodType.DOUBLE)
			{
				JTextField s = (JTextField)bd.comp;
				String val = s.getText();
				double dVal = 0;
				
				try
				{
					dVal = Double.parseDouble(val);
				}
				catch (NumberFormatException e) {}; // errors are silent
				
				bd.set(dVal);
			}
			else if (bd.type == MethodType.ENUM)
			{
				JComboBox <?> cb = (JComboBox <?>)bd.comp;
				int index = cb.getSelectedIndex();
				
				bd.set(bd.enumConstants[index]);
			}
			else if (bd.type == MethodType.SUBOPTIONS)
			{
				bd.set(bd.unsavedSubOptions);
			}
		}
	}
	
	/**
	 * Convert a string from camel case to spaces. For example "helloWorld" -> "Hello World"
	 * @param str the camel case string
	 * @return the string with spaces
	 */
	private static String camelCaseToSpaces(String str)
	{
		String rv = "";
		
		if (str.length() > 0)
		{
			rv += Character.toUpperCase(str.charAt(0));
			
			for (int i = 1; i < str.length(); ++i)
			{
				char c = str.charAt(i);
				
				if (Character.isUpperCase(c))
					rv += " ";
				
				rv += c;
			}
		}
		
		return rv;
	}
	
	////////////////////////// TYPES /////////////////////////
	/**
	 * Supported method types for the getters and setters which generate a GUI
	 * automatically
	 */
	private enum MethodType
	{
		STRING,
		BOOLEAN,
		INTEGER,
		DOUBLE,
		ENUM,
		SUBOPTIONS
	}
	
	/**
	 * Data extracted through reflection
	 */
	private class BeanData
	{
		public BeanData(MethodType t)
		{
			type = t;
		}
		
		public Object getValue()
		{
			Object rv = null;
					
			try
			{
				rv = getter.invoke(bean);
			}
			catch (IllegalArgumentException e)
			{
				// these shouldn't happen since we check the bean beforehand
				throw new RuntimeException(e);
			}
			catch (IllegalAccessException e)
			{
				// these shouldn't happen since we check the bean beforehand
				throw new RuntimeException(e);
			}
			catch (InvocationTargetException e)
			{
				// these shouldn't happen since we check the bean beforehand
				throw new RuntimeException(e);
			}
			
			return rv;
		}
		
		public Object getRange()
		{
			Object rv = null;
			
			try
			{
				if (rangeFunc != null)
					rv = rangeFunc.invoke(bean);
			}
			catch (IllegalArgumentException e)
			{
				// these shouldn't happen since we check the bean beforehand
				throw new RuntimeException(e);
			}
			catch (IllegalAccessException e)
			{
				// these shouldn't happen since we check the bean beforehand
				throw new RuntimeException(e);
			}
			catch (InvocationTargetException e)
			{
				// these shouldn't happen since we check the bean beforehand
				throw new RuntimeException(e);
			}
			
			return rv;
		}
		
		public String getLabel()
		{
			String rv = null;
			
			try
			{
				if (labelFunc != null)
					rv = (String)labelFunc.invoke(bean);
			}
			catch (IllegalArgumentException e)
			{
				// these shouldn't happen since we check the bean beforehand
				throw new RuntimeException(e);
			}
			catch (IllegalAccessException e)
			{
				// these shouldn't happen since we check the bean beforehand
				throw new RuntimeException(e);
			}
			catch (InvocationTargetException e)
			{
				// these shouldn't happen since we check the bean beforehand
				throw new RuntimeException(e);
			}
			
			if (rv == null)
				rv = camelCaseToSpaces(name);
				
			return rv;
		}
		
		public String getHelp()
		{
			String rv = null;
			
			try
			{
				if (helpFunc != null)
					rv = (String)helpFunc.invoke(bean);
			}
			catch (IllegalArgumentException e)
			{
				// these shouldn't happen since we check the bean beforehand
				throw new RuntimeException(e);
			}
			catch (IllegalAccessException e)
			{
				// these shouldn't happen since we check the bean beforehand
				throw new RuntimeException(e);
			}
			catch (InvocationTargetException e)
			{
				// these shouldn't happen since we check the bean beforehand
				throw new RuntimeException(e);
			}
				
			return rv;
		}
		
		public void set(Object param) 
		{
			try
			{
				setter.invoke(bean, param);
			}
			catch (IllegalArgumentException | IllegalAccessException | InvocationTargetException e)
			{
				// these shouldn't happen since we check the bean beforehand
				throw new RuntimeException(e);
			}
		}

		String name;
		Method getter;
		Method setter;
		Method labelFunc;
		Method helpFunc;
		Method rangeFunc;
		
		Object[] enumConstants; // assigned if type is ENUM
		
		GenericOptions unsavedSubOptions; // assigned if type is SUBOPTIONS
		
		MethodType type;
		
		// gui data
		JComponent comp;
	}
	
	/////////////////////////////// EVENTS ///////////////////////////

	@Override
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == cancelButton)
			setVisible(false);
		else if (e.getSource() == okButton)
		{
			saveDataToBean();
			
			okPressed = true;
			setVisible(false);
		}
		else
		{
			// check for sub-options button presses
			for (BeanData bd : beanData)
			{
				if (bd.type == MethodType.SUBOPTIONS && e.getSource() == bd.comp)
				{
					if (GenericOptionsDialog.showOptionsDialog(bd.unsavedSubOptions))
					{
						changed = true;
					}
				}
			}
		}
	}

	@Override
	public void changedUpdate(DocumentEvent arg0)
	{
		changed = true;
	}

	@Override
	public void insertUpdate(DocumentEvent arg0)
	{
		changed = true;
	}

	@Override
	public void removeUpdate(DocumentEvent arg0)
	{
		changed = true;
	}

	@Override
	public void itemStateChanged(ItemEvent arg0)
	{
		changed = true;
	}

	@Override
	public void stateChanged(ChangeEvent arg0)
	{
		changed = true;
	}
	
	
}
