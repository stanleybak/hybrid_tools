package gui.hycreate;

import java.awt.BorderLayout;
import java.awt.Component;

import javax.swing.JEditorPane;
import javax.swing.JPanel;

import com.stanleybak.hycreate.containers.HyCreateData;


public class GlobalPanel
{
	
	// private constants
	private static String GLOBAL_HELP = 
			"You can define global values for use in the other code blocks. Define them as \n" + 
			"'public static' variables here, and then you can refer to them using Global.<<variable name>>\n" + 
			"in the other code blocks.\n\n" +
			"For example, you could write in this block: \n" + 
			"public static double MAX_VELOCITY = 5.0;\n\n" + 
			"Then, in the other code blocks, for example, in a mode's position variable derivative, you can \n" +
			"use Global.MAX_VELOCITY instead of a hardcoded number.";
	
	// private variables
	private JPanel panel = new JPanel();
	private JEditorPane globalPane = new JEditorPane();
	
	public GlobalPanel(HyCreateFrame parent)
	{
		panel.setLayout(new BorderLayout());
	
		JPanel constantsCodePanel = parent.createCodePanel(globalPane, 
				HyCreateData.DEFAULT_GLOBAL, "Global Values", GLOBAL_HELP);
		
		panel.add(constantsCodePanel);
	}

	public Component getPanel()
	{
		return panel;
	}
	
	public void importFrom(HyCreateData d)
	{
		globalPane.setText(d.getGlobalText());
	}

	public void exportTo(HyCreateData d)
	{
		d.setGlobalText(globalPane.getText());
	}

}
