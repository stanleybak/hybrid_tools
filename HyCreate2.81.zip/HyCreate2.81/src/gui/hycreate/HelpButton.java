package gui.hycreate;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;

// format help button
public class HelpButton implements ActionListener
{
	private String helpText;
	private Component parent;
	
	private HelpButton(String helpText, Component parent) 
	{
		this.helpText = helpText;
		this.parent = parent;
	}
	
	public static JButton create(String helpText, Component parent)
	{
		JButton b = new JButton("Help");
		b.addActionListener(new HelpButton(helpText, parent));
		
		return b;
	}

	public void actionPerformed(ActionEvent e)
	{
		JOptionPane.showMessageDialog(parent, helpText, "Help", 
				JOptionPane.INFORMATION_MESSAGE);
	}
}

