package gui.hycreate;


import gui.partial.PartialResultsVisualizer;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.KeyStroke;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import com.stanleybak.hycreate.containers.FrameData;
import com.stanleybak.hycreate.containers.HyCreateData;
import com.stanleybak.hycreate.containers.HyCreateOptions;
import com.stanleybak.hycreate.containers.ModelOptions;

import main.BatchMode;
import main.FileOperations;
import main.Main;
import main.XmlUtil;

import compiler.HyCompile;


/**
 * Manager for the main frame of the GUI
 * @author Stanley Bak
 *
 */
public class HyCreateFrame implements WindowListener, ActionListener, ModeListener, ItemListener
{
	///////// PRIVATE CONSTANTS BELOW ///////////
	private final String[] emptyDimensionNames = {"(empty)"};
	private final int RECENT_FILES_MAX_SIZE = 5;
	private final String SETTINGS_PATH = "SETTINGS.XML";
	private final String SAVE_EXTENSION = ".hyc2";
	
	///////// PRIVATE STATIC BELOW ////////////
	final static private JFileChooser fileChooser = new JFileChooser();
	private static final String HYCREATE_FILE_VERSION = "File Version 3";
	
	///////// PUBLIC VARIABLES BELOW /////////////
	public ModificationListener modListen = new ModificationListener(this);
	public String hyCreateTempPath = null; // one per session, assigned on first compile
	
	///////// PRIVATE VARIABLES BELOW ///////////////
	private JTabbedPane tabs;
	public ModePanel modePanel;
	public GeneralPanel generalPanel;
	public TransitionsPanel transitionsPanel;
	public GlobalPanel globalPanel;
	
	private String openPath = null;
	private boolean modified = false;
	private String[] dimensionNames = emptyDimensionNames;
	private LinkedList <DimNamesChangedListener> dimNamesChangedListeners;
	private boolean documentListenerActive = true;
	private boolean frameCreated = false;
	private boolean compileNeeded = true;
	
	////////// GUI VARIABLES BELOW //////////
	public JFrame frame;
	// file
	private JMenuItem newButton;
	private JMenuItem openButton;
	private JMenuItem saveButton;
	private JMenuItem saveAsButton;
	private JMenuItem exitButton;
	// options
	private JMenuItem hyCreateOptionsButton;
	private JMenuItem modelOptionsButton;
	// help
	private JMenuItem aboutButton;
	
	// add to the front, remove from the end
	private ArrayList <String> recentFiles = new ArrayList <String>();
	private JMenu openRecent;
	private ArrayList <JMenuItem> openRecentItems = new ArrayList <JMenuItem>();
	private HyCompile hyCompile = null;
	public HyCreateOptions options = new HyCreateOptions();
	public ModelOptions modelOptions = new ModelOptions(); 
	
	///////////////// public static methods below /////////////
	
	public static JPanel addFrame(String title, Component c)
	{
		final int INDENT_PIXELS = 25;
		
		JPanel rv = new JPanel();
		rv.setLayout(new BorderLayout());
		
		rv.add(Box.createRigidArea(new Dimension(INDENT_PIXELS, 0)), BorderLayout.LINE_START);
		rv.add(c, BorderLayout.CENTER);
		
		Font titleFont = c.getFont().deriveFont(Font.BOLD);
		
		TitledBorder b = BorderFactory.createTitledBorder(
							BorderFactory.createEmptyBorder(5,5,5,5),
							title, TitledBorder.LEADING, TitledBorder.TOP, titleFont);

		rv.setBorder(b);
		
		return rv;
	}
	
	public static JPanel addFrame(String title, Component c, int indentPixels)
	{
		JPanel rv = new JPanel();
		rv.setLayout(new BorderLayout());
		
		if (indentPixels > 0)
			rv.add(Box.createRigidArea(new Dimension(indentPixels, 0)), BorderLayout.LINE_START);
		
		rv.add(c, BorderLayout.CENTER);
		
		Font titleFont = c.getFont().deriveFont(Font.BOLD);
		
		TitledBorder b = BorderFactory.createTitledBorder(
							BorderFactory.createEmptyBorder(5,5,5,5),
							title, TitledBorder.LEADING, TitledBorder.TOP, titleFont);

		rv.setBorder(b);
		
		return rv;
	}
	
	public static void setEnabled(Component comp, boolean b)
	{
		if (comp instanceof JPanel)
		{
			JPanel p = (JPanel)comp;
			
			for (Component c : p.getComponents())
				setEnabled(c, b);
		}
		else if (comp instanceof JScrollPane)
		{			
			JScrollPane sp = (JScrollPane)comp;
		
			sp.getViewport().getView().setEnabled(b);
		}
		else if (comp instanceof JTabbedPane)
		{
			JTabbedPane tabs = (JTabbedPane)comp;
			
			for (Component c : tabs.getComponents())
				setEnabled(c,b);
			
			tabs.setEnabled(b);
		}
		else
			comp.setEnabled(b);
		
		comp.repaint();
	}
	
///////// public methods below //////////////
	
	public LinkedList <String> getModes()
	{
		return modePanel.getModes();
	}
	
	public void addModeListener(ModeListener l)
	{
		modePanel.addModeListerer(l);
	}
	
	/**
	 * Update dimensionNames and call listeners
	 */
	public void dimensionsUpdated(String[] dims)
	{
		if (dims.length == 0)
			dimensionNames = emptyDimensionNames;
		else
			dimensionNames = dims;
		
		// call listeners
		for (DimNamesChangedListener d : dimNamesChangedListeners)
			d.dimensionNamesChanged(dims);
	}
	
	public void addDimensionNameChangeListener(DimNamesChangedListener d)
	{
		dimNamesChangedListeners.add(d);
	}
	
	public String[] getDimensions()
	{
		return dimensionNames;
	}
	
	/**
	 * Create a code panel for this frame, and add appropriate listeners for changes
	 * @param editor the JEditorPane to use
	 * @param title the title of the section
	 * @param helpText the help text when the "format help" button is pressed
	 * @return a JPanel containing the create GUI
	 */
	public JPanel createCodePanel(JEditorPane editor, String initText,
			String title, String helpText)
	{
		JPanel p = new JPanel();
		p.setLayout(new BorderLayout());
		
		editor.setPreferredSize(new Dimension(300,150));
		
		if (initText == null || initText.length() == 0)
		{
			// setting the init text fixes a weird layout bug
			throw new RuntimeException("need init text");
		}
		
		editor.setText(initText);
		
		editor.getDocument().addDocumentListener(modListen);
		JScrollPane sp = new JScrollPane(editor,
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		
		p.add(sp, BorderLayout.CENTER);
		
		JButton editExternalButton = ExternalEditorPane.createButton(this, editor, frame);
		JButton helpButton = HelpButton.create(helpText, frame);
		
		JPanel right = new JPanel();
		right.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
		right.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = c.gridy = 0;
		
		right.add(editExternalButton, c);
		
		c.gridy = 1;
		right.add(Box.createRigidArea(new Dimension(0,10)),c);
		
		c.gridy = 2;
		right.add(helpButton, c);
		
		p.add(right, BorderLayout.LINE_END);
		
		return addFrame(title, p);
	}
	
	public JButton createHelpButton(String text)
	{
		JButton helpButton = HelpButton.create(text, frame);
		
		return helpButton;
	}
	
	/**
	 * Try to close the window (query user to save if needed)
	 * @return true iff closed successfully
	 */
	public boolean tryWindowClose()
	{
		boolean closed = false;
		
		if (modified)
		{
			// Ask the user if they want to save the file.
			String message = getFilename() + " has been modified. Save before closing?";
			int o = JOptionPane.showOptionDialog(frame, message, "Save Changes?", 
					JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, 
					null, null, null);
			
			if (o != JOptionPane.CANCEL_OPTION)
			{
				boolean doClose = true;
				
				if (o == JOptionPane.YES_OPTION)
				{
					if (openPath == null)
						doClose = saveAs() != null;
					else
						doClose = save(openPath) != null;
				}
				
				if (doClose)
				{
					killExternal();
					PartialResultsVisualizer.hideIfVisible();
					
					setVisible(false);
					closed = true;
				}
			}
		}
		else
		{
			killExternal();
			PartialResultsVisualizer.hideIfVisible();
			
			setVisible(false);
			closed = true;
		}
		
		// save persistent settings
		saveSettings();
		
		return closed;
	}

	/**
	 * Mark that we are changing whether components are enabled or disabled, so that
	 * document listeners will not be fired
	 * 
	 * @param enabled
	 */
	public void setDocumentListenerState(boolean enabled)
	{
		documentListenerActive = enabled;
	}
	
	///////////////// gui methods below //////////////////
	
	public HyCreateFrame(final boolean loadLastFile, boolean showGui)
	{
		Main.hcf = this;
		
		dimNamesChangedListeners = new LinkedList <DimNamesChangedListener>();
		
		// create temp path
		hyCreateTempPath = FileOperations.getTempDirPath("hycreate2");
		
		if (SwingUtilities.isEventDispatchThread())
			makeGui(loadLastFile);
		else
		{
			// create in event dispatch thread and stall until it's created
			
			SwingUtilities.invokeLater(new Runnable(){
				public void run()
				{
					makeGui(loadLastFile);
				}
			});
		}

		waitForFrameCreation();
		
		if (showGui)
			frame.setVisible(true);
		
		generalPanel.startUpdateOutputThread();
	}
	
	/**
	 * Called in event dispatch thread
	 */
	private void makeGui(boolean loadLastFile)
	{
		frame = new JFrame(Main.TOOL_VERSION);
		
		frame.addWindowListener(this);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		
		makeMenu();
		
		// make tabbed pane with three panels
		tabs = new JTabbedPane();
		frame.add(tabs);
		generalPanel = new GeneralPanel(this);
		tabs.add("General", generalPanel.getPanel());
		
		modePanel = new ModePanel(this);
		tabs.add("Discrete Modes", modePanel.getPanel());
		
		transitionsPanel = new TransitionsPanel(this);
		tabs.add("Transitions", transitionsPanel.getPanel());
		
		globalPanel = new GlobalPanel(this);
		tabs.add("Global Values", globalPanel.getPanel());
	
		frame.pack();
		frame.setLocationRelativeTo(null);
		
		documentListenerActive = false;
		generalPanel.forceDimensionNamesUpdated();
		setModified(false);
		
		addModeListener(this);
		
		if (!BatchMode.runningInBatchMode)
			loadSettings(loadLastFile);

		documentListenerActive = true;
		frameCreated = true;
	}

	private void makeMenu()
	{
		JMenuBar bar = new JMenuBar();
		frame.setJMenuBar(bar);
		
		JMenu file = new JMenu("File");
		file.setMnemonic(KeyEvent.VK_F);
		bar.add(file);
		
		newButton = new JMenuItem("New", KeyEvent.VK_N);
		newButton.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_N, ActionEvent.CTRL_MASK));
		file.add(newButton);
		newButton.addActionListener(this);
		file.addSeparator();
		
		openButton = new JMenuItem("Open...", KeyEvent.VK_O);
		openButton.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_O, ActionEvent.CTRL_MASK));
		file.add(openButton);
		openButton.addActionListener(this);
		
		openRecent = new JMenu("Open Recent");
		file.add(openRecent);
		
		file.addSeparator();
		
		saveButton = new JMenuItem("Save", KeyEvent.VK_S);
		saveButton.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_S, ActionEvent.CTRL_MASK));
		file.add(saveButton);
		saveButton.addActionListener(this);
		
		saveAsButton = new JMenuItem("Save As...", KeyEvent.VK_A);
		saveAsButton.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_S, ActionEvent.SHIFT_MASK | ActionEvent.CTRL_MASK));
		file.add(saveAsButton);
		saveAsButton.addActionListener(this);
		file.addSeparator();
		
		exitButton = new JMenuItem("Exit", KeyEvent.VK_X);
		exitButton.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_X, ActionEvent.ALT_MASK | ActionEvent.CTRL_MASK));
		file.add(exitButton);
		exitButton.addActionListener(this);
		
		JMenu options = new JMenu("Options");
		options.setMnemonic(KeyEvent.VK_O);
		bar.add(options);
		
		hyCreateOptionsButton = new JMenuItem("HyCreate Options");
		hyCreateOptionsButton.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_H, ActionEvent.SHIFT_MASK | ActionEvent.CTRL_MASK));
		hyCreateOptionsButton.addActionListener(this);
		options.add(hyCreateOptionsButton);
		
		modelOptionsButton = new JMenuItem("Model Options");
		modelOptionsButton.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_O, ActionEvent.SHIFT_MASK | ActionEvent.CTRL_MASK));
		modelOptionsButton.addActionListener(this);
		options.add(modelOptionsButton);
		
		JMenu help = new JMenu("Help");
		help.setMnemonic(KeyEvent.VK_H);
		bar.add(help);
		
		aboutButton = new JMenuItem("About");
		help.add(aboutButton);
		aboutButton.addActionListener(this);
	}
	
	private void waitForFrameCreation()
	{
		// sleep until frame is visible, since it is made visible using invokeLater
		
		while (true)
		{
			if (frameCreated)
				break;
			
			try 
			{
				Thread.sleep(10);
			}
			catch (InterruptedException e) {}
		}
	}
	
	private void setVisible(final boolean vis)
	{
		if (SwingUtilities.isEventDispatchThread())
		{
			frame.setVisible(vis);
			
			if (vis == false)
				frame.dispose();
		}
		else
		{
			SwingUtilities.invokeLater(new Runnable(){
				public void run()
				{
					frame.setVisible(vis);
					
					if (vis == false)
						frame.dispose();
				}
			});
		}
	}
	
	private void setLocation(final int x, final int y)
	{
		SwingUtilities.invokeLater(new Runnable(){
			public void run()
			{
				frame.setLocation(x,y);
				frame.setVisible(true);
			}
		});
	}
	

	/**
	 * Called when a modification of some data in the gui occurs, basically mark that
	 * the hybrid automaton needs to be saved
	 * @param wasModified true iff we should mark as modified, false if we should make as
	 *         unmodified
	 */
	public void setModified(boolean wasModified)
	{
		if (modified != wasModified)
		{
			modified = wasModified;
		}
		
		// adjust title
		frame.setTitle(makeTitle());
		
		if (wasModified)
			compileNeeded = true;
	}
	
	public void clearOutput()
	{
		generalPanel.clearOutput();
		
		if (BatchMode.runningInBatchMode)
			System.out.println();
	}
	
	public void setExternalProcessRunning(final boolean b)
	{
		SwingUtilities.invokeLater(new Runnable(){
			public void run()
			{
				generalPanel.killExternal.setEnabled(b);
			}
		});
	}
	

	public void killExternal()
	{
		if (hyCompile != null)
			hyCompile.kill();
	}
	
	public void addOutput(final String msg)
	{
		if (BatchMode.runningInBatchMode)
			System.out.println(msg);
		
		SwingUtilities.invokeLater(new Runnable()
		{
			public void run()
			{
				generalPanel.addOutput(msg);
			}
		});
	}
	
	public void compiledSuccessfully()
	{
		compileNeeded = false;
	}
	
	public void waitForCompileCompute()
	{
		while (hyCompile.compileComputeThreadRunning)
		{
			try
			{
				Thread.sleep(10);
			}
			catch (InterruptedException e) {}
		}
	}
	
	// returns true if started compile or it's not necessary
	public boolean startCompile(boolean doCompute)
	{
		boolean rv = true;
		boolean forceCompile = doCompute == false;
		
		if (compileNeeded)
			forceCompile = true;
		
		// first, always do a save
		HyCreateData data = null;
		
		if (openPath == null)
			data = saveAs();
		else
			data = save(openPath);

		if (data == null)
		{
			rv = false;
			Main.error("Save must be done before compilation can be done.");
		}
		else
		{
			// ok save was performed, data and openPath is defined
			generalPanel.setCompilingComputing(true);
						
			hyCompile = new HyCompile(this, data, openPath);
			hyCompile.begin(forceCompile, doCompute);
		}
		
		return rv;
	}
	
	// need not run in event thread
	public void finishedCompiling()
	{
		SwingUtilities.invokeLater(new Runnable(){
			public void run()
			{
				generalPanel.setCompilingComputing(false);
			}
		});
	}
	
	///////// private helper methods below /////////////

	private String makeTitle()
	{
		return Main.TOOL_VERSION + " - " + getFilename() + (modified ? "*" : "");
	}
	
	private HyCreateData saveAs()
	{
		HyCreateData rv = null;
		if (openPath != null)
			fileChooser.setCurrentDirectory(new File(openPath).getParentFile());
		
		// first get the list of files
		int fileChooserRv = fileChooser.showSaveDialog(frame);
		
		if (fileChooserRv == JFileChooser.APPROVE_OPTION)
		{
			String path = fileChooser.getSelectedFile().getAbsolutePath();
			
			if (!path.endsWith(SAVE_EXTENSION))
				path += SAVE_EXTENSION;
			
			rv = save(path);
		}
		
		return rv;
	}
	
	private boolean load()
	{
		boolean loaded = false;
		
		if (openPath != null)
			fileChooser.setCurrentDirectory(new File(openPath).getParentFile());
		
		// first get the list of files
		int fileChooserRv = fileChooser.showOpenDialog(frame);
		
		if (fileChooserRv == JFileChooser.APPROVE_OPTION)
		{
			String path = fileChooser.getSelectedFile().getAbsolutePath();
			
			loaded = load(path);
		}
		
		return loaded;
	}
	
	public boolean load(String path)
	{
		boolean loaded = false;
		
		try
		{
			HyCreateData data = ModelLoader.load(path);
			
			// check if version matches
			if (!data.getVersionString().equals(HYCREATE_FILE_VERSION))
			{
				String text = "File version mismatch. File is '" + data.getVersionString() + 
					"', whereas HyCreate expected: '" + HYCREATE_FILE_VERSION + "'.\n" + 
					"Are you trying to open a file created using a different version of HyCreate?";
				throw new IOException(text);
			}
			
			// load was success
			openPath = path;
			loaded = true;
			updateRecentFiles(path);

			generalPanel.importFrom(data);
			modePanel.importFrom(data);
			transitionsPanel.importFrom(data);
			globalPanel.importFrom(data);
			
			modelOptions = data.getOptions();
			modelOptionsButton.setEnabled(true);
			
			setModified(false);
		}
		catch (IOException e)
		{
			String text = "Error while loading from " + path + "\n" + e;
			Main.error(text);
		}
		
		return loaded;
	}
	
	private HyCreateData save(String path)
	{		
		HyCreateData data = new HyCreateData(HYCREATE_FILE_VERSION);
				
		generalPanel.exportTo(data);
		modePanel.exportTo(data);
		transitionsPanel.exportTo(data);
		globalPanel.exportTo(data);
		
		data.setOptions(modelOptions);
		
		try
		{
			XmlUtil.saveObject(data, path);
			
			// save was success
			openPath = path;
			this.setModified(false);
			
			updateRecentFiles(path);
		}
		catch (IOException e)
		{
			String text = "Error while saving to " + path + "\n" + e;

			Main.error(text);
			data = null;
		}
		
		return data;
	}

	////////////// custom classes below //////////////
	
	private void updateRecentFiles(String path)
	{
		int i = recentFiles.indexOf(path);
		
		if (i == -1)
		{
			JMenuItem j = new JMenuItem(shortenPath(path));
			
			// add to the front
			recentFiles.add(0, path);
			openRecentItems.add(0, j);
			openRecent.add(j, 0);
			
			j.addActionListener(this);
			
			while (recentFiles.size() > RECENT_FILES_MAX_SIZE)
			{
				// remove from the end
				int endIndex = recentFiles.size() - 1;
				
				recentFiles.remove(endIndex);
				openRecent.remove(openRecentItems.get(endIndex));
				openRecentItems.remove(endIndex);
			}
			
			saveSettings();
		}
		else
		{
			// swap it to the start
			JMenuItem tempItem = openRecentItems.get(i);
			openRecentItems.set(i, openRecentItems.get(0));
			openRecentItems.set(0, tempItem);
			
			openRecent.remove(tempItem);
			openRecent.add(tempItem,0);
			
			String tempFile = recentFiles.get(i);
			recentFiles.set(i, recentFiles.get(0));
			recentFiles.set(0, tempFile);
		}
		
		openRecent.revalidate();
		openRecent.repaint();
	}

	private String shortenPath(String path)
	{
		final int NUM_CHARS = 50;
		final String PREFIX = "...";
		final int prefixLen = PREFIX.length();
		
		String rv = path;
		
		if (rv.length() > NUM_CHARS + prefixLen)
			rv = PREFIX + rv.substring(rv.length() - NUM_CHARS - prefixLen);
		
		return rv;
	}

	private void loadSettings(boolean loadLastFile)
	{
		try
		{
			FrameData fd = (FrameData)XmlUtil.loadObject(SETTINGS_PATH);
			
			if (loadLastFile && (fd.getExtendedState() & Frame.ICONIFIED) == 0)
			{
				// restore location / size
				frame.setExtendedState(fd.getExtendedState());
				
				if ((fd.getExtendedState() & Frame.MAXIMIZED_BOTH) == 0)
				{
					// if it's not maximized, set location and size
					
					frame.setLocation(fd.getLocation());
					frame.setSize(fd.getSize());
				}
			}
			
			if (loadLastFile)
				tabs.setSelectedIndex(fd.getSelectedTab());
			
			// update openRecent
			for (String s : fd.getRecentFiles())
			{
				if (new File(s).exists())
				{
					recentFiles.add(s);
					
					JMenuItem b = new JMenuItem(shortenPath(s));
					b.addActionListener(this);
					openRecentItems.add(b);
					openRecent.add(b);
				}
			}
			
			if (loadLastFile && fd.getLatestOpen() != null && 
					new File(fd.getLatestOpen()).exists())
			{
				// automatically open the last-open file
				load(fd.getLatestOpen());
			}
			
			this.options = fd.getOptions();
		}
		catch (IOException e)
		{
			System.out.println("Could not open persistent settings: " + e 
					+ "; assuming new session.");
			
			// make frame visible since its location will not be set
		}
	}
	
	private void saveSettings()
	{
		FrameData fd = new FrameData();
		
		fd.setExtendedState(frame.getExtendedState());
		fd.setLocation(frame.getLocation());
		fd.setSize(frame.getSize());
		fd.setSelectedTab(tabs.getSelectedIndex());
		fd.setRecentFiles(recentFiles);
		fd.setLatestOpen(openPath);
		fd.setOptions(options);
		
		try
		{
			XmlUtil.saveObject(fd, SETTINGS_PATH);
		}
		catch (IOException e)
		{
			Main.error("Error saving persistent settings to " 
					+ SETTINGS_PATH + "\n" + e);
		}
	}
	
	private String getFilename()
	{
		String rv = "(Untitled)";
		
		if (openPath != null)
			rv = new File(openPath).getName();
			
		return rv;
	}
	
	// path can be null
	private void saveAndOpen(String path)
	{
		boolean doLoad = true;
		
		if (modified)
		{
			// ask for save
			
			String message = getFilename() + " has been modified. Save?";
			
			int o = JOptionPane.showOptionDialog(frame, message, "Save Changes?", 
				    JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, 
					null, null, null);
			
			if (o == JOptionPane.CANCEL_OPTION)
				doLoad = false;
			else
			{
				if (o == JOptionPane.YES_OPTION)
				{
					if (openPath == null)
						doLoad = saveAs() != null;
					else
						doLoad = save(openPath) != null;
				}
			}
		}
		
		if (doLoad)
		{
			if (path != null)
				load(path);
			else
				load();
		}
	}

	// modification listener for all the GUI so save can be queried when exiting 
	class ModificationListener implements DocumentListener
	{
		HyCreateFrame parent;
		
		public ModificationListener(HyCreateFrame parent)
		{
			this.parent = parent;
		}
		
		public void modified(DocumentEvent e)
		{
			if (parent.documentListenerActive)
				parent.setModified(true);
		}

		@Override
		public void changedUpdate(DocumentEvent e)
		{
			modified(e);
		}

		@Override
		public void insertUpdate(DocumentEvent e)
		{
			modified(e);
		}

		@Override
		public void removeUpdate(DocumentEvent e)
		{
			modified(e);
		}
	}
	
	///////////////// listeners below //////////////////////

	@Override
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == newButton)
		{
			if (tryWindowClose())
			{
				HyCreateFrame f = new HyCreateFrame(false, true);
				
				f.setLocation(frame.getX() + 20, frame.getY() + 10); // offset it a little
				
				frame.dispose();
				frame = null;
			}
		}
		else if (e.getSource() == openButton)
		{
			saveAndOpen(null);
		}
		else if (e.getSource() == saveButton)
		{
			if (openPath == null)
				saveAs();
			else
				save(openPath);
		}
		else if (e.getSource() == saveAsButton)
		{
			saveAs();
		}
		else if (e.getSource() == hyCreateOptionsButton)
		{
			if (GenericOptionsDialog.showOptionsDialog(options))
				saveSettings();
		}
		else if (e.getSource() == modelOptionsButton)
		{
			if (GenericOptionsDialog.showOptionsDialog(modelOptions))
				setModified(true);
		}
		else if (e.getSource() == exitButton)
		{
			tryWindowClose();
		}
		else if (e.getSource() == aboutButton)
		{
			JOptionPane.showMessageDialog(frame, Main.ABOUT_TEXT, 
					"About HyCreate", JOptionPane.INFORMATION_MESSAGE);
		}
		else
		{
			// try open recent items
			
			for (int i = 0; i < openRecentItems.size(); ++i)
			{
				if (e.getSource() == openRecentItems.get(i))
				{
					// open path i
					String path = recentFiles.get(i);
							
					saveAndOpen(path);
				}
			}
		}
	}

	@Override
	public void windowClosing(WindowEvent e)
	{
		tryWindowClose();
	}

	@Override
	public void windowActivated(WindowEvent e){}

	@Override
	public void windowClosed(WindowEvent e){}
	
	@Override
	public void windowDeactivated(WindowEvent e) {}

	@Override
	public void windowDeiconified(WindowEvent e) {}

	@Override
	public void windowIconified(WindowEvent e) {}

	@Override
	public void windowOpened(WindowEvent e) {}

	@Override
	public void modesUpdated(LinkedList<String> modeNames)
	{
		setModified(true);
	}

	@Override
	public void modeRenamed(String from, String to) {}

	@Override
	public void itemStateChanged(ItemEvent e)
	{
		// inform the modification listener listener, event doesn't matter
		modListen.modified(null);
	}
}
