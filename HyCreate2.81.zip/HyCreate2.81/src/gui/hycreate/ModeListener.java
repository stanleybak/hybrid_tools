package gui.hycreate;

import java.util.LinkedList;

public interface ModeListener
{
	public void modesUpdated(LinkedList <String> modeNames);
	public void modeRenamed(String from, String to);
}
