package gui.hycreate;


import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.stanleybak.hycreate.containers.HyCreateData;
import com.stanleybak.hycreate.containers.ModeData;

import main.Main;
import main.Util;

public class ModePanel implements ActionListener, ListSelectionListener, 
									DimNamesChangedListener
{	
	//////// PRIVATE GUI VARIABLES ///////////
	private HyCreateFrame parent;
	private JPanel panel;
	private boolean localListEventsEnabled = true;
	private JList <String> modeList;
	private DefaultListModel <String> listModel;
	private JTextField modeName;
	private JTextField gridSize;
	private JTextField regridRatio;
	private JPanel modeDescriptionPanel;
	private JEditorPane invariant;
	private JEditorPane timeTrigger;
	private JTabbedPane perDimensionTabbedPane;
	private ArrayList <DimensionGui> perDimensionGui = new ArrayList <DimensionGui>();
	private JButton addButton;
	private JButton removeButton;
	private JButton copyButton;
	private JButton renameButton;
	
	//////// PRIVATE VARIABLES ////////
	private String displayedName = null; 
	private LinkedList <ModeListener> modeListeners = new LinkedList <ModeListener>();
	private TreeMap <String, ModeData> data = new TreeMap <String, ModeData>();
	
	//////// PRIVATE CONSTANTS /////////
	private String GRID_SIZE_HELP_TEXT = 
			"The grid size in each dimension in this mode. Generally a smaller\n" + 
			"grid size will be more accurate, but take longer to compute. This is\n" + 
			"a comma separated list of real numbers, one for each dimension. If you\n" + 
			"leave this blank it will be estimated based on sampling the derivative.\n\n" +
			"For example, if you have two dimensions and want a grid of 0.25 x 1.0,\n" +
			"you would enter:\n"+
			"0.25, 1.0";
	
	private String REGRID_RATIO_HELP_TEXT = 
			"A multiplier (times grid size) which determines how large hyperrectangles\n" +
			"need to become before they are re-mapped to the grid (necessary to detect\n" + 
			"termination). This is a comma-separated list of real numbers. Lower values\n" + 
			"have more error from continuous regridding, larger values will result in more\n" +
			"redundant work as rectangles will overlap more often. The value must be more\n" + 
			"than 1.0 in each dimension. A typical value is 1.7.\n\n" + 
			"For example, to specify 1.7 for each of two dimensions, you enter:\n" +
			"1.7, 1.7";
	
	private String INVARIANT_HELP = 
			"Defines the invariant (allowed states) when in the current discrete mode. For a\n" +
			"specific hyperrectangle, is any part of the hyperrectangle inside the allowed states\n" +
			"for this mode (the invariant)? Edges of the hyperrectangle are inclusive. The syntax\n" + 
			"is java code which will be placed inside a method. To refer to dimension values of the\n" +
			"input hyperrectangle, use $DIM_NAME.min or $DIM_NAME.max, and they will be\n" +
			"replaced by the corresponding code.\n\n" +
			"For example, if your mode's invariant is temperature <= 50, you could enter:\n" +
			"return $TEMPERATURE.min <= 50";
	
	private String TIME_TRIGGER_HELP =
			"You can define time-triggered dynamics, where a mode computes for exactly some fixed\n" + 
			"amount of time. The value returned here defines the maximum time that can pass, per\n" +
			"face lifting operation. To use this with time-triggered dynamics, create a countdown timer\n" +
			"variable that ticks at rate -1, and return that variable here. The invariant will then\n" +
			"automatically include the time trigger, in addition to whatever you provide. For time-triggered\n" +
			"guards, you must add the condition that $trigger.min == 0 && $trigger.max == 0. If you don't want\n" +
			"to use time-triggered transitions, you can return null.\n\n" +
			"For example, if your time-trigger clock variable is called 'countdown', you could enter:\n" +
			"return $countdown;";
	
	private String DERIVATIVE_HELP = 
			"Compute the derivative at a point in the state space. For a specific value in\n" +
			"every dimension, you must provide the derivative. Since non-determinsitic\n" +
			"derivatives are allowed, the output is an Interval object. The syntax is java\n" +
			"code which will be placed inside a method. To refer to dimension values, use\n" +
			"$DIM_NAME and they will be replaced by appropriate code.\n\n" + 
			"For example, if the derivative is sqrt(x) + 2*y, you could enter:\n" +
			"double der = Math.sqrt($x) + 2*$y;\n" +
			"return new Interval(der,der);";
 	
	private String MIN_MAX_POINTS_HELP = 
			"Get the set of points inside a given hyperrectangle where the derivative\n" +
			"is minimized or maximized, not including the corners. If your system is linear,\n" +
			"you can return null. You can also return other points which are not the\n" +
			"minimum and maximum (the derivative will be sampled at each of the points).\n" +
			"The input is Java code, which will be placed inside a\n" +
			"method. To refer to dimension values of the input hyperrectangle, use\n" +
			"$DIM_NAME.min or $DIM_NAME.max and they will be replaced by\n" +
			"the corresponding code.\n\n" +
			"This is usually the hardest part for nonlinear models, but is necssary for\n" + 
			"correctness. Computing a maximum (or minimum) can be easy or difficult\n" + 
			"depending on the specific derivative function. If the min or max occurs\n" +
			"in an infinte number of points, just return at least one of them.\n\n" +
			"For example, if you have a system with dimensions {x,y} and the\n" +
			"derivative of y is (x-1)^2, the global minimum for the y derivative will\n" +
			"occur when x takes the value of 1 for any y. One would enter:\n\n" +
			"LinkedList <HyperPoint> list = new LinkedList<HyperPoint>();\n" +
			"if ($x.min < 1 && $x.max > 1)\n" +
			"    list.add(new HyperPoint(1.0, $y.min)); // x=1.0 and any y gives the minimum\n" +
			"return list;";
			;
	
	public ModePanel(HyCreateFrame parent)
	{
		this.parent = parent;
		
		panel = new JPanel();		
		panel.setLayout(new BorderLayout());
		
		panel.add(makeCenterPanel(), BorderLayout.CENTER);
		
		HyCreateFrame.setEnabled(modeDescriptionPanel, false);
	}
	
	private JPanel makeCenterPanel()
	{
		JPanel rv = new JPanel();
		rv.setLayout(new BorderLayout());
		JPanel left = new JPanel();
		modeDescriptionPanel = new JPanel();
		JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, left, modeDescriptionPanel);
		split.setOneTouchExpandable(true);
		split.setContinuousLayout(true);
		//split.setDividerLocation(200);
		
		rv.add(split, BorderLayout.CENTER);
		
		//// left ////
		populateLeftPanel(left);
		
		//// right ////
		modeDescriptionPanel.setLayout(new GridBagLayout());
		GridBagConstraints modeDescriptionPanelC = new GridBagConstraints();
		
		JPanel propertiesPanel = new JPanel();
		
		JPanel topRight = new JPanel();
		
		modeDescriptionPanelC.gridx = modeDescriptionPanelC.gridy = 0;
		modeDescriptionPanelC.fill = GridBagConstraints.BOTH;
		modeDescriptionPanelC.weighty = 0.33;
		modeDescriptionPanelC.weightx = 1.0;
		modeDescriptionPanel.add(topRight, modeDescriptionPanelC);
		
		topRight.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		
		c.gridx = c.gridy = 0; c.fill = GridBagConstraints.BOTH; c.weightx = 1.0;
		topRight.add(HyCreateFrame.addFrame("Properties", propertiesPanel),c);
		
		c.gridy = 1; c.weighty = 0.75;
		invariant = new JEditorPane();
		topRight.add(parent.createCodePanel(invariant, ModeData.DEFAULT_INVARIANT, 
				"Invariant", INVARIANT_HELP),c);
		
		c.gridy = 2; c.weighty = 0.25;
		timeTrigger = new JEditorPane();
		topRight.add(parent.createCodePanel(timeTrigger, ModeData.DEFAULT_TIME_TRIGGER, 
				"Time Trigger", TIME_TRIGGER_HELP),c);
		
		propertiesPanel.setLayout(new GridBagLayout());
		c = new GridBagConstraints();
		
		// name 
		c.gridx = 0; c.gridy = 0; c.fill = GridBagConstraints.HORIZONTAL; 
		c.insets = new Insets(0,10,5,0);
		propertiesPanel.add(new JLabel("Mode Name:", JLabel.RIGHT), c);
		
		modeName = new JTextField(20);
		modeName.setDisabledTextColor(modeName.getForeground());
		c.gridx = 1; c.weightx = 1; 
		propertiesPanel.add(modeName, c);
		
		// grid size
		c.gridx = 0; c.gridy = 1; c.weightx = 0;
		propertiesPanel.add(new JLabel("Grid Size:", JLabel.RIGHT), c);
		
		gridSize = new JTextField();
		gridSize.getDocument().addDocumentListener(parent.modListen);
		c.gridx = 1; c.weightx = 1;
		propertiesPanel.add(gridSize, c);
		
		c.gridx = 2; c.weightx = 0; 
		propertiesPanel.add(parent.createHelpButton(GRID_SIZE_HELP_TEXT), c);
		
		// regrid ratio
		
		c.gridx = 0; c.gridy = 2; c.weightx = 0;
		propertiesPanel.add(new JLabel("Regrid Ratio:", JLabel.RIGHT), c);
		
		regridRatio = new JTextField();
		regridRatio.getDocument().addDocumentListener(parent.modListen);
		c.gridx = 1; c.weightx = 1;
		propertiesPanel.add(regridRatio, c);
		
		c.gridx = 2; c.weightx = 0; 
		propertiesPanel.add(parent.createHelpButton(REGRID_RATIO_HELP_TEXT), c);
		
		perDimensionTabbedPane = new JTabbedPane();
		
		modeDescriptionPanelC.insets = new Insets(0,10,0,0);
		modeDescriptionPanelC.gridy = 1;
		modeDescriptionPanelC.weighty = 0.67;
		modeDescriptionPanel.add(perDimensionTabbedPane, modeDescriptionPanelC);
		
		parent.addDimensionNameChangeListener(this);
		
		return rv;
	}

	private void populateLeftPanel(JPanel left)
	{
		left.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 0; c.fill = GridBagConstraints.BOTH;
		c.gridwidth = 2; c.weightx = 1.0; c.weighty = 1.0;
		
		listModel = new DefaultListModel <String>();
		
		modeList = new JList <String>(listModel);
		modeList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		modeList.addListSelectionListener(this);
		JScrollPane sp = new JScrollPane(modeList);
		JPanel scrollPanel = HyCreateFrame.addFrame("Modes", sp, 0);
		//scrollPanel.setBorder(BorderFactory.createEmptyBorder(15,15,15,0));

		left.add(scrollPanel, c);
		
		c.gridwidth = 1; c.weightx = 0.5; c.weighty = 0; 
		c.gridy = 1; c.gridx = 0; c.anchor = GridBagConstraints.CENTER;
		c.insets = new Insets(3,15,3,15);
		addButton = new JButton("New");
		addButton.addActionListener(this);
		left.add(addButton, c);
		
		c.gridy = 2; c.gridx = 0;
		removeButton = new JButton("Delete");
		removeButton.addActionListener(this);
		left.add(removeButton, c);
		
		c.gridy = 1; c.gridx = 1;
		copyButton = new JButton("Clone");
		copyButton.addActionListener(this);
		left.add(copyButton, c);
		
		c.gridy = 2; c.gridx = 1;
		renameButton = new JButton("Rename");
		renameButton.addActionListener(this);
		left.add(renameButton, c);
	}

	private JPanel createDimensionPanel(DimensionGui dg)
	{
		JPanel rv = new JPanel();
				
		rv.setLayout(new GridLayout(2,1));
		
		
		JPanel derivativePanel = parent.createCodePanel(dg.derivative, 
				ModeData.DEFAULT_DERIVATIVE, "Derivative", DERIVATIVE_HELP);
		
		rv.add(derivativePanel);
		
		JPanel minMaxPointsPanel = parent.createCodePanel(dg.minMaxPoints, 
				ModeData.DEFAULT_MIN_MAX_POINTS, "Derivative Min/Max Points", MIN_MAX_POINTS_HELP);
		
		rv.add(minMaxPointsPanel);
		
		return rv;
	}

	public JPanel getPanel()
	{
		return panel;
	}
	
	///////////// PUBLIC METHODS BELOW //////////////
	
	public void importFrom(HyCreateData d)
	{
		// remove selection before changing 'data', in order to prevent a save-back 
		modeList.clearSelection();
		
		localListEventsEnabled = false;
		
		data = d.getModes();
		
		//System.out.println("gui.ModePanel.java: Loaded " + data.size() + " modes");
		
		listModel.clear();
		
		for (Entry<String, ModeData> e : data.entrySet())
			listModel.addElement(e.getKey());
		
		localListEventsEnabled = true;
		
		modeList.setSelectedValue(d.getSelectedMode(), true);
	
		modeNamesUpdated();
	}

	public void exportTo(HyCreateData d)
	{
		guiToData((String)modeList.getSelectedValue());
		
		d.setModes(data);
		d.setSelectedMode((String)modeList.getSelectedValue());
	}
	
	public LinkedList<String> getModes()
	{
		LinkedList <String> rv = new LinkedList <String>();
		
		for (Entry<String, ModeData> e : data.entrySet())
			rv.add(e.getKey());
		
		return rv;
	}
	
	public void addModeListerer(ModeListener l)
	{
		modeListeners.add(l);
	}
	
	/////////////// PRIVATE HELPERS METHODS BELOW //////////////
	
	private void modeRenamed(String from, String to)
	{
		for (ModeListener l : modeListeners)
			l.modeRenamed(from, to);
	}
	
	private void modeNamesUpdated()
	{
		LinkedList <String> names = getModes();
		
		for (ModeListener l : modeListeners)
			l.modesUpdated(names);
	}
	
	private void guiToData(String name)
	{
		if (name != null)
		{
			ModeData md = data.get(name);
			
			if (md == null)
				throw new RuntimeException("guiToData called for data that doesn't exist.");
			
			md.setGridSize(gridSize.getText().trim());
			md.setRegridRatio(regridRatio.getText().trim());
			md.setInvariant(invariant.getText());
			md.setTimeTrigger(timeTrigger.getText());
			
			List <String> derivatives = md.getDerivative();
			List <String> minMaxPoints = md.getMinMaxPoints();
			
			for (int d = 0; d < perDimensionGui.size(); ++d)
			{
				DimensionGui dg = perDimensionGui.get(d);
				
				derivatives.set(d, dg.derivative.getText());
				minMaxPoints.set(d, dg.minMaxPoints.getText());
			}
		}
	}

	private void dataToGui(String name)
	{
		if (name == null)
		{
			// clear data
			for (DimensionGui dg : perDimensionGui)
			{
				dg.derivative.setText(" ");
				dg.minMaxPoints.setText(" ");
			}
			
			modeName.setText("");
			
			timeTrigger.setText("");
			invariant.setText(" ");
			gridSize.setText("");
			regridRatio.setText("");
			
			HyCreateFrame.setEnabled(modeDescriptionPanel, false);
		}
		else
		{
			HyCreateFrame.setEnabled(modeDescriptionPanel, true);
			
			// populate with new selected data
			ModeData md = data.get(name);
			
			modeName.setText(name);
			modeName.setEnabled(false); // mode name stays disabled
			
			timeTrigger.setText(md.getTimeTrigger());
			invariant.setText(md.getInvariant());
			gridSize.setText(md.getGridSize());
			regridRatio.setText(md.getRegridRatio());
			
			List <String> derivatives = md.getDerivative();
			List <String> minMaxPoints = md.getMinMaxPoints();
			
			for (int d = 0; d < perDimensionGui.size(); ++d)
			{
				DimensionGui dg = perDimensionGui.get(d);
				
				if (derivatives.size() > d)
					dg.derivative.setText(derivatives.get(d));
				else
					dg.derivative.setText("Error in file");
				
				if (minMaxPoints.size() > d)
					dg.minMaxPoints.setText(minMaxPoints.get(d));
				else
					dg.derivative.setText("Error in file");
			}
		}
	}
	
	private String inputModeName(String query, String init)
	{
		String rv = null;
		String output = init;
		
		for (boolean repeat = true; repeat == true;)
		{
			repeat = false; // until set to true
			
			String title = "Enter Name";
			
			output = (String)JOptionPane.showInputDialog(panel, 
					query, 
					title, JOptionPane.QUESTION_MESSAGE, null, null, output);
			
			if (output != null)
			{
				output = Util.cleanName(output); 
				
				if (output.length() == 0)
				{
					repeat = true;
					Main.error("Your mode name was empty!");
				}
				else if (data.containsKey(output))
				{
					repeat = true;
					Main.error("A mode with that name already exists!");
				}
				else
					rv = output;
			}
		}
		
		return rv;
	}
	
	private void updateListAndSelect(String selectName)
	{
		// force saving of current data
		modeList.setSelectedIndex(-1);
		
		localListEventsEnabled = false; // since clear() causes a change event
		
		listModel.clear();
		int selectIndex = -1;
		
		for (Entry<String, ModeData> e : data.entrySet())
		{
			String name = e.getKey();
			
			listModel.addElement(name);
			
			if (name.equals(selectName))
				selectIndex = listModel.getSize() - 1;
		
		}
			
		localListEventsEnabled = true; // reenable events for the select event
		
		modeList.setSelectedIndex(selectIndex);
		modeList.repaint();
	}	
	
	/////////////// ACTION LISTENERS BELOW /////////////////

	@Override
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == addButton)
		{
			// update data and redo list
			String name = inputModeName("Please enter the name of the new discrete mode:", null);
			
			if (name != null)
			{
				data.put(name, new ModeData(parent.getDimensions().length));
				updateListAndSelect(name);
				
				modeNamesUpdated();
			}
		}
		else if (e.getSource() == removeButton)
		{
			int i = modeList.getSelectedIndex();
			
			if (i != -1)
			{
				String name = (String)listModel.get(i);
				listModel.remove(i);
				
				if (listModel.size() > i)
					modeList.setSelectedIndex(i);
				else if (listModel.size() > 0)
					modeList.setSelectedIndex(listModel.size() - 1);
				
				// remove data after selecting new one
				data.remove(name);
				
				modeNamesUpdated();
			}
			else
				Main.error("Please select a mode from the list before trying to delete.");
		}
		else if (e.getSource() == copyButton)
		{
			int i = modeList.getSelectedIndex();
			
			if (i == -1)
				Main.error("Please select a mode from the list before trying to clone.");
			else
			{
				String selectedName = (String)listModel.get(i);
			
				// update data and redo list
				String name = inputModeName("Please enter the mode name for the new copy:", 
						selectedName);
				
				if (name != null)
				{
					ModeData copyOf = data.get(selectedName);
					ModeData newData = null;
					
					if (copyOf == null)
						newData = new ModeData(parent.getDimensions().length);
					else
						newData = new ModeData(copyOf);
					
					data.put(name, newData);
					updateListAndSelect(name);
					
					modeNamesUpdated();
				}
			}
		}
		else if (e.getSource() == renameButton)
		{
			int i = modeList.getSelectedIndex();
			
			if (i == -1)
				Main.error("Please select a mode from the list before trying to rename.");
			else
			{
				String selectedName = (String)listModel.get(i);
			
				// update data and redo list
				String name = inputModeName("Please enter the new mode name:", selectedName);
				
				if (name != null && !selectedName.equals(name))
				{
					ModeData modeData = data.get(selectedName);
					
					/*
					 * The ordering of the events here matter. Generally, we add the new version as a new item,
					 * then launch the updated/renamed listeners, then we remove the old version
					 */
					
					data.put(name, modeData); // add new
					updateListAndSelect(name); // select new one (writes back gui changes to old)
					
					modeNamesUpdated(); // add new
					modeRenamed(selectedName, name); // update transition data
					
					data.remove(selectedName); // remove old
					updateListAndSelect(name); // update list to remove old
					modeNamesUpdated(); // remove old
				}
			}
		}
	}

	@Override
	public void valueChanged(ListSelectionEvent e)
	{
		if (localListEventsEnabled)
		{
			String name = (String)modeList.getSelectedValue();
			
			if (name != displayedName)
			{
				parent.setDocumentListenerState(false);
	
				// save old index from gui
				guiToData(displayedName);
				
				displayedName = name; 
			
				// load new index into gui
				dataToGui(displayedName);
				
				parent.setDocumentListenerState(true);
			}
		}
	}

	@Override
	public void dimensionNamesChanged(String[] names)
	{
		int numDimensions = names.length;
		
		// save to data (since we're changing it) and update data
		String name = (String)modeList.getSelectedValue();
		guiToData(name);
		
		for (Entry<String, ModeData> e : data.entrySet())
			e.getValue().resizeDimensions(numDimensions);
		
		// repopulate the perDimensionInfo tabbed pane
		int numTabs = perDimensionTabbedPane.getTabCount();
		
		for (int tabIndex = 0; tabIndex < numDimensions; ++tabIndex)
		{
			String dimName = names[tabIndex];
			
			if (tabIndex < numTabs)
			{
				// tab exists, just rename the tab
				perDimensionTabbedPane.setTitleAt(tabIndex, dimName);
			}
			else
			{
				// tab does not exist, add it!
				DimensionGui dg = new DimensionGui();
				
				JPanel dimPanel = createDimensionPanel(dg);
				
				perDimensionTabbedPane.add(dimName, dimPanel);
				perDimensionGui.add(dg);
			}
		}
		
		// remove any extra tabs
		while (perDimensionTabbedPane.getTabCount() > numDimensions)
		{
			perDimensionTabbedPane.remove(numDimensions);
			perDimensionGui.remove(numDimensions);
		}
		
		// set disabled if no selection
		if (modeList.getSelectedIndex() == -1)
			HyCreateFrame.setEnabled(perDimensionTabbedPane, false);
		
		// update gui since data has changed
		dataToGui(name);
		
		// update layout manager
		perDimensionTabbedPane.revalidate();
		
		// repaint
		perDimensionTabbedPane.repaint();
	}
	
	//////// PRIVATE CLASSES BELOW ////////
	private class DimensionGui
	{
		public JEditorPane derivative = new JEditorPane();
		public JEditorPane minMaxPoints = new JEditorPane();
	}

	/**
	 * Assing a value to the derivative
	 * @param mode the name of the mode to assign to
	 * @param dim the dimension to assign to 
	 * @param der the value to assign
	 */
	public void setDerivative(String mode, String dim, String der)
	{
		// first find the dimension index
		int dimensionIndex = -1;
		
		for (int x = 0; x < perDimensionTabbedPane.getTabCount(); ++x)
		{
			String d = perDimensionTabbedPane.getTitleAt(x);
			
			if (dim.equals(d))
			{
				dimensionIndex = x;
				break;
			}
		}
		
		if (dimensionIndex == -1)
			throw new RuntimeException("Dimension not found " + dim);
		else if (!data.containsKey(mode))
			throw new RuntimeException("Mode not found " + mode);
		else
		{
			modeList.setSelectedValue(mode, false);
			perDimensionGui.get(dimensionIndex).derivative.setText(der);
		}
	}
}
