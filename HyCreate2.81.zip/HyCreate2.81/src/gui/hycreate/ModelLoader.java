package gui.hycreate;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Map.Entry;
import java.util.TreeMap;

import main.XmlUtil;

public class ModelLoader {

	/**
	 * Load the model from the file. This is done in a backwards compatible way with
	 * the old package names. This makes use of java reflection pretty extensively.
	 * Since generic objects are used, I can't use reflection for everything, so it ends 
	 * up being pretty ugly code... sorry about that.
	 * 
	 * @param path the path to load from
	 * @return the model, in the com.stanleybak.hycreate.containers package
	 * @throws IOException if a file error occurs
	 */
	public static com.stanleybak.hycreate.containers.HyCreateData load(String path) throws IOException 
	{
		Object o = XmlUtil.loadObject(path);
		com.stanleybak.hycreate.containers.HyCreateData rv;
		
		if (o instanceof containers.HyCreateData)
		{
			// do the conversion
			containers.HyCreateData old = (containers.HyCreateData)o;
			
			try
			{
				rv = (com.stanleybak.hycreate.containers.HyCreateData)convertCopy(old);
			}
			catch (Exception e)
			{
				// convert it to an I/O Exception
				throw new IOException(e);
			}
		}
		else
		{
			rv = (com.stanleybak.hycreate.containers.HyCreateData)o;
		}
		
		return rv;
	}

	public static Object convertCopy(Object from) throws Exception 
	{
	    Class<?> fromClass = from.getClass();
	    Object to = null;
	    
	    if (isBasic(fromClass))
	    {	
	    	Constructor<?> constructor = fromClass.getConstructor(fromClass);
	    	to = constructor.newInstance(from);
	    }
	    else if (fromClass.isEnum())
	    {
	    	// enum conversion
	    	Class<?> toClass = getClassConversion(fromClass);
		    int o = ((Enum<?>)from).ordinal();
		    to = toClass.getEnumConstants()[o];
	    }
	    else
	    {
	    	Class<?> toClass = getClassConversion(fromClass);
	    	
		    Constructor<?> constructor = toClass.getConstructor();
		    to = constructor.newInstance();
		    
		    for (Method setter : toClass.getMethods())
		    {
		    	if (isSetter(setter))
		    	{
		    		Method getter = findGetter(fromClass, setter);
		    		Class<?> type = setter.getParameterTypes()[0];
		    				
		    		if (isBasic(type))
					{
		    			Object val = getter.invoke(from);
		    			setter.invoke(to, val);
					}
		    		else if (type == ArrayList.class)
		    		{
		    			ParameterizedType pt = (ParameterizedType)getter.getGenericReturnType();
		    			Type t = pt.getActualTypeArguments()[0];
		    			
		    			if (t == containers.TransitionData.class)
		    			{
		    				ArrayList <com.stanleybak.hycreate.containers.TransitionData> newList = 
		    					new ArrayList <com.stanleybak.hycreate.containers.TransitionData>();
		    				
		    				copyGenericList(newList, getter, from, setter, to);
		    			}
		    			else if (t == String.class)
		    			{
		    				ArrayList <String> newList = new ArrayList <String>();
		    				
		    				copyGenericList(newList, getter, from, setter, to);
		    			}
		    			else
		    				throw new RuntimeException("Unsupport arraylist generic type: " + t);
		    		}
		    		else if (type == TreeMap.class)
		    		{
		    			// String, ModeData
		    			ParameterizedType pt = (ParameterizedType)getter.getGenericReturnType();
		    			Type[] types = pt.getActualTypeArguments();
		    			
		    			if (types[0] == String.class && types[1] == containers.ModeData.class)
		    			{
		    				TreeMap <String, com.stanleybak.hycreate.containers.ModeData> newMap = 
		    					new TreeMap <String, com.stanleybak.hycreate.containers.ModeData>();
		    			
		    				TreeMap <?, ?> oldMap = (TreeMap <?, ?>)getter.invoke(from);
		    				
		    				for (Entry<?, ?> e : oldMap.entrySet())
		    				{
		    					String s = (String)e.getKey();
		    					
		    					Object o = e.getValue();
		    					
		    					com.stanleybak.hycreate.containers.ModeData md = 
		    							(com.stanleybak.hycreate.containers.ModeData)convertCopy(o);
		    					newMap.put(s,  md);
		    				}
		    				
		    				setter.invoke(to, newMap);
		    			}
		    			else
		    				throw new RuntimeException("Unsupported TreeMap with generic types: " + 
		    						types[0] + ", " + types[1]);
		    		}
		    		else
		    		{
		    			// recursive case
		    			Object val = convertCopy(getter.invoke(from));
		    			setter.invoke(to, val);
		    		}
		    	}
		    }
	    }
	    
	    return to;
	}
	
	private static <K> void copyGenericList(ArrayList<K> newList, Method getter, 
			Object from, Method setter, Object to) throws Exception
	{
		ArrayList <?> oldList = (ArrayList<?>)getter.invoke(from);
		
		for (int i = 0; i < oldList.size(); ++i)
		{
			Object o = oldList.get(i);
			
			@SuppressWarnings("unchecked")
			K td = (K)convertCopy(o);
			
			newList.add(td);
		}
		
		setter.invoke(to, newList);
	}

	private static Class <?> getClassConversion(Class <?> from)
	{
		Class<?> conversions[][] = 
    	{
    		{containers.HyCreateData.class, com.stanleybak.hycreate.containers.HyCreateData.class},
    		{containers.TransitionData.class, com.stanleybak.hycreate.containers.TransitionData.class},
    		{containers.ModeData.class, com.stanleybak.hycreate.containers.ModeData.class},
    		{containers.ModelOptions.class, com.stanleybak.hycreate.containers.ModelOptions.class},
    		{containers.ModelPlotOptions.class, com.stanleybak.hycreate.containers.ModelPlotOptions.class},
    		{containers.ModelSimulationOptions.class, com.stanleybak.hycreate.containers.ModelSimulationOptions.class},
    		
    		// enum conversions
    		{containers.ModelOptions.AggregationMethod.class, 
    			com.stanleybak.hycreate.containers.ModelOptions.AggregationMethod.class},
    		{containers.ModelOptions.ReachabilityMethod.class, 
    			com.stanleybak.hycreate.containers.ModelOptions.ReachabilityMethod.class},
    		{containers.ModelSimulationOptions.SimulationType.class, 
    			com.stanleybak.hycreate.containers.ModelSimulationOptions.SimulationType.class},
    		{containers.ModelSimulationOptions.StartingPositionsType.class, 
        		com.stanleybak.hycreate.containers.ModelSimulationOptions.StartingPositionsType.class},
    		{containers.ModelSimulationOptions.EnumDerivativesType.class, 
            	com.stanleybak.hycreate.containers.ModelSimulationOptions.EnumDerivativesType.class},
    	};
		
		Class<?> rv = null;
		
		for (int i = 0; i < conversions.length; ++i)
		{
			if (conversions[i][0] == from)
			{
				rv = conversions[i][1];
				break;
			}
		}
		
		if (rv == null)
			throw new RuntimeException("Could not find class conversion for " + from);
		
		return rv;
	}
	
	private static Method findGetter(Class <?> c, Method m) 
	{
		Method rv = null;
		String[] names = {"get" + m.getName().substring(3), "is" + m.getName().substring(3)};
		
		for (String name : names)
		{
			for (Method m2 : c.getMethods())
			{
				if (m2.getName().equals(name))
				{
					rv = m2;
					break;
				}
			}
			
			if (rv != null)
				break;
		}
		 
		if (rv == null)
			throw new RuntimeException("Getter not found corresponding to setter: " + m.getName());
		 
		return rv;
	}

	private static boolean isSetter(Method method)
	{
		boolean rv = true;
		
		 if (!method.getName().startsWith("set")) 
			 rv = false;
		 else if (method.getParameterTypes().length != 1)
			 rv = false;
		 
		 return rv;
	}

	private static boolean isBasic(Class<?> c)
	{
		boolean rv = c.isPrimitive();
		
		if (c == String.class || c == Boolean.class || c == Character.class || c == Byte.class ||
				c == Short.class || c == Integer.class || c == Long.class || c == Float.class ||
        		c == Double.class)
			rv = true;
		
		return rv;
	}
}
