package gui.hycreate;


import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.LinkedList;

import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.stanleybak.hycreate.containers.HyCreateData;
import com.stanleybak.hycreate.containers.TransitionData;


import main.Main;

public class TransitionsPanel implements ListSelectionListener, ActionListener, 
						ModeListener, ItemListener
{	
	//////// PRIVATE GUI VARIABLES ///////////
	private HyCreateFrame parent;
	private JPanel panel;
	private JList <String> transitionList;
	private JComboBox <String> from;
	private DefaultComboBoxModel <String> fromModel;
	private JComboBox <String> to;
	private DefaultComboBoxModel <String> toModel;
	private DefaultListModel <String> listModel;
	private JButton addButton;
	private JButton removeButton;
	private JButton upButton;
	private JButton downButton;
	private JEditorPane reset;
	private JEditorPane guard;
	private JPanel transitionDataPanel;
	
	//////// PRIVATE VARIABLES /////////
	private ArrayList <TransitionData> data = new ArrayList <TransitionData>();
	int displayedListIndex = -1;
	private boolean listListenerEnabled = true;
	private boolean comboBoxListenerEnabled = true;
	
	private String GUARD_HELP = 
			"Specify the guard (enabling condition) for this transition. If the passed-in hyperrectangle\n" +
			"could take this transition (one of the points inside the hyperrectangle could take the\n" +
			"transition), the guard method should return true. The format is Java code, which will be\n" +
			"placed inside a method. To refer to dimension values of the input hyperrectangle, use\n" +
			"$DIM_NAME.min or $DIM_NAME.max and they will be replaced by the corresponding code.\n\n" +
			"For example, if the transition can be taken only when the temperature is less than 50,\n" +
			"the following could be entered:\n" +
			"return $TEMPERATURE.min < 50;";
	
	private String RESET_HELP = 
			"The reset action, which is applied to a hyperrectangle when the transition is taken. This can\n" +
			"be used to help eliminate error from pessimism in the guard condition. The format is Java code,\n" +
			"which will be placed inside a method. To refer to dimension values of the input hyperrectangle,\n" +
			"use $DIM_NAME.min or $DIM_NAME.max and they will be replaced by\n" +
			"the corresponding code.\n\n" + 
			"For example, you can reset the temperature variable to exactly 50 by entering:\n" +
			"$TEMPERATURE.min = $TEMPERATURE.max = 50;";
	
	public TransitionsPanel(HyCreateFrame parent)
	{
		this.parent = parent;
		
		panel = new JPanel();	
		panel.setLayout(new GridLayout(1,1));
		
		JPanel left = makeLeftPanel();
		JPanel right = makeDataPanel();
		JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, left, right);
		split.setOneTouchExpandable(true);
		split.setContinuousLayout(true);
		
		panel.add(split);
		
		HyCreateFrame.setEnabled(right, false);
		parent.addModeListener(this);
	}
	
	private JPanel makeDataPanel()
	{
		/*
		 * <-- JPanel (connections) -->
		 * <-- JPanel (guard)       -->
		 * <-- JPanel (reset)       -->
		 */
		
		transitionDataPanel = new JPanel();
		transitionDataPanel.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.BOTH; c.weighty = 0; c.weightx = 1; c.gridx = 0; c.gridy = 0;
		
		transitionDataPanel.add(makeConnectionsPanel(), c);
	
		c.weighty = 0.5; c.gridy = 1;
		guard = new JEditorPane();
		transitionDataPanel.add(parent.createCodePanel(guard, 
				TransitionData.DEFAULT_GUARD, "Guard Condition", GUARD_HELP), c);
		
		c.gridy = 2;
		reset = new JEditorPane();
		transitionDataPanel.add(parent.createCodePanel(reset, 
				TransitionData.DEFAULT_RESET, "Reset Action", RESET_HELP), c);
		
		return transitionDataPanel;
	}
	
	private JPanel makeConnectionsPanel()
	{
		JPanel p = new JPanel();
		p.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.insets = new Insets(5,20,5,20);
		
		c.fill = GridBagConstraints.BOTH;c.gridx = 0; c.gridy = 0; c.weightx = 0;
		p.add(new JLabel("From:", SwingConstants.RIGHT), c);
		
		c.gridx = 1; c.gridy = 0; c.weightx = 1;
		fromModel = new DefaultComboBoxModel <String>();
		from = new JComboBox <String>(fromModel);
		from.addItemListener(this);
		p.add(from, c);
		
		c.gridx = 0; c.gridy = 1; c.weightx = 0;
		p.add(new JLabel("To:", SwingConstants.RIGHT), c);
		
		c.gridx = 1; c.gridy = 1; c.weightx = 1;
		toModel = new DefaultComboBoxModel <String>();
		to = new JComboBox <String>(toModel);
		to.addItemListener(this);
		p.add(to, c);
		
		return HyCreateFrame.addFrame("Connection", p);
	}

	private JPanel makeLeftPanel()
	{
		JPanel left = new JPanel();
		
		left.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = 0; c.gridy = 0; c.fill = GridBagConstraints.BOTH;
		c.gridwidth = 2; c.weightx = 1.0; c.weighty = 1.0;
		
		listModel = new DefaultListModel <String>();
		
		transitionList = new JList <String>(listModel);
		transitionList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		transitionList.addListSelectionListener(this);
		JScrollPane sp = new JScrollPane(transitionList);
		JPanel scrollPanel = HyCreateFrame.addFrame("Transitions", sp, 0);
		//scrollPanel.setBorder(BorderFactory.createEmptyBorder(15,15,15,0));

		left.add(scrollPanel, c);
		
		c.gridwidth = 1; c.weightx = 0.5; c.weighty = 0; 
		c.gridy = 1; c.gridx = 0; c.anchor = GridBagConstraints.CENTER;
		c.insets = new Insets(3,15,3,15);
		addButton = new JButton("New");
		addButton.addActionListener(this);
		left.add(addButton, c);
		
		c.gridy = 2; c.gridx = 0;
		removeButton = new JButton("Delete");
		removeButton.addActionListener(this);
		left.add(removeButton, c);
		
		c.gridy = 1; c.gridx = 1;
		upButton = new JButton("Move Up");
		upButton.addActionListener(this);
		left.add(upButton, c);
		
		c.gridy = 2; c.gridx = 1;
		downButton = new JButton("Move Down");
		downButton.addActionListener(this);
		left.add(downButton, c);
		
		return left;
	}
	
	/////////// PUBLIC METHODS BELOW //////////
	
	public JPanel getPanel()
	{
		return panel;
	}
	
	public void importFrom(HyCreateData data)
	{
		transitionList.clearSelection();
				
		listListenerEnabled = false;
		comboBoxListenerEnabled = false;
		
		this.data = data.getTransitions();
		listModel.clear();
		
		for (TransitionData t : this.data)
			listModel.addElement(t.toString());

		listListenerEnabled = true;
		comboBoxListenerEnabled = true;
		
		transitionList.setSelectedIndex(data.getSelectedTransition());
	}

	public void exportTo(HyCreateData data)
	{
		guiToData(transitionList.getSelectedIndex());
		
		data.setTransitions(this.data);
		data.setSelectedTransition(transitionList.getSelectedIndex());
	}
	
	///////// PRIVATE METHODS BELOW ////////////	
	private void addPressed(LinkedList<String> modes)
	{
		Object[] choices = modes.toArray();
		
		String from = (String)JOptionPane.showInputDialog(panel, "Add transition from which mode?",
				"Add Transition", JOptionPane.QUESTION_MESSAGE, null, choices, null);
		
		if (from != null)
		{
			String to = (String)JOptionPane.showInputDialog(panel, 
					"Add transition from '" + from + "' to which mode?",
					"Add Transition", JOptionPane.QUESTION_MESSAGE, null, choices, null);
			
			if (to != null)
				addTransition(new TransitionData(from, to));
		}
	}
	
	private void transitionsModified()
	{
		parent.setModified(true);
	}
	
	private void addTransition(TransitionData d)
	{
		data.add(d);
		listModel.addElement(d.toString());
		transitionList.setSelectedIndex(data.size() - 1);
		
		transitionList.revalidate();
		transitionList.repaint();
		
		transitionsModified();
	}
	
	private void guiToData(int dataIndex)
	{
		if (dataIndex != -1)
		{
			TransitionData d = data.get(dataIndex);
			
			d.setFrom((String)from.getSelectedItem());
			d.setTo((String)to.getSelectedItem());
			
			d.setGuard(guard.getText());
			d.setReset (reset.getText());
		}
	}

	private void dataToGui(int dataIndex)
	{
		if (dataIndex == -1)
		{
			from.setSelectedItem(null);
			to.setSelectedItem(null);
			
			guard.setText(" ");
			reset.setText(" ");
		}
		else
		{
			TransitionData td = data.get(dataIndex);
			
			from.setSelectedItem(td.getFrom());
			to.setSelectedItem(td.getTo());
			
			if (!to.getSelectedItem().equals(td.getTo()) || 
					!from.getSelectedItem().equals(td.getFrom()))
				throw new RuntimeException("data to gui called with nonexistent mode in data");
			
			guard.setText(td.getGuard());
			reset.setText(td.getReset());
		}
	}
	
	////////// EVENT LISTENERS BELOW //////////

	@Override
	public void valueChanged(ListSelectionEvent e)
	{
		if (listListenerEnabled)
		{
			int index = transitionList.getSelectedIndex();
			
			if (index != displayedListIndex)
			{
				parent.setDocumentListenerState(false);
	
				// save old index from gui
				guiToData(displayedListIndex);
				
				displayedListIndex = index;
				
				// load new index into gui
				dataToGui(index);
				
				HyCreateFrame.setEnabled(transitionDataPanel, index != -1);
				
				parent.setDocumentListenerState(true);
			}
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == addButton)
		{
			LinkedList <String> modes = parent.getModes();
			
			if (modes.size() == 0)
				Main.error("You must add some discrete modes before adding transitions.");
			else
				addPressed(modes);
		}
		else if (e.getSource() == removeButton)
		{
			int i = transitionList.getSelectedIndex();
			
			if (i != -1)
			{
				// remove element i
				
				listModel.remove(i);
				data.remove(i);
				
				if (i < listModel.size())
					transitionList.setSelectedIndex(i);
				else if (listModel.size() > 0)
					transitionList.setSelectedIndex(listModel.getSize() - 1);
				
				transitionsModified();
			}
			else
				Main.error("Please select a transition to remove.");
		}
		else if (e.getSource() == upButton)
		{
			int i = transitionList.getSelectedIndex();
			
			if (i != -1 && i != 0)
			{
				int aboveIndex = i - 1;
				
				guiToData(i);
				
				// swap in listModel and in data
				TransitionData d = data.get(i);
				TransitionData aboveData = data.get(aboveIndex);
				
				data.set(i, aboveData);
				data.set(aboveIndex, d);
				
				listModel.set(aboveIndex, d.toString());
				listModel.set(i, aboveData.toString());
				
				listListenerEnabled = false; // we don't want it to overwrite what we did
				transitionList.setSelectedIndex(aboveIndex);
				displayedListIndex = aboveIndex; // set manually since listener is off
				listListenerEnabled = true;
			}
			else
				Main.error("Please select a transition which can move up in the list.");
		}
		else if (e.getSource() == downButton)
		{
			int i = transitionList.getSelectedIndex();
			
			if (i != -1 && i != listModel.size() - 1)
			{
				int belowIndex = i + 1;
				
				guiToData(i);

				// swap in listModel and in data
				TransitionData d = data.get(i);
				TransitionData belowData = data.get(belowIndex);

				data.set(belowIndex, d);
				data.set(i, belowData);
				
				listModel.set(belowIndex, d.toString());
				listModel.set(i, belowData.toString());
				
				listListenerEnabled = false; // we don't want it to overwrite what we did
				transitionList.setSelectedIndex(belowIndex);
				displayedListIndex = belowIndex; // set manually since listener is off
				listListenerEnabled = true;
			}
			else
				Main.error("Please select a transition which can move down in the list.");
		}
	}

	@Override
	public void modesUpdated(LinkedList<String> modeNames)
	{
		comboBoxListenerEnabled = false;

		int listIndex = transitionList.getSelectedIndex();
		guiToData(listIndex);
		
		// clear selected index to prevent gui updates when removing transitions
		transitionList.clearSelection();
		
		fromModel.removeAllElements();
		toModel.removeAllElements();
		
		for (String s : modeNames)
		{
			fromModel.addElement(s);
			toModel.addElement(s);
		}
		
		// remove transitions from modes that no longer exist
		for (int i = 0; i < data.size(); /* increment in loop */)
		{
			TransitionData d = data.get(i);
			
			if (!modeNames.contains(d.getFrom()) || !modeNames.contains(d.getTo()))
			{	
				// must remove from list model before data, since it may cause
				// a change in the selected index which may be written back to data
				listModel.remove(i); 
				data.remove(i);
			}
			else
				++i;
		}
		
		// reload from GUI
		if (displayedListIndex != -1)
			dataToGui(displayedListIndex);
		
		from.revalidate();
		from.repaint();
		
		to.revalidate();
		to.repaint();
		
		comboBoxListenerEnabled = true;
	}

	@Override
	public void modeRenamed(String from, String to)
	{
		int listIndex = transitionList.getSelectedIndex();
		guiToData(listIndex);
		
		for (int i = 0; i < data.size(); ++i)
		{
			TransitionData d = data.get(i);
			boolean renamed = false;
			
			if (from.equals(d.getFrom()))
			{
				d.setFrom(to);
				renamed = true;
			}
			
			if (from.equals(d.getTo()))
			{
				d.setTo(to);
				renamed = true;
			}
			
			if (renamed)
			{
				listModel.setElementAt(d.toString(), i);
				
				if (i == displayedListIndex)
					dataToGui(i);
			}
		}
		
		if (transitionList.getSelectedIndex() == -1)
		{
			this.to.setSelectedItem(null);
			this.from.setSelectedItem(null);
		}
		
		transitionList.repaint();
	}

	@Override
	public void itemStateChanged(ItemEvent e)
	{
		if (comboBoxListenerEnabled)
		{
			JComboBox <String> b = from;
			
			if (e.getSource() == to)
				b = to;

			int comboBoxIndex = b.getSelectedIndex();
			int listIndex = transitionList.getSelectedIndex();
			
			// Combo Box Changed, rename in data and list
			
			if (comboBoxIndex != -1 && listIndex != -1)
			{
				String listString = (String)listModel.getElementAt(listIndex);
				TransitionData d = data.get(listIndex);
				
				if (e.getSource() == from)
					d.setFrom((String)from.getSelectedItem());
				else
					d.setTo((String)to.getSelectedItem());
				
				String newString = data.get(listIndex).toString();
				
				if (!listString.equals(newString))
				{
					listModel.setElementAt(newString, listIndex);
					
					transitionsModified(); // will call parent.setEnabled(true);
				}
			}
		}
	}
}
