package gui.partial;

import java.awt.Graphics2D;

public abstract class ComputeEvent
{
	public abstract String getEventName();
	public abstract void draw(Graphics2D g, PartialPanel parent, 
			boolean isBeingDrawn, boolean isSelected);
}
