package gui.partial;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;

import reachability.geometry.HyperRectangleTime;

public class ContinuousSuccessors extends ComputeEvent
{
	// private constants
	private final Stroke thin = new BasicStroke(0.75f);
	private final Stroke med = new BasicStroke(1.5f);
	
	private String modeName;
	public ArrayList <Point> points = new ArrayList <Point>();
	Collection <HyperRectangleTime> init;
	public LinkedList <DiscreteTransition> successors = new LinkedList <DiscreteTransition>();

	private ArrayList<Double> piSim;
	private double[] piSlope;
	
	private final static Color colors[] = 
	{
		Color.green,
		Color.blue,
		Color.orange,
		Color.lightGray,
		Color.magenta,
		Color.gray,
		Color.cyan,
		Color.darkGray
	};
	
	private static ArrayList <String> modeColorIndex = new ArrayList <String>(); 
	
	public ContinuousSuccessors(String modeName, Collection <HyperRectangleTime> init)
	{
		this.modeName = modeName;
		this.init = init;
	}

	public static void reset()
	{
		modeColorIndex.clear();
	}
	
	public static Color getModeColor(String modeName)
	{
		int index;
		
		for (index = 0; index < modeColorIndex.size(); ++index)
		{
			if (modeColorIndex.get(index).equals(modeName))
				break;
		}
		
		if (index == modeColorIndex.size())
		{
			// not found
			modeColorIndex.add(modeName);
		}
		
		return colors[index % colors.length];
	}
	
	@Override
	public void draw(Graphics2D g, PartialPanel parent, 
			boolean isBeingDrawn, boolean isSelected)
	{
		double widthPerBox = (double)parent.getWidth() / parent.outputWidth;
		double heightPerBox = (double)parent.getHeight() / parent.outputHeight;
		double startX = 0;
		double startY = parent.getHeight() - heightPerBox;
		
		g.setColor(getModeColor(modeName));
		
		for (int i = 0; i < points.size(); ++i)
		{
			Point p = points.get(i);
			
			// draw a rect corresponding to this one
			double x = startX + widthPerBox * p.x;
			double y = startY - heightPerBox * p.y;
			
			Rectangle2D.Double rect = new Rectangle2D.Double(x, y, widthPerBox, heightPerBox);
			
			g.fill(rect);
		}
		
		if (isSelected)
		{
			drawInit(g, parent);
			drawTransitions(g, parent);
			drawPi(g, parent);
		}
	}

	private void drawPi(Graphics2D g, PartialPanel parent)
	{
		if (piSim != null)
		{
			g.setColor(Color.orange);
			g.setStroke(med);
			
			for (int i = 1; i < piSim.size(); ++i)
			{
				Point2D.Double prev = piSim.get(i - 1);
				Point2D.Double cur = piSim.get(i);
				
				Point2D.Double prevDraw = parent.convertToDrawPoint(prev);
				Point2D.Double curDraw = parent.convertToDrawPoint(cur);
				
				g.draw(new Line2D.Double(prevDraw, curDraw));
			}
			
			// draw the line
			g.setStroke(thin);
			
			Point2D.Double anchor = piSim.get(piSim.size() - 1);
			
			double len = (parent.xRange[1] - parent.xRange[0]) + (parent.yRange[1] - parent.yRange[0]);
			len *= 2;
			
			Point2D.Double one = new Point2D.Double(anchor.x + piSlope[0] * len, anchor.y + piSlope[1] * len);
			Point2D.Double two = new Point2D.Double(anchor.x + piSlope[0] * -len, anchor.y + piSlope[1] * -len);
			
			g.draw(new Line2D.Double(parent.convertToDrawPoint(one), parent.convertToDrawPoint(two)));
		}
	}

	private void drawInit(Graphics2D g, PartialPanel parent)
	{
		g.setColor(Color.blue);
		g.setStroke(thin);
		
		for (HyperRectangleTime hr : init)
		{
			Shape drawRect = parent.convertToDrawRect(hr.rect);
			
			g.draw(drawRect);
		}
	}

	private void drawTransitions(Graphics2D g, PartialPanel parent)
	{
		g.setStroke(thin);
		
		for (DiscreteTransition t : successors)
		{
			Rectangle2D.Double from = parent.convertToDrawRect(t.from);
			Rectangle2D.Double to = parent.convertToDrawRect(t.to);
			
			g.setColor(Color.orange);
			g.setStroke(PartialPanel.dotted);
			g.draw(new Line2D.Double(center(from), center(to)));
			
			g.setStroke(thin);
			g.setColor(Color.magenta);
			g.fill(from);
			
			g.setColor(Color.orange);
			g.fill(to);
		}
	}

	private Point2D.Double center(Rectangle2D.Double r)
	{
		Point2D.Double rv = new Point2D.Double();
		rv.x = r.x + r.width / 2;
		rv.y = r.y + r.height / 2;
		
		return rv;
	}

	@Override
	public String getEventName()
	{
		return modeName + " (Continuous Post) - " + init.size() + " init rects";
	}

	public void setPseudoInvariant(ArrayList <Point2D.Double> sim, double[] gradient)
	{
		this.piSim = sim;
		
		normalize(gradient);
		this.piSlope = new double[] {gradient[1], -gradient[0]};
	}

	private void normalize(double[] gradient)
	{
		double dist = Math.sqrt(gradient[0] * gradient[0] + gradient[1] + gradient[1]);
		
		if (dist > 0)
		{
			gradient[0] /= dist;
			gradient[1] /= dist;
		}
	}
}
