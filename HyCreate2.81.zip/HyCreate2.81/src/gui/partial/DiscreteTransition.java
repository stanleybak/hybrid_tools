package gui.partial;

import reachability.geometry.HyperRectangle;

public class DiscreteTransition
{
	HyperRectangle from;
	HyperRectangle to;
	
	public DiscreteTransition(HyperRectangle from, HyperRectangle to)
	{
		this.from = from;
		this.to = to;
	}
}
