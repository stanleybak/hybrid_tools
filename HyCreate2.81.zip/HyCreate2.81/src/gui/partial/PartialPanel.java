package gui.partial;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;

import javax.swing.JPanel;

import reachability.geometry.HyperRectangle;
import reachability.geometry.HyperRectangleTime;
import reachability.geometry.Interval;

@SuppressWarnings("serial")
public class PartialPanel extends JPanel
{
	boolean computationDone = false;
	PartialResultsVisualizerFrame parent;
	
	private Collection <ArrayList <Point2D.Double>> simulations = 
			new LinkedList <ArrayList <Point2D.Double>>();
	
	private ArrayList <ComputeEvent> computeEvents = new ArrayList <ComputeEvent>();

	private LinkedList <HyperRectangle> trackedRects = new LinkedList <HyperRectangle>();
	
	double[] xRange;
	double[] yRange;
	double[] step;
	private int[] dimIndex;
	int outputWidth;
	int outputHeight;
	
	Stroke simulationStroke = new BasicStroke(1);
	
    final static BasicStroke dotted =
        new BasicStroke(0.5f,
                        BasicStroke.CAP_BUTT,
                        BasicStroke.JOIN_MITER,
                        10.0f, new float[]{2.0f, 3.0f}, 0.0f);
	
	public PartialPanel(PartialResultsVisualizerFrame parent, int resultWidth, int resultHeight)
	{
		setPreferredSize(new Dimension(640, 480));
		
		outputWidth = resultWidth;
		outputHeight = resultHeight;
		
		this.parent = parent;
	}
	
	public synchronized void clear()
	{
		computationDone = false;
		
		simulations.clear();
		computeEvents.clear();
		
		repaint();
	}
	
	@Override
	protected void paintComponent(Graphics graphics)
	{
		Graphics2D g = (Graphics2D)graphics;
		setupDrawing(g);
		
		if (xRange != null && yRange != null && dimIndex != null)
		{
			
			synchronized (this)
			{
				drawPartialResult(g);
				
				if (simulations != null)
					drawSimulations(g);
				
				if (computationDone == false && trackedRects != null)
					drawTrackedRects(g);
			}
		}
		
	}

	private void drawTrackedRects(Graphics2D g)
	{
		g.setColor(Color.red);
		g.setStroke(simulationStroke);
		
		for (HyperRectangle r : trackedRects)
		{
			Shape drawRect = convertToDrawRect(r);
			g.fill(drawRect);
		}
	}

	private void drawSimulations(Graphics2D g)
	{
		g.setColor(Color.black);
		
		for (ArrayList <Point2D.Double> sim : simulations)
		{
			Point2D.Double last = null;
			boolean didDiscreteTransition = false;
			
			for (Point2D.Double p : sim)
			{
				if (p == null)
					didDiscreteTransition = true;
				else
				{
					Point2D.Double drawPoint = convertToDrawPoint(p);
					
					if (last != null)
					{
						if (didDiscreteTransition)
							g.setStroke(dotted);
						
						g.draw(new Line2D.Double(last, drawPoint));
						
						if (didDiscreteTransition)
						{
							g.setStroke(simulationStroke);
							didDiscreteTransition = false;
						}
					}
					
					last = drawPoint;
				}
			}
		}
	}

	public Point2D.Double convertToDrawPoint(Point2D.Double p)
	{
		Point2D.Double rv = new Point2D.Double();
		
		double width = (double)getWidth();
		double height = (double)getHeight();

		double unitsPerX = (xRange[1] - xRange[0]) / width;
		double unitsPerY = (yRange[1] - yRange[0]) / height;
		
		double xAfterOffset = p.x - xRange[0];
		double yAfterOffset = p.y - yRange[0];
	
		rv.x = xAfterOffset / unitsPerX;
		rv.y = height - (yAfterOffset / unitsPerY);
		
		return rv;
	}

	private void drawPartialResult(Graphics2D g)
	{
		int selectedIndex = parent.eventList.getSelectedIndex();
		
		ContinuousSuccessors.reset();
		
		for (int i = 0; i < computeEvents.size(); ++i)
		{
			ComputeEvent event = computeEvents.get(i);
			boolean isBeingDrawn = !computationDone && i == computeEvents.size() - 1;
			boolean isSelected = parent.eventList.getSelectedIndex() == i;
			
			event.draw(g, this, isBeingDrawn, isSelected);
			
			if (i == selectedIndex)
				break;
		}
	}

	private void setupDrawing(Graphics2D g)
	{
		// Enable Anti-Aliasing
		g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);   
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		
		Dimension size = getSize();
		g.setColor(Color.white);
		g.fillRect(0,0,size.width,size.height);
		g.setColor(Color.black);
	}

	public void setXRange(double min, double max)
	{
		xRange = new double[] {min, max};
	}
	
	public void setYRange(double min, double max)
	{
		yRange = new double[] {min, max};
	}
	
	public void setDimIndex(int x, int y)
	{
		dimIndex = new int[] {x, y};
	}

	public synchronized void flushPoints(ArrayList<Point> pointBuffer)
	{
		int lastIndex = computeEvents.size() - 1;
		ContinuousSuccessors event = (ContinuousSuccessors)computeEvents.get(lastIndex);
		
		event.points.addAll(pointBuffer);
		repaint();
	}

	public synchronized void flushSimulationPoints(ArrayList<Point2D.Double> simPoints)
	{
		simPoints.trimToSize();
		
		simulations.add(simPoints);
		
		repaint();
	}

	public synchronized void setCurMode(String name, LinkedList<HyperRectangleTime> initStates)
	{
		ContinuousSuccessors c = new ContinuousSuccessors(name, initStates);
		
		computeEvents.add(c);
		
		parent.addEvent(c.getEventName());
	}

	public synchronized void addTransition(HyperRectangle from, HyperRectangle to)
	{
		int lastIndex = computeEvents.size() - 1;
		ContinuousSuccessors event = (ContinuousSuccessors)computeEvents.get(lastIndex);
		
		event.successors.add(new DiscreteTransition(from, to));
	}

	/**
	 * Convert a hyperrectangle to the coordinates where it needs to be drawn
	 * @param rect the hyperrect
	 * @return the rect to draw
	 */
	public Rectangle2D.Double convertToDrawRect(HyperRectangle rect)
	{
		Rectangle2D.Double rv = new Rectangle2D.Double();
		
		Interval x = rect.dims[dimIndex[0]];
		Interval y = rect.dims[dimIndex[1]];
		
		Point2D.Double topLeft = convertToDrawPoint(new Point2D.Double(x.min, y.min));
		Point2D.Double bottomRight = convertToDrawPoint(new Point2D.Double(x.max, y.max));
		
		rv.x = topLeft.x;
		rv.y = bottomRight.y;
		rv.width = bottomRight.x - topLeft.x;
		rv.height = topLeft.y - bottomRight.y;
		
		return rv;
	}

	public synchronized void computationDone()
	{
		computationDone = true;
		repaint();
	}

	public synchronized void addPseudoInvariant(ArrayList <Point2D.Double> sim, double[] gradient)
	{
			int lastIndex = computeEvents.size() - 1;
			ContinuousSuccessors event = (ContinuousSuccessors)computeEvents.get(lastIndex);
			
			event.setPseudoInvariant(sim, gradient);
			repaint();
	}

	public synchronized void setCurRects(LinkedList<HyperRectangle> curRects)
	{
		trackedRects = curRects;
		
		repaint();
	}
}
