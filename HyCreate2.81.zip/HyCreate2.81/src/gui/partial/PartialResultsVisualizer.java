package gui.partial;

import com.stanleybak.hycreate.containers.ReachParams;

import compiler.CompilationException;
import compiler.CompileThread;

public class PartialResultsVisualizer
{
	private static PartialResultsVisualizerFrame frame;

	/**
	 * Begin trying to show the visualizer. This initially will hide it until a change in the
	 * results files is detected.
	 * @param parent for frame placement and output printing
	 * @param reachParams the settings for the visualization, also port will get set
	 * @throws CompilationException if the partial results directory doesn't exist
	 */
	public static void begin(CompileThread parent, ReachParams reachParams) 
			throws CompilationException
	{
		if (frame != null)
		{
			if (frame.isVisible())
				frame.clear(); // reuse existing frame
			else
			{
				frame.dispose();
				frame = null;
			}
		}
			
		if (frame == null)
			frame = new PartialResultsVisualizerFrame(parent, reachParams);
		
		reachParams.visualizerPort = frame.listenPort;
	}

	public static void hideIfVisible()
	{
		if (frame != null && frame.isVisible())
		{
			frame.setVisible(false);
			frame.dispose();
		}
		
		frame = null;
	}
}
