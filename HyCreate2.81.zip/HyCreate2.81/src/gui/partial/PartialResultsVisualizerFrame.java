package gui.partial;

import gui.hycreate.HyCreateFrame;

import java.awt.BorderLayout;
import java.awt.Point;
import java.awt.geom.Point2D;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.LinkedList;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.stanleybak.hycreate.containers.ReachParams;

import reachability.geometry.HyperRectangle;
import reachability.geometry.HyperRectangleTime;
import reachability.geometry.Interval;

import compiler.CompilationException;
import compiler.CompileThread;


@SuppressWarnings("serial")
public class PartialResultsVisualizerFrame extends JFrame implements ListSelectionListener 
{
	CompileThread parent;
	public int listenPort = 0;
	private boolean guiMade = false;
	JList <String> eventList = null;
	DefaultListModel <String> eventListModel = new DefaultListModel <String>();
	private PartialPanel panel = null;

	/**
	 * Create a new results visualizer frame
	 * @param parent the parent, for initial location and error printing
	 * @param params the settings for the reachability computation
	 * @throws CompilationException if a socket error occurs
	 */
	public PartialResultsVisualizerFrame(final CompileThread compileThread, final ReachParams params) 
			throws CompilationException
	{
		this.parent = compileThread;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		SwingUtilities.invokeLater(
		new Runnable(){
			public void run()
			{
				makeGui(compileThread.parent, params.visualizeWidth, params.visualizeHeight);						
			}
		});
		
		// start the polling thread
		SocketThread st = new SocketThread(this);
		listenPort = st.openListenSocket();
		
		while (!guiMade)
		{
			try { Thread.sleep(10); } catch (InterruptedException e){}
		}
		
		setVisible(true);

		// start the thread after we've visible, since being invisible is a condition for
		// the thread to exit
		st.start(); 
	}
	
	public void clear() throws CompilationException
	{
		panel.clear();
		eventListModel.clear();
		
		// start the polling thread
		SocketThread st = new SocketThread(this);
		listenPort = st.openListenSocket();
		
		st.start();
		
		repaint();
	}
	

	protected void makeGui(HyCreateFrame parent, int visW, int visH)
	{
		JFrame frame = parent.frame;
		setTitle("Intermediate Computation Visualizer");
		
		getContentPane().setLayout(new BorderLayout());
		eventList = new JList <String>(eventListModel);
		eventList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		eventList.getSelectionModel().addListSelectionListener(this);
		
		JScrollPane pane = new JScrollPane(eventList);
		
		panel = new PartialPanel(this, visW, visH);
		
		panel.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));
		
		JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
				pane, panel);
		splitPane.setOneTouchExpandable(true);
		splitPane.setDividerLocation(200);
		
		getContentPane().add(splitPane, BorderLayout.CENTER);
		
		pack();
		int w = getWidth();
		int h = getHeight();
		
		int posX = frame.getX() + frame.getWidth() / 2 - w / 2;
		int posY = frame.getY() + frame.getHeight() / 2 - h / 2;
		this.setLocation(posX,  posY);
		
		guiMade = true;
	}

	private class SocketThread extends Thread
	{
		private PartialResultsVisualizerFrame parent = null;
		private ServerSocket serverSocket = null;
		private Socket clientSocket = null;     
		private BufferedReader csReader = null; // client socket reader
		
		public SocketThread(PartialResultsVisualizerFrame parent)
		{
			this.parent = parent;
		}
		
		/**
		 * Open a socket to listen for the data from the computation process
		 * @return the port number we're listening on
		 */
		public int openListenSocket() throws CompilationException
		{
			int rv = 0;
			
			try
			{
				// choose any available port
				serverSocket = new ServerSocket(0, 0, InetAddress.getByName(null)); 
				rv = serverSocket.getLocalPort();
			}
			catch (IOException e)
			{
				throw new CompilationException("Opening partial result visualzer server socket: " + e);
			}
			
			return rv;
		}
		
		public void run()
		{
			if (serverSocket == null)
				throw new RuntimeException("openListenSocket must be called before thread is started");
			
			try
			{
				// so it's not infinitely blocking
				serverSocket.setSoTimeout(50);
				
				while (true)
				{
					// poll it
					try
					{
						clientSocket = serverSocket.accept();
						
						break;
					}
					catch (SocketTimeoutException e)
					{
						// check if gui was closed, otherwise poll again
						if (!parent.isVisible())
							break;
					}
				};
				
				if (clientSocket != null)
				{
					csReader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
					ArrayList<Point> pointBuffer = null;
					ArrayList<Point2D.Double> simPointBuffer = null;
					String line = null;
					HyperRectangle transitionStart = null;
					LinkedList <HyperRectangle> curRects = null;
					
					for (line = csReader.readLine(); line != null; line = csReader.readLine())
					{
						if (!parent.isVisible())
							break;
						
						if (line.equals("end,"))
						{
							panel.computationDone();
							break;
						}
						
						if (!line.endsWith(","))
						{
							// line was not completed
							parent.parent.addOutput("Warning: Line was not completed " +
									"in partial results viewer; ignoring");
							continue;
						}
						
						String[] parts = line.split(",");
						
						if (parts.length == 3 && parts[0].equals("xRange"))
							panel.setXRange(Double.parseDouble(parts[1]), Double.parseDouble(parts[2]));
						else if (parts.length == 3 && parts[0].equals("yRange"))
							panel.setYRange(Double.parseDouble(parts[1]), Double.parseDouble(parts[2]));
						else if (parts.length == 3 && parts[0].equals("dim"))
							panel.setDimIndex(Integer.parseInt(parts[1]), Integer.parseInt(parts[2]));
						else if (parts.length == 5 && parts[0].equals("mode"))
						{
							// mode , name, numDims, count, <semicolon list of rects>
							gotMode(parts);
						}
						else if (parts.length == 3 && parts[0].equals("pt"))
						{
							if (pointBuffer == null)
								pointBuffer = new ArrayList<Point>();
							
							pointBuffer.add(new Point(Integer.parseInt(parts[1]), Integer.parseInt(parts[2])));
						}
						else if (parts.length == 1 && parts[0].equals("flush"))
						{
							panel.flushPoints(pointBuffer);
							pointBuffer = null;
						}
						else if (parts.length == 3 && parts[0].equals("simpt"))
						{
							if (simPointBuffer == null)
								simPointBuffer = new ArrayList<Point2D.Double>();
							
							simPointBuffer.add(new Point2D.Double(
									Double.parseDouble(parts[1]), 
									Double.parseDouble(parts[2])));
						}
						else if (parts.length == 2 && parts[0].equals("simpt") && 
								parts[1].equals("null"))
						{
							if (simPointBuffer == null)
								simPointBuffer = new ArrayList<Point2D.Double>();
							
							simPointBuffer.add(null);
						}
						else if (parts.length == 1 && parts[0].equals("simflush"))
						{
							panel.flushSimulationPoints(simPointBuffer);
							simPointBuffer = null;
						}
						else if (parts.length > 1 && parts[0].equals("presucc"))
						{
							transitionStart = parseHr(parts, 1);
						}
						else if (parts.length > 1 && parts[0].equals("postsucc"))
						{
							HyperRectangle transitionEnd = parseHr(parts, 1);
							
							if (transitionStart != null && transitionEnd != null)
								panel.addTransition(transitionStart, transitionEnd);
						}
						else if (parts.length > 3 && parts[0].equals("pi2"))
						{
							int simLength = Integer.parseInt(parts[1]);
							
							if (parts.length != 2 + 2 * simLength + 2)
								parent.parent.addOutput("Warning: length is wrong for visualization of pi2");
							else
							{
								ArrayList <Point2D.Double> sim = parseSimulation(parts, 2, simLength);
								
								double dx = Double.parseDouble(parts[2+2*sim.size()]);
								double dy = Double.parseDouble(parts[2+2*sim.size() + 1]);
								
								double[] gradient = {dx, dy};
								panel.addPseudoInvariant(sim, gradient);
							}
						}
						else if (parts.length > 1 && parts[0].equals("cur"))
						{
							HyperRectangle rect = parseHr(parts, 1);
							
							if (curRects == null)
								curRects = new LinkedList <HyperRectangle>();
							
							curRects.add(rect);
						}
						else if (parts.length == 1 && parts[0].equals("curdone"))
						{
							panel.setCurRects(curRects);
							
							curRects = null;
						}
						else
						{
							parent.parent.addOutput("Warning: Partial Result Visualizer Socket " +
									"got unknown command '" + parts[0] + "'(len=" + parts.length 
									+ "); received line : " + line);
						}
					}
					
					if (line == null)
						parent.parent.addOutput("Warning: Partial Result Visualizer socket closed unexpectedly");
				}
			}
			catch (IOException e)
			{
				parent.parent.addOutput("Warning: Partial Result Visualizer Socket Error: " + e);
				clientSocket = null;
			}
			
			try
			{
				if (clientSocket != null)
					clientSocket.close();
			}
			catch (IOException e)
			{
				parent.parent.addOutput("Warning: Partial Result Visualizer Socket Error: " + e);
			}
			
			try
			{
				serverSocket.close();
			}
			catch (IOException e)
			{
				parent.parent.addOutput("Warning: Partial Result Visualizer Server Socket Error: " + e);
			}
		}

		private ArrayList <Point2D.Double> parseSimulation(String[] parts, int startIndex, 
				int simLength)
		{
			ArrayList <Point2D.Double> rv = new ArrayList <Point2D.Double>();
			
			for (int i = 0; i < simLength; ++i)
			{
				int xIndex = startIndex + 2*i;
				int yIndex = xIndex + 1;
				
				double x = Double.parseDouble(parts[xIndex]);
				double y = Double.parseDouble(parts[yIndex]);
				
				Point2D.Double p = new Point2D.Double(x, y);
				rv.add(p);
			}
			
			return rv;
		}

		/**
		 * Parse a hyperrectangle from a series of strings
		 * @param parts the min/max for each dimension, in order
		 * @param startIndex the index to start at
		 * @return the constructed hyperrectangle, or null if errors occured
		 */
		private HyperRectangle parseHr(String[] parts, int startIndex)
		{
			int numDims = (parts.length - startIndex) / 2;
			HyperRectangle rv = new HyperRectangle(numDims);
			
			for (int d = 0; d < numDims; ++d)
			{
				int index = startIndex + d * 2;
				
				try
				{
					double min = Double.parseDouble(parts[index]);
					double max = Double.parseDouble(parts[index + 1]);
					
					rv.dims[d] = new Interval(min, max);
				}
				catch (NumberFormatException e)
				{
					System.out.println("Error parsing HyperRectangle: " + e);
					rv = null;
					break;
				}
			}
			
			return rv;
		}

		private void gotMode(String[] parts)
		{
			// mode , name, numDims, count, <semicolon list of rects>
			String name = parts[1];
			
			LinkedList <HyperRectangleTime> initStates = new LinkedList <HyperRectangleTime>();
			
			int numDims = Integer.parseInt(parts[2]);
			int rectCount = Integer.parseInt(parts[3]);
			
			String[] rectParts = parts[4].split(";");

			if (rectParts.length != (1 + 2 * numDims) * rectCount)
			{
				parent.parent.addOutput("Warning: Socket sent malformed initial states for mode " 
						+ name);
			}
			else
			{
				int index = 0;
				
				for (int r = 0; r < rectCount; ++r)
				{
					double time = Double.parseDouble(rectParts[index++]);
					HyperRectangle hr = new HyperRectangle(numDims);
					
					for (int d = 0; d < numDims; ++d)
					{
						double min = Double.parseDouble(rectParts[index++]);
						double max = Double.parseDouble(rectParts[index++]);
						
						hr.dims[d] = new Interval(min, max);
					}
					
					HyperRectangleTime hrt = new HyperRectangleTime(hr, time);
					initStates.add(hrt);
				}
				
				// ok, now do something with init states
				panel.setCurMode(name, initStates);
			}
		}
	}

	public void addEvent(String event)
	{
		eventListModel.addElement(event);
		
		SwingUtilities.invokeLater(new Runnable(){ public void run() 
		{
			eventList.setSelectedIndex(eventListModel.getSize() - 1);
		}});
		
	}

	@Override
	public void valueChanged(ListSelectionEvent arg0)
	{
		panel.repaint();
	}
}
