package main;

import gui.hycreate.HyCreateFrame;

public class BatchMode
{
	public static boolean runningInBatchMode = false;

	/**
	 * Run a model in batch mode. If debugMode is true, will not exit the program at the end
	 * @param hcf the frame
	 * @param path the model file
	 * @param debugMode if true, will not exit after compiling/computing the model
	 */
	public static void run(HyCreateFrame hcf, String path, boolean debugMode)
	{
		if (!debugMode)
			runningInBatchMode = true; // disables plotting
		
		Main.showErrorDialogs = false;
		int exitCode = 1;
		
		if (hcf.load(path))
		{
			if (hcf.startCompile(true))
			{
				// errors will be printed using Main.error() (auto detected by unit tests)
				hcf.waitForCompileCompute();
				
				exitCode = 0;
				
				if (Main.hadError)
					exitCode = 2;
			}
		}
		
		if (!debugMode)
			System.exit(exitCode);
		else
			System.out.println("Debug mode (not exiting). Exit code would have been " + exitCode + ".");
	}

}
