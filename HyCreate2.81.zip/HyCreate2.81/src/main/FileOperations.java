package main;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FileOperations
{
	public static String getTempDirPath(String baseName) 
	{
		String path = System.getProperty("java.io.tmpdir") + File.separator + baseName + "_";
		
		path += System.nanoTime() % 10000;
		
		File dir = new File(path);
		
		if (dir.exists())
		{
			try
			{
				for (File f : dir.listFiles())
					recursiveDelete(f);
			}
			catch (IOException e)
			{
				Main.error("Error cleaning temp dir: " + e.toString());
			}
		}
		else
			dir.mkdirs();
		
		return dir.getAbsolutePath();
	}
	
	/**
	 * Delete all files in a directory, then delete the directory; or just delete a plain file
	 * @param f a directory
	 * @throws IOException if a file can not be deleted
	 */
	public static void recursiveDelete(File dir) throws IOException
	{
		try
		{
			if (dir.isDirectory())
			{
				for (File f : dir.listFiles())
				{
					if (f.isDirectory())
						recursiveDelete(f);
					else if (!f.delete())
						throw new IOException("Cannot delete file: " + f);
				}
				
				if (!dir.delete())
					throw new IOException("Cannot delete directory: " + dir.getAbsolutePath());
			}
			else if (!dir.delete())
				throw new IOException("Cannot delete file: " + dir.getAbsolutePath());
		}
		catch (SecurityException e)
		{
			throw new IOException(e.toString());
		}
	}
	
	/**
	 * Locate an executable by looking through all directories on PATH. This works with program arguments as well.
	 * This never returns null.
	 * @param executeName the executable name to look for. Spaces will be interpreted as program arguments
	 * @param englishName the name for error / success displays
	 * @return the path of the found executable
	 * @throws FileNotFoundException if the executable can not be found
	 */
	public static String[] locate(String executeName, String englishName, String extraPath) 
			throws FileNotFoundException
	{
		String[] execParts = splitSpaces(executeName);
		
		if (execParts.length < 1)
			throw new FileNotFoundException("Malformed executable name: '" + executeName + "'");
			
		String programName = execParts[0];
		String[] rv = null;
		String[] tryExtensions = {"", ".exe"}; 
		
		// look for program name among PATH
		Map <String, String> env = System.getenv();
		
		String pathVar = env.get("PATH");
		
		if (pathVar == null)
			pathVar = env.get("Path");
		
		if (pathVar == null)
		{
			throw new FileNotFoundException("Environment variable PATH is not defined.");
		}
		else
		{
			// prepend the user options path directory
			extraPath = extraPath.trim();
			
			if (extraPath.length() > 0)
				pathVar = extraPath + File.pathSeparator + pathVar;
			
			String[] paths = pathVar.split(File.pathSeparator);
			
			for (String s : paths)
			{
				String dir = s;
				
				if (!dir.endsWith(File.separator))
					dir += File.separator;
				
				for (String suffix : tryExtensions)
				{
					String path = dir + programName + suffix;
					
					File f = new File(path);
					
					if (f.exists())
					{
						execParts[0] = path;
						rv = execParts;
						break;
					}
				}
				
				if (rv != null) // already found
					break;
			}
		}
		
		if (rv == null)
		{
			String text = englishName + " not found! Please add " + programName + 
					" to your PATH environment variable or\n" +
					"add its directory to Options->HyCreate Options->Extra Search Directories.";
			
			throw new FileNotFoundException(text);
		}
		
		return rv;
	}

	/**
	 * split on spaces, except when quotes are involved
	 * @param str the string to split
	 * @return the resultant spaces
	 */
	private static String[] splitSpaces(String str)
	{
		ArrayList<String> list = new ArrayList<String>();
		
		// from http://stackoverflow.com/questions/7804335/split-string-on-spaces-except-if-between-quotes-i-e-treat-hello-world-as
		Matcher m = Pattern.compile("([^\"]\\S*|\".+?\")\\s*").matcher(str);
		
		while (m.find())
		    list.add(m.group(1).replace("\"", "")); 

		String[] rv = new String[list.size()];
		
		for (int i = 0; i < list.size(); ++i)
			rv[i] = list.get(i);
		
		return rv;
	}
}
