package main;

import gui.hycreate.HyCreateFrame;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import untrusted.UntrustedMain;


/**
 * HyCreate Main Class
 * 
 * Version 2.7
 * - Using time step with MFL-Reconstruct Strategy
 * - Using max boxes to limit number of tracked boxes
 * 
 * Version 2.8
 * - Changed import to use com.stanleybak.hycreate package
 * 
 * Version 2.81
 * - Made import backwards compatible with previous package name as well
 * 
 * @author Stanley Bak (stanleybak@gmail.com), 2012-2018
 *
 */
public class Main
{
	public static final String TOOL_VERSION = "HyCreate v2.81";
	public static final String ABOUT_TEXT = Main.TOOL_VERSION + 
			"\nby Stanley Bak (stanleybak@gmail.com)";
	public static final String RUN_EXTERNAL_PARAM = "RUN_EXTERNAL";
	
	public static HyCreateFrame hcf = null;
	
	// error reporting, these are set when Main.error() is called, used for unit testing
	public static boolean hadError = false;
	public static boolean showErrorDialogs = true;
	
	public static void main(String[] args)
	{	
		if (args.length == 0)
		{
			// normal start
			fixLookAndFeel();
			
			new HyCreateFrame(true, true);
			
			// UnitTests.run(hcf);
		}
		else if (args.length == 1)
		{
			String filename = args[0];
			System.out.println("Loading from filename:" + filename);
			
			new HyCreateFrame(false, true).load(filename);
		}
		else if (args.length == 5 && args[0].equals(RUN_EXTERNAL_PARAM))
		{
			// a new JVM was spawned to run the external code
			UntrustedMain.begin(args[1], args[2], args[3], args[4]);
		}
		else if (args.length == 2 && args[0].equals("-b"))
		{
			// batch mode
			String filename = args[1];
			
			fixLookAndFeel();
			BatchMode.run(new HyCreateFrame(false, false), filename, false);
		}
		else if (args.length == 2 && args[0].equals("-bd"))
		{
			// debug batch mode
			String filename = args[1];
			
			fixLookAndFeel();
			BatchMode.run(new HyCreateFrame(false, true), filename, true);
		}
		else 
		{
			System.out.println("Batch mode usage: -b (filename to run) or -bd (debug mode; filename to run)");
			System.out.println("Debug batch mode usage (doesn't exit after running model): -bd (filename to run)");
			System.out.println("Otherwise, run program without arguments.\n"
					+ ABOUT_TEXT);
			
			System.exit(1);
		}
	}
	
	private static void fixLookAndFeel()
	{
		try 
		{
			/*for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
			   System.out.println(info.getClassName());
			*/
			
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch (Exception e) {}
	}

	public static void error(String errorMsg)
	{
		final String text = errorMsg;
		hadError = true;

		if (showErrorDialogs)
		{
			// thread safe
			SwingUtilities.invokeLater(new Runnable()
			{
				public void run()
				{
					if (hcf.frame.isVisible())
					{
						JOptionPane.showMessageDialog(hcf.frame,
							    text,
							    "Error",
							    JOptionPane.ERROR_MESSAGE);
					}
				}
			});
		}
		else
			System.out.println("Error: " + text);
	}
}
