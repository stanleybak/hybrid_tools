package main;

import gui.hycreate.HyCreateFrame;

import java.io.File;

public class UnitTests 
{
	private static HyCreateFrame hcf = null;
	private boolean exitAfterTests = false;
	
	private UnitTest[] tests = 
	{
		new CheckUnitFolder(),
		new OpenCompileCompute(),
	};
	
	private UnitTests()
	{
		int count = 0;
		boolean failed = false;
		
		// disable joption pane error dialogs
		Main.showErrorDialogs = false;
		
		for (UnitTest u : tests)
		{
			System.out.print("Running Test #" + (++count) + " (" + u.name + ")... ");
			Main.hadError = false;
			
			boolean result = false;
			
			try
			{
				result = u.run();
			}
			catch (Exception e)
			{
				System.out.println("Exception while running unit test: " + e);
				e.printStackTrace();
				
				result = false;
			}
			
			if (result == true && !Main.hadError)
				System.out.println("Passed!");
			else
			{
				failed = true;
				System.out.println("Test #" + (count) + " (" + u.name + ") Failed!");
				break;
			}
		}
		
		if (!failed)
			System.out.println("All Tests Passed!");
		
		if (exitAfterTests)
			System.exit(failed ? 1 : 0);
	}
	
	public static void run(HyCreateFrame f) 
	{
		hcf = f;
		
		new UnitTests(); // will run tests
	}
	
	private abstract class UnitTest
	{
		public String name;
		
		public UnitTest(String n)
		{
			name = n;
		}
		
		public abstract boolean run();
	}

	private class CheckUnitFolder extends UnitTest
	{
		public CheckUnitFolder()
		{
			super("CheckUnitFolder");
		}
		
		public boolean run()
		{
			boolean rv = true;
			File f = new File("unit");
			
			if (!f.exists() || !f.isDirectory())
			{
				System.out.println("Unit folder does not exist on current working directory.");
				rv = false;
			}
			
			return rv;
		}
	}

	private class OpenCompileCompute extends UnitTest
	{
		public OpenCompileCompute()
		{
			super("OpenCompileCompute");
		}
		
		public boolean run()
		{
			boolean rv = false;
			String path = "unit/heater_simple/heater_simple.hyc2";
			
			if (hcf.load(path))
			{
				if (hcf.startCompile(true))
				{
					// errors will be printed using Main.error() (auto detected by unit tests)
					hcf.waitForCompileCompute();
					rv = true;
				}
			}
			
			return rv;
		}
		
	}

}
