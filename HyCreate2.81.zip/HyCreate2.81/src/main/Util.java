package main;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class Util
{
	/**
	 * Sanitize a String, replacing 'bad' characters with an underscore. 
	 * Only alphanumeric characters are allowed.
	 * @param s the string to clean
	 * @return the cleaned string
	 */
	public static String cleanName(String s)
	{
		s = s.trim();
		StringBuffer name = new StringBuffer();
		
		for (int x = 0; x < s.length(); ++x)
		{
			char c = s.charAt(x);
			
			if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
				name.append(c);
			else
				name.append('_');
		}
		
		return name.toString();
	}
	
	/**
	 * Sanitize a String, replacing 'bad' characters with an underscore.
	 * By default, only alphanumeric characters are allowed.
	 * @param s the string to clean
	 * @param extraAllowed extra characters which are also allowed
	 * @return the cleaned string
	 */
	public static String cleanName(String s, char[] extraAllowed)
	{
		s = s.trim();
		ArrayList<Character> extra = new ArrayList <Character>();
		
		for (char c : extraAllowed)
			extra.add(c);
		
		StringBuffer name = new StringBuffer();
		
		for (int x = 0; x < s.length(); ++x)
		{
			char c = s.charAt(x);
			
			if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
				name.append(c);
			else if (extra.contains(c))
				name.append(c);
			else
				name.append('_');
		}
		
		return name.toString();
	}
	
	public static String doubleArrayString(double[] ds)
	{
		String rv = "";
		
		for (double d : ds)
		{
			if (rv.length() > 0)
				rv += ", ";
			
			if (d < 0.0001 || d > 0.0001)
				rv += doubleToString(d);
		}
		
		return "[" + rv + "]";
	}
	
	private static DecimalFormat df = new DecimalFormat("#");
	
	static
	{
		df.setMaximumFractionDigits(10);
	}
	
	public static String doubleToString(double n)
	{
		String rv;
		
		if (n < -0.001 || n > 0.001)
			rv = String.format("%.4f", n);
		else
			rv = df.format(n);
		
		return rv;
	}
}
