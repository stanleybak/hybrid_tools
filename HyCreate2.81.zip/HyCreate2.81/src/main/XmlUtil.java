package main;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Utilities for XML Encoding / Decoding of Java Beans
 * @author Stanley Bak (sbak2@illinois.edu)
 *
 */
public class XmlUtil
{

	public static void saveObject(Object bean, String path) throws IOException
	{
		
		XMLEncoder e = new XMLEncoder(
			    new BufferedOutputStream(
			        new FileOutputStream(path)));
		e.writeObject(bean);
		e.close();
	}
	
	public static Object loadObject(String path) throws IOException
	{
		Object rv = null;
	
		XMLDecoder d = new XMLDecoder(
			    new BufferedInputStream(
			        new FileInputStream(path)));
		try
		{
			rv = d.readObject();
		}
		catch (Exception e)
		{
			String error = "Error loading model file.";
			d.close();
			throw new IOException(error);
		}
		
		d.close();
		
		return rv;
	}

}
