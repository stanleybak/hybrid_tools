package reachability.automaton;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map.Entry;
import java.util.TreeMap;

import reachability.compute.ComputationResultSaveThread;
import reachability.compute.FaceLift;
import reachability.geometry.HyperRectangleTime;

/**
 * Class which stores data about individual automaton modes; a Java Bean.
 * @author Stanley Bak
 *
 */
public class AutomatonMode
{
	public String name; // the name of this mode
	public Dynamics modeDynamics = null;
	
	public ArrayList <Transition> successors = new ArrayList <Transition>();
	
	public SuccessorAggregation successorAggregator = null;
	
	public HybridAutomaton automaton;
	
	private double[] gridSize;
	private double[] regridRatio;
	
	public AutomatonMode(HybridAutomaton automaton)
	{
		this.automaton = automaton;
	}
	
	public double[] getGridSize()
	{
		return gridSize;
	}

	public void setGridSize(double[] gridSize)
	{
		this.gridSize = gridSize;
	}

	public double[] getRegridRatio()
	{
		return regridRatio;
	}

	public void setRegridRatio(double[] regridRatio)
	{
		this.regridRatio = regridRatio;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public Dynamics getModeDynamics()
	{
		return modeDynamics;
	}

	public void setModeDynamics(Dynamics modeDynamics)
	{
		this.modeDynamics = modeDynamics;
	}

	public ArrayList<Transition> getSuccessors()
	{
		return successors;
	}

	public void setSuccessors(ArrayList<Transition> successors)
	{
		this.successors = successors;
	}

	////////// compute below ////////////////
	/**
	 * Perform a reachability computation for this mode. This should add successor
	 * states by using atuomaton.addSuccessorStates
	 * @param automaton the automaton object (for params and error printing)
	 * @param init the initial set
	 */
	public void compute(Collection <HyperRectangleTime> init) 
	{
		int numDims = automaton.getDimensions();
		double deltaReachTime = automaton.getDeltaReachTime();
		
		modeDynamics.setAutomaton(automaton);
		
		FaceLift computer = new FaceLift(automaton, this, numDims);
		computer.setDeltaReachTime(deltaReachTime);
		computer.setDynamics(modeDynamics);
		computer.setDesiredTimeStep(automaton.getTimeStep());
		computer.setGridSize(gridSize);
		computer.setRegridRatio(regridRatio);
		computer.setInitialStates(init);
		
		automaton.output("\nComputing reachability for mode '" + name + "' (" 
				+ "number of initial hyperrectangles: "+ init.size() + ")");
		
		if (automaton.reachParams.saveInitialStates)
			ComputationResultSaveThread.saveInitialStates(init);
		
		successorAggregator = new SuccessorAggregation(automaton.reachParams.aggregationMethod);
		
		computer.compute(0);
			
		TreeMap <String, Collection <HyperRectangleTime>> modeSuccessors = 
				successorAggregator.getModeSuccessors(); 
		
		ComputationResultSaveThread.flushBuffer();
		
		if (ComputationResultSaveThread.hadErrors())
			automaton.output("Error encountered while saving reachability result");
		else
		{
			// add the accumulated states from modeSuccessors to the automaton
			for (Entry<String, Collection<HyperRectangleTime>> e : modeSuccessors.entrySet())
			{
				String modeName = e.getKey();
				
				for (HyperRectangleTime hrt : e.getValue())
					automaton.addSuccessorState(modeName, hrt);
			}
		}
	}

	/**
	 * Called during computation to add a successor rectangle
	 * @param successorMode the name of the successor mode
	 * @param hrt the rectangle to add
	 */
	public void addSuccessorState(String successorMode, HyperRectangleTime hrt)
	{
		successorAggregator.addSuccessorRect(successorMode, hrt);
	}
}



