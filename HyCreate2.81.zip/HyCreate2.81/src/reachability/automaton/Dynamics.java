package reachability.automaton;

import java.util.LinkedList;

import reachability.geometry.HyperPoint;
import reachability.geometry.HyperRectangle;
import reachability.geometry.HyperRectangleCornerEnumerator;
import reachability.geometry.Interval;


public abstract class Dynamics
{
	// used to print output when tracking min/max errors
	private HybridAutomaton ha = null;
	
	public void setAutomaton(HybridAutomaton ha)
	{
		this.ha = ha;
	}
	
	/**
	 * Get the derivative at a point in the state space
	 * @param dimensionIndex the index of the dimension we want the derivative of
	 * @param point a point in the state space
	 * @return an interval containing the derivative of the passed-in dimension, 
	 *  at the passed-in point
	 */
	protected abstract Interval getDerivativeBounds(int dimensionIndex, HyperPoint point);
	
	/**
	 * Get points inside the hyperrectangle where the derivative is minimized or maximized (not the endpoints)
	 * return value can be null if not points exist
	 * @param dimensionIndex the direction of the derivative we are interested in
	 * @param r the region in which we are takin the derivative
	 * @return a list of points where the derivative is maximized or minimized (not endpoints), can be null 
	 */
	public abstract LinkedList <HyperPoint> getLocalMinMaxPoints(int dimensionIndex, HyperRectangle r);
	
	/**
	 * Check if a hyperrectangle intersects this mode's invariant
	 * @param hr the hyperrectangle to check
	 * @return true iff the hyperrectangle intersects the mode
	 */
	public abstract boolean intersectsInvariant(HyperRectangle hr);
	
	/**
	 * return the time trigger value for this mode, null means don't use it
	 * @param hr the variable values in the current rectangle
	 * @return the time-trigger range, or null
	 */
	public abstract Interval getTimeTrigger(HyperRectangle hr);
	
	////////// functions below already implemented ///////////
	
	/**
	 * Get the derivative at a point in the state space
	 * @param dimensionIndex the index of the dimension we want the derivative of
	 * @param point a point in the state space
	 * @return an interval containing the derivative of the passed-in dimension, 
	 *  at the passed-in point
	 */
	public Interval getDerivative(int dimensionIndex, HyperPoint point)
	{
		return getDerivativeBounds(dimensionIndex, point);
	}
	
	/**
	 * Get the derivative bounds inside a region of the state space.
	 * @param dimensionIndex the index of the dimension we want the derivative of
	 * @param region a portion of the state space
	 * @return the derivative bounds
	 */
	public Interval getDerivative(final int dimensionIndex, HyperRectangle region)
	{
		final Interval rv = new Interval(Double.MAX_VALUE, -Double.MAX_VALUE);

		// first try all the corners
		region.enumerateCorners(new HyperRectangleCornerEnumerator()
		{
			@Override
			public void enumerate(HyperPoint p)
			{
				Interval der = getDerivative(dimensionIndex, p);
				
				// update return value
				if (der.min < rv.min)
					rv.min = der.min;
				
				if (der.max > rv.max)
					rv.max = der.max;
			}
		});
		
		// next, try the local minimums / maximums inside region
		LinkedList <HyperPoint> minMaxPointSet = getLocalMinMaxPoints(dimensionIndex, region);
		
		if (minMaxPointSet != null)
		{			
			// try each point in the min/max point set
			for (HyperPoint p : minMaxPointSet)
			{				
				Interval der = getDerivative(dimensionIndex, p);
		
				// update return value
				if (der.min < rv.min)
					rv.min = der.min;
				
				if (der.max > rv.max)
					rv.max = der.max;
			}
		}
		
		if (ha.reachParams.detectMinMaxErrors)
		{
			if (hasMinMaxErrors(dimensionIndex, region, rv))
			{
				// error printed in hasMinMaxErrors, suppress further checks
				
				ha.setMinMaxErrorsFound(true);
				
				ha.reachParams.detectMinMaxErrors = false;
			}
		}
		
		return rv;
	}
	
	///////////////////////////////////////////////////////////////
	///////// sanity checking for min/max errors below ////////////
	///////////////////////////////////////////////////////////////

	/**
	 * Sanity check which, if enabled, attempts to detect errors with the getLocalMinMaxPoints
	 * method. Throws returns true if a problem is found
	 * @param dimensionIndex the dimension we are checking in
	 * @param region the region of the state space to check
	 * @param bounds the computed bounds we are trying to get a derivative outside of
	 * @return true if a min/max specification problem is found 
	 */
	private boolean hasMinMaxErrors(int dimensionIndex, HyperRectangle region, Interval bounds)
	{
		boolean rv = false;
		LinkedList <HyperPoint> toCheck = new LinkedList <HyperPoint>();
		
		int numDimensions = region.dims.length;
		
		// try middle point
		HyperPoint middle = new HyperPoint(numDimensions);
		
		for (int d = 0; d < numDimensions; ++d)
			middle.dims[d] = region.dims[d].middle();
		
		toCheck.add(middle);
		
		// try points "near" corners
		
		int maxIterator = 1;
		
		for (int dimIndex = 0; dimIndex < numDimensions; ++dimIndex)
			maxIterator *= 2;
		
		// next iterate from 0 to maxIterator (try each bit-array combination)
		HyperPoint point = new HyperPoint(numDimensions);
		
		for (int iterator = 0; iterator < maxIterator; ++iterator)
		{
			// extract each dimension's boolean true/false values from iterator
			int mask = 0x01;
			for (int dimIndex = 0; dimIndex < numDimensions; ++dimIndex)
			{
				boolean isMin = (iterator & mask) == 0;
				mask = mask << 1;
				
				// assign the current dimension of the point point
				point.dims[dimIndex] = isMin ? region.dims[dimIndex].min : region.dims[dimIndex].max;
			}

			// but move the point inward slightly for each dimension
			mask = 0x01;
			for (int d = 0; d < numDimensions; ++d)
			{
				double before = point.dims[d];
				boolean isMin = (iterator & mask) == 0;
				mask = mask << 1;
				
				double width = region.dims[d].max - region.dims[d].min; 
						
				if (isMin)
					point.dims[d] += (width / 10.0);
				else
					point.dims[d] -= (width / 10.0);
				
				toCheck.add(new HyperPoint(point));
				
				point.dims[d] = before;
			}
		}
		
		// check if any of the points in toCheck are outside of bounds
		for (HyperPoint p : toCheck)
		{
			Interval der = getDerivative(dimensionIndex, p);
			
			if (der.min < bounds.min || der.max > bounds.max)
			{
				String msg = "MIN/MAX VIOLATION: Found violation while checking getMinMaxPoints in region:\n" +
						region + "\n\n" + 
						"Derivative in dimension index = " + dimensionIndex + 
						" at corners & user-provided min/max points was computed as\n" +
						bounds + "\n\n" +
						"However, the derivative found at point\n" +
						p + "\n" +
						"was outside of this range:\n" +
						der + "\n";
				
				rv = true;
				
				ha.output(msg);
				
				break;
			}
				
		}
		
		return rv;
		
	}
}
