package reachability.automaton;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.TreeMap;

import com.stanleybak.hycreate.containers.ReachParams;

import reachability.compute.ComputationResultSaveThread;
import reachability.compute.FaceLift;
import reachability.geometry.HyperRectangleTime;

/**
 * A Java Bean which has the reachability parameters for a hybrid
 * automaton stored.
 * @author Stanley Bak
 *
 */
public class HybridAutomaton
{	
	// computation variables
	private TreeMap <String,  ModeStartStateData> modeStartStates = null;
	
	// automaton variables
	private String name;
	private String initialStateString;
	private int dimensions;
	private double deltaReachTime = Double.MAX_VALUE; // or Double.MAX_VALUE for infinite
	private boolean minMaxErrorsFound = false;
	private boolean usePseudoInvariant = false;
	private double timeStep = 0;
	private double[] baseSize;
	
	// settings
	public ReachParams reachParams;
	
	private ArrayList <AutomatonMode> modes = new ArrayList <AutomatonMode>();
	
	// assigned if we're tracking min/max errors
	public ArrayList<AutomatonMode> getModes()
	{
		return modes;
	}
	public void setModes(ArrayList<AutomatonMode> modes)
	{
		this.modes = modes;
	}
	
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public int getDimensions()
	{
		return dimensions;
	}
	public void setDimensions(int dimensions)
	{
		this.dimensions = dimensions;
	}
	public double getDeltaReachTime()
	{
		return deltaReachTime;
	}
	public void setDeltaReachTime(double deltaReachTime)
	{
		this.deltaReachTime = deltaReachTime;
	}
	
	public double getTimeStep()
	{
		return timeStep;
	}
	
	public void setTimeStep(double ts)
	{
		timeStep = ts;
	}
	
	//////// compute method below
	
	/**
	 * Compute Reachability for the Hybrid Automaton. The result of the reachability
	 * will be placed into the variable reachabilityResult
	 * @param baseDir the base directory where to perform the computation
	 * @param init the initial states
	 * @return An error message, if an error occurs, null if success
	 */
	public String compute(String baseDir, TreeMap <String, Collection <HyperRectangleTime> > init) throws IOException
	{
		String rv = null;
		long start = System.currentTimeMillis();
		FaceLift.startTimer();

		if (deltaReachTime == Double.MAX_VALUE)
			output("Initialized computation with no time bound");
		else
			output("Initialized computation with time bound " + deltaReachTime);
		
		modeStartStates = new TreeMap <String,  ModeStartStateData>();
		
		for (Entry<String, Collection<HyperRectangleTime>> e : init.entrySet())
		{
			ModeStartStateData data = new ModeStartStateData();
			data.rects = e.getValue();
			data.minTime = Double.MAX_VALUE;
			
			for (HyperRectangleTime t : data.rects)
			{
				double time = t.getTime();
				
				if (time < data.minTime)
					data.minTime = time;
			}
			
			modeStartStates.put(e.getKey(), data);
		}
		
		// iterate, performing computation in each mode
		while (!modeStartStates.isEmpty())
		{
			Entry<String, ModeStartStateData> e = popMinTimeMode();
			
			Collection <HyperRectangleTime> initRects = e.getValue().rects;
			
			if (initRects.size() == 0)
				continue;
			
			// compute reachability for mode, which may add to modeInputRects
			computeMode(e.getKey(), initRects);
			
			if (ComputationResultSaveThread.hadErrors())
				break;
		}
		
		// save the final matrix files
		ComputationResultSaveThread.saveMatrixFiles();
		
		long end = System.currentTimeMillis();
		output("\nComputation finished in " + (end - start) + " milliseconds");
		
		if (ComputationResultSaveThread.hadErrors())
		{
			rv = "Error while saving reachability result";
			output(rv);
		}
		
		if (minMaxErrorsFound)
			rv = "Min/Max Errors found during computation\n";
		
		output("");
		
		return rv;
	}
	
	/**
	 * Pop the mode that has successors of the minimum time
	 * @return the mode name and inital states data
	 */
	private Entry<String, ModeStartStateData> popMinTimeMode()
	{
		Entry<String, ModeStartStateData> rv = null;
		double minTime = Double.MAX_VALUE;
		
		for (Entry<String, ModeStartStateData> e : modeStartStates.entrySet())
		{
			ModeStartStateData data = e.getValue();
			
			if (data.minTime < minTime)
			{
				minTime = data.minTime;
				rv = e;
			}
		}
		
		modeStartStates.remove(rv.getKey());
		
		return rv;
	}

	public void output(String string)
	{
		System.out.println(string);
	}
	
	/**
	 * Compute the reachability for a single mode
	 * @param mode the mode name
	 * @param initRects the initial set
	 */
	private void computeMode(String mode, Collection <HyperRectangleTime> initRects)
	{
		boolean found = false;
		
		for (AutomatonMode am : modes)
		{
			if (am.name.equals(mode))
			{
				am.compute(initRects);
				
				found = true;
				break;
			}
		}
		
		if (!found)
			throw new RuntimeException("ComputeMode called on non-existent mode: " + mode);
	}
	/**
	 * Retrun a list of all the modes in this automaton
	 * @return
	 */
	public ArrayList <String> modeNames()
	{
		ArrayList <String> rv = new ArrayList <String>();
		
		for (AutomatonMode am : modes)
			rv.add(am.name);
		
		return rv;
	}

	/**
	 * Add a successor states during the computation. These will get recomputed eventually, 
	 * one mode at a time
	 * @param mode the mode we're adding successor states to
	 * @param r the state to add
	 */
	public void addSuccessorState(String mode, HyperRectangleTime r)
	{
		ModeStartStateData data = modeStartStates.get(mode);
		
		if (data == null)
		{
			data = new ModeStartStateData();
			modeStartStates.put(mode, data);
		}
		
		data.rects.add(r);
		
		double time = r.getTime();
		
		if (time < data.minTime)
			data.minTime = time;
	}

	public void setUsePseudoInvariant(boolean b)
	{
		this.usePseudoInvariant = b;
	}
	
	public boolean isUsePseudoInvariant()
	{
		return usePseudoInvariant;
	}

	public boolean isMinMaxErrorsFound()
	{
		return minMaxErrorsFound;
	}

	public void setMinMaxErrorsFound(boolean minMaxErrorsFound)
	{
		this.minMaxErrorsFound = minMaxErrorsFound;
	}

	public String getInitialStateString()
	{
		return initialStateString;
	}

	public void setInitialStateString(String initialStateString)
	{
		this.initialStateString = initialStateString;
	}
	
	public void setReachParams(ReachParams p)
	{
		reachParams = p;
	}
	
	// types
	
	private class ModeStartStateData
	{
		Collection <HyperRectangleTime> rects = new LinkedList <HyperRectangleTime>();
		double minTime = Double.MAX_VALUE;
	}

	public void setBaseSize(double[] baseSize) 
	{
		this.baseSize = baseSize;
	}
	
	public double[] getBaseSize()
	{
		return baseSize;
	}
}
