package reachability.automaton;

import java.util.Collection;
import java.util.LinkedList;
import java.util.TreeMap;

import com.stanleybak.hycreate.containers.ModelOptions.AggregationMethod;

import reachability.compute.DiscretizedHullSuccessors;
import reachability.geometry.HyperRectangleTime;

/**
 * Aggregates successors when crossing mode boundaries. There are various ways to do this:
 * 
 * - No aggregation: this will just track all the rectangles and set them as successors
 * - Convex hull: aggregates successor states on a per-mode convex hull
 * - Discretized hull: tracks which grid entries are entered by successor modes
 * 
 * @author Stanley Bak, 2014
 *
 */
public class SuccessorAggregation 
{
	private AggregationMethod aggMethod;
	private double[] gridSize;
	
	private DiscretizedHullSuccessors disHullSucc = null;
	private TreeMap <String, Collection <HyperRectangleTime>> modeSuccessors = null;
	private boolean addedSuccessors = false;

	public SuccessorAggregation(AggregationMethod aggMethod) 
	{
		this.aggMethod = aggMethod;
		
		disHullSucc = null;
		modeSuccessors = null;
		addedSuccessors = false;
		
		if (aggMethod == AggregationMethod.NONE || aggMethod == AggregationMethod.CONVEX_HULL)
			modeSuccessors = new TreeMap <String, Collection <HyperRectangleTime>>();
		else if (aggMethod == AggregationMethod.DISCRETIZED_HULL)
			disHullSucc = new DiscretizedHullSuccessors();
		else if (aggMethod == AggregationMethod.CONDITIONAL_DISCRETIZED_HULL)
		{
			modeSuccessors = new TreeMap <String, Collection <HyperRectangleTime>>();
			disHullSucc = new DiscretizedHullSuccessors();
		}
		else
			throw new RuntimeException("Unsupported Aggregation Method");
	}
	
	public void setGridSize(double[] grid)
	{
		gridSize = grid;
	}

	/**
	 * Get the mode successors. This may be a shallow copy depending on the aggregation method.
	 * @return the successor states
	 */
	public TreeMap<String, Collection<HyperRectangleTime>> getModeSuccessors() 
	{
		TreeMap<String, Collection<HyperRectangleTime>> rv = null;
		
		if (aggMethod == AggregationMethod.NONE || aggMethod == AggregationMethod.CONVEX_HULL)
			rv = modeSuccessors;
		else if (aggMethod == AggregationMethod.DISCRETIZED_HULL)
			rv = disHullSucc.discretizedHullCreateModeSuccessors();
		else if (aggMethod == AggregationMethod.CONDITIONAL_DISCRETIZED_HULL)
		{
			rv = disHullSucc.discretizedHullCreateModeSuccessors();
			
			// take the minimum (this is the 'conditional' aspect)
			if (numRects(rv) >= numRects(modeSuccessors))
				rv = modeSuccessors;
		}
		
		return rv;
	}
	
	/**
	 * Get the number of rectangles in this collections
	 * @param set the set
	 */
	private int numRects(TreeMap<String, Collection<HyperRectangleTime>> set)
	{
		int rv = 0;
		
		for (Collection <HyperRectangleTime> c : set.values())
		{
			rv += c.size();
		}
		
		return rv;
	}

	public void addSuccessorRect(String successorMode, HyperRectangleTime hrt) 
	{
		addedSuccessors = true;
		
		if (disHullSucc != null)
			disHullSucc.discretizedHullAggregate(successorMode, hrt, gridSize);
		
		if (modeSuccessors != null)
		{
			Collection <HyperRectangleTime> set = modeSuccessors.get(successorMode);
			
			if (set == null || set.size() == 0)
			{
				set = new LinkedList<HyperRectangleTime>();
				modeSuccessors.put(successorMode, set);
			}
			
			if (aggMethod.equals(AggregationMethod.CONVEX_HULL))
				convexHullAggregate(hrt, set);
			else
				set.add(new HyperRectangleTime(hrt));
		}
	}
	
	private void convexHullAggregate(HyperRectangleTime hrt,
			Collection<HyperRectangleTime> set)
	{
		if (set.size() == 0)
		{
			HyperRectangleTime copy = new HyperRectangleTime(hrt);
			
			set.add(copy); // first one
		}
		else
		{
			// accumulate it to the current one
			HyperRectangleTime hull = set.iterator().next();
			
			// use the minimum time
			if (hull.getTime() > hrt.getTime())
				hull.setTime(hrt.getTime());
			
			// accumulate convex hull
			for (int d = 0; d < hull.rect.dims.length; ++d)
			{
				if (hull.rect.dims[d].min > hrt.rect.dims[d].min)
					hull.rect.dims[d].min = hrt.rect.dims[d].min;
				
				if (hull.rect.dims[d].max < hrt.rect.dims[d].max)
					hull.rect.dims[d].max = hrt.rect.dims[d].max;
			}
		}
	}

	public boolean hasSuccessors() 
	{
		return addedSuccessors;
	}

	public int getSuccessorCount() 
	{
		int count1 = Integer.MAX_VALUE;
		int count2 = Integer.MAX_VALUE;
		
		if (disHullSucc != null)
			count1 = disHullSucc.getCount();
		
		if (modeSuccessors != null)
			count2 = numRects(modeSuccessors);
		
		return Math.min(count1, count2);
	}
}
