package reachability.automaton;
import reachability.geometry.HyperRectangle;


/**
 * Java Bean storing data about transition
 * @author Stanley Bak (sbak2@illinois.edu)
 *
 */
public abstract class Transition
{
	// guard method
	public abstract boolean intersectsGuard(HyperRectangle hr);
	
	// reset method
	public abstract void applyReset(HyperRectangle hr);
	
	// successor state
	String successorMode;

	public String getSuccessorMode()
	{
		return successorMode;
	}

	public void setSuccessorMode(String successorMode)
	{
		this.successorMode = successorMode;
	}
}
