package reachability.compute;

import java.awt.geom.Point2D;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import com.stanleybak.hycreate.containers.ReachParams;

import reachability.automaton.AutomatonMode;
import reachability.automaton.HybridAutomaton;
import reachability.fileformat.HrmFormat;
import reachability.geometry.HyperPoint;
import reachability.geometry.HyperRectangle;
import reachability.geometry.HyperRectangleTime;

/**
 * This is a thread that will run as the computation is occurring, and will save the result
 * @author sbak
 *
 */
public class ComputationResultSaveThread
{
	public static String GNUPLOT_PARTIAL_EXTENSION = ".gnuplot.txt";
	
	private static boolean hadError = false;
	private static SaveThread saveThread = null;
	private static HybridAutomaton ha = null;
	private static String modeName = "";
	private static ReachParams reachParams = null;
	private static Socket visualizeSocket = null;
	
	private static Map <String, boolean[][]> modeMatricies = null; // for visualization
	private static boolean[][] currentVisualizationMatrix = null;
	private static boolean warnedOutOfBounds = false;
	private static double[] xRange = null;
	private static double[] yRange = null;
	private static double xStep = -1;
	private static double yStep = -1;
	private static int xDim = -1;
	private static int yDim = -1;
	
	private static String saveDir = null;
	private static Writer partialResultSocket = null;
	private static boolean socketNeedsFlush = false;
	private static int numInitialStatesSaved = 0;
	
	public static boolean visualizeSuccessors = false; // TODO make this a setting, also figure out why it slows down on toy
	
	private ComputationResultSaveThread() {}
	
	/**
	 * Set the port number for outputting partial results
	 * @param socketNum the port num
	 */
	public static void setVisualizePort(int port)
	{
		try
		{
			visualizeSocket = new Socket(InetAddress.getByName(null), port);
			
			partialResultSocket = new BufferedWriter(new PrintWriter(
					visualizeSocket.getOutputStream())); 
		}
		catch (IOException e )
		{
			System.out.println("EXCEPTION when opening partial result socket: " + e);
			partialResultSocket = null;
		}
	}
	
	private static void partialResultOutput(String line)
	{
		if (partialResultSocket != null)
		{
			//System.out.println(": " + line);
			try
			{
				// add a comma at the end
				partialResultSocket.write(line + "," + "\n");
			}
			catch (IOException e)
			{
				System.out.println("EXCEPTION when writing partial results socket: " + e);
				partialResultSocket = null;
			}
		}
	}
	
	private static void flushSocket()
	{
		if (partialResultSocket != null)
		{
			try
			{
				partialResultSocket.flush();
			}
			catch (IOException e)
			{
				System.out.println("EXCEPTION when flushing partial results socket: " + e);
				partialResultSocket = null;
			}
		}
	}
	
	public static void closeVisualizeSocket()
	{
		if (partialResultSocket != null)
		{
			try
			{
				partialResultOutput("end");
				partialResultSocket.flush();
				partialResultSocket.close();
			}
			catch (IOException e)
			{
				System.out.println("EXCEPTION when closing partial results socket: " + e);
				hadError = true;
			}
		}
	}
	
	/**
	 * Set the automaton we're saving
	 * @param ha
	 */
	public static void setAutomaton(HybridAutomaton ha, ReachParams rp)
	{
		if (ComputationResultSaveThread.ha != null)
			throw new RuntimeException("setAutomaton called twice");
		
		ComputationResultSaveThread.ha = ha;
		
		if (reachParams.saveVisualization)
		{
			xDim = reachParams.visualizeXDim;
			yDim = reachParams.visualizeYDim;
			
			if (xDim < 0)
				xDim = 0;
			
			if (yDim < 0)
				yDim = 0;
			
			if (xDim >= ha.getDimensions())
				xDim = ha.getDimensions() - 1;
			
			if (yDim >= ha.getDimensions())
				yDim = ha.getDimensions() - 1;
			
			modeMatricies = new TreeMap <String, boolean[][]> ();
			
			for (AutomatonMode mode : ha.getModes())
			{
				boolean[][] matrix = new boolean[rp.visualizeHeight][rp.visualizeWidth];
				
				modeMatricies.put(mode.getName(), matrix);
			}
		}
	}
	
	public static void stopThread()
	{
		if (saveThread != null)
		{
			try
			{
				// signal the thread to exit and wait for it
				
				saveThread.doExit();
				
				while (saveThread.exited == false)
					Thread.sleep(10);
			}
			catch (InterruptedException e)
			{
				hadError = true;
				System.out.println("ERROR waiting for results to finish saving: " + e);
			}
		}
	}

	/**
	 * Start the output-saving thread. This should only be called once, before
	 * any security manager is installed.
	 * @param outputPath the path to the output file
	 * @param params the computation parameters (indicates what to save)
	 */
	public static void startThread(String outputPath, ReachParams params)
	{
		if (saveThread != null)
			throw new RuntimeException("startThread called twice");
		
		reachParams = params;
		
		saveDir = new File(outputPath).getAbsoluteFile().getParent();
		
		try
		{
			saveThread = new ComputationResultSaveThread().new SaveThread(outputPath);
			
			saveThread.start();
		}
		catch (IOException e)
		{
			hadError = true;
			System.out.println("ERROR saving results: " + e);
		}
	}

	/**
	 * Did the thread encounter an error during computation? For example, an IOException.
	 * @return true iff there were no errors
	 */
	public static boolean hadErrors()
	{
		return hadError;
	}
	
	/**
	 * Add rectangles to the reach set. This also may write the matrix files 
	 * partial result or final result to files for display
	 * @param reachableStatesBuffer the rectangles which are reachable to add
	 * @param saveMatrixFiles should we save the matrix files? (assuming visualization is enabled)
	 */
	public static void dumpBuffer(Collection<HyperRectangle> reachableStatesBuffer)
	{
		if (saveThread == null)
		{
			if (!hadError)
			{
				hadError = true;
				System.out.println("Error: dumpBuffer called but save thread has not been started");
			}
		}
		else if (!hadError)
		{
			if (reachableStatesBuffer != null)
				saveThread.dumpBuffer(reachableStatesBuffer);
		}
	}
	
	/**
	 * Save the matrix files. This will save the .gnuplot file
	 * @param milliseconds the milliseconds to tag the partial result. Use -1 for the final result
	 */
	public static void saveMatrixFiles()
	{
		if (saveThread != null && reachParams.saveVisualization)
		{
			synchronized (saveThread)
			{
				try
				{
					for (Entry<String, boolean[][]> e : modeMatricies.entrySet())
					{
						String modeName = e.getKey();
						String path = saveDir + File.separator + modeName + GNUPLOT_PARTIAL_EXTENSION;
						
						boolean[][] matrix = e.getValue();
						
						BufferedWriter writer = new BufferedWriter(new FileWriter(path));
						
						for (int y = 0; y < matrix.length; ++y)
						{
							for (int x = 0; x < matrix[0].length; ++x)
							{
								if (matrix[y][x])
								{
									double xValue = xRange[0] + x * xStep;
									double yValue = yRange[0] + y * yStep;
									
									writer.write(xValue + " " + yValue + "\n");
								}
							}
						}
						
						writer.close();
					}
				}
				catch (IOException e)
				{
					ha.output("Error saving visualization data files: " + e);
				}
			}
		}
	}
	
	/**
	 * Set the ranges and dimensions for the visualization. Should be called before
	 * the reachability computation starts.
	 * @param xRange the range in the x dimension that we are saving
	 * @param yRange the range in the y dimension that we are saving
	 */
	public static void setVisualizationRanges(double[] xRange, double[] yRange)
	{
		if (reachParams.saveVisualization)
		{
			ComputationResultSaveThread.xRange = xRange;
			ComputationResultSaveThread.yRange = yRange;
			
			xStep = (xRange[1] - xRange[0]) / (double)(reachParams.visualizeWidth - 1);
			yStep = (yRange[1] - yRange[0]) / (double)(reachParams.visualizeHeight - 1);
			
			// output them to the ranges file
			try
			{
				BufferedWriter bw = new BufferedWriter(new FileWriter(saveDir + 
						File.separator + "ranges" + GNUPLOT_PARTIAL_EXTENSION));
				
				bw.write("set xrange [" + xRange[0] + ":" + xRange[1] + "]\n");
				bw.write("set yrange [" + yRange[0] + ":" + yRange[1] + "]\n");
	
				bw.close();
				
				/*
				 * Send metadata for partial results visualizer
				 */
				
				partialResultOutput("xRange," + xRange[0] + "," + xRange[1]);
				partialResultOutput("yRange," + yRange[0] + "," + yRange[1]);
				partialResultOutput("dim," + xDim + "," + yDim);
				
			}
			catch (IOException e)
			{
				System.out.println("ERROR saving reachable ranges: " + e);
				hadError = true;
			}
		}
	}

	public static void flushBuffer()
	{
		if (saveThread == null)
		{
			if (!hadError)
			{
				hadError = true;
				System.out.println("ERROR: flushBuffer() called but save thread had not been started.");
			}
		}
		else if (!hadError)
			saveThread.flushBuffer();
	}
	
	// Send to visualizer, a successor was reached (guard = true)
	public static void reachedSuccessor(HyperRectangle hr)
	{
		if (visualizeSuccessors)
		{
			StringBuffer line = new StringBuffer();
			
			line.append("presucc");
			
			for (int d = 0; d < hr.dims.length; ++d)
				line.append("," + hr.dims[d].min + "," + hr.dims[d].max);
			
			partialResultOutput(line.toString());
		}
	}
	
	public static void postReset(HyperRectangle hr)
	{
		if (visualizeSuccessors)
		{
			StringBuffer line = new StringBuffer();
			
			line.append("postsucc");
			
			for (int d = 0; d < hr.dims.length; ++d)
			{
				line.append("," + hr.dims[d].min + "," + hr.dims[d].max);
			}
			
			partialResultOutput(line.toString());
		}
	}

	public static void newMode(String name, Collection <HyperRectangleTime> init)
	{
		modeName = name;
		
		int numDims = 1;
		
		if (init.size() > 0)
			numDims = init.iterator().next().rect.dims.length;
		
		StringBuffer rectString = new StringBuffer();
		
		for (HyperRectangleTime r : init)
		{
			rectString.append(r.getTime());
			rectString.append(";");
			
			for (int d = 0; d < numDims; ++d)
				rectString.append(r.rect.dims[d].min + ";" + r.rect.dims[d].max + ";");
		}
		
		partialResultOutput("mode," + name + "," + numDims + "," + 
				init.size() + "," + rectString.toString());
		
		if (reachParams.saveVisualization)
			currentVisualizationMatrix = modeMatricies.get(name); 
	}
	

	/**
	 * Add hr to currentVisualizationMatrix
	 * @param hr the rectangle to add
	 */
	private static void populateMatrix(HyperRectangle hr)
	{
		if ((xRange[0] > hr.dims[xDim].min || xRange[1] < hr.dims[xDim].max) ||
			(yRange[0] > hr.dims[yDim].min || yRange[1] < hr.dims[yDim].max))
		{
			if (!warnedOutOfBounds)
			{
				warnedOutOfBounds = true;
				ha.output("Warning: Some reachable states are outside of the visualization range.");
			}
		}
		
		double xMin = xRange[0];
		double yMin = yRange[0];
		
		double xIndexStart = (hr.dims[xDim].min - xMin) / xStep;
		double xIndexEnd = (hr.dims[xDim].max - xMin) / xStep;
		
		double yIndexStart = (hr.dims[yDim].min - yMin) / yStep;
		double yIndexEnd = (hr.dims[yDim].max - yMin) / yStep;
		
		int xStart = (int)Math.round(xIndexStart);
		int xEnd = (int)Math.round(xIndexEnd);
		
		int yStart = (int)Math.round(yIndexStart);
		int yEnd = (int)Math.round(yIndexEnd);
		
		for (int x = xStart; x <= xEnd; ++x) for (int y = yStart; y <= yEnd; ++y)
		{
			if (x < 0 || y < 0 
					|| x >= currentVisualizationMatrix[0].length 
					|| y >= currentVisualizationMatrix.length)
				continue;
			
			if (currentVisualizationMatrix[y][x] == false)
			{
				socketNeedsFlush = true;
				partialResultOutput("pt," + x + "," + y);
				
				currentVisualizationMatrix[y][x] = true;
			}
		}
	}
	 
	/**
	 * Downsample the simulation to one with less points (for graphing, for example)
	 * @param points the normal simulation
	 * @return the downsampled one
	 */
	public static ArrayList<HyperPoint> downSampleSimulation(ArrayList<HyperPoint> sim)
	{
		// we're going to down sample a little bit to speed this up
		double X_TOL = 5 * xStep;
		double Y_TOL = 5 * yStep;
		
		Point2D.Double lastSentPoint = null;
				
		ArrayList<HyperPoint> rv = new ArrayList<HyperPoint>();
	
		if (xDim != -1) // should send simulation over socket
		{
			for (int i = 0; i < sim.size(); ++i)
			{
				HyperPoint p = sim.get(i);
				boolean shouldSendPoint = false;
				Point2D.Double curPoint = null;
				
				if (p != null)
				{
					double x = p.dims[xDim];
					double y = p.dims[yDim];
					curPoint = new Point2D.Double(x, y);
					
					// always send first and last
					if (lastSentPoint == null || i == sim.size() - 1 || sim.get(i+1) == null) 
						shouldSendPoint = true;
					else
					{
						if (Math.abs(curPoint.x - lastSentPoint.x) > X_TOL ||
							Math.abs(curPoint.y - lastSentPoint.y) > Y_TOL)
						{
							shouldSendPoint = true;
						}
					}
				}
				else // p == null, always send discrete transitions 
					shouldSendPoint = true;
				
				if (shouldSendPoint)
					rv.add(p);
			}
		}
			
		return rv;
	}
	
	/**
	 * Send a simulation result to the partial result visualizer. This downsamples
	 * a little bit to speed things up
	 * @param sim the simulation result
	 */
	public static void socketSendSimulationResult(ArrayList <HyperPoint> sim)
	{
		// we're going to down sample a little bit to speed this up
		double X_TOL = 5 * xStep;
		double Y_TOL = 5 * yStep;
		
		Point2D.Double lastSentPoint = null;
		
		for (int i = 0; i < sim.size(); ++i)
		{
			HyperPoint p = sim.get(i);
			boolean shouldSendPoint = false;
			Point2D.Double curPoint = null;
			
			if (p != null)
			{
				double x = p.dims[xDim];
				double y = p.dims[yDim];
				curPoint = new Point2D.Double(x, y);
				
				// always send first and last
				if (lastSentPoint == null || i == sim.size() - 1 || sim.get(i+1) == null) 
					shouldSendPoint = true;
				else
				{
					if (Math.abs(curPoint.x - lastSentPoint.x) > X_TOL ||
						Math.abs(curPoint.y - lastSentPoint.y) > Y_TOL)
					{
						shouldSendPoint = true;
					}
				}
			}
			else // p == null, always send discrete transitions 
				shouldSendPoint = true;
			
			if (shouldSendPoint)
			{
				lastSentPoint = curPoint;
				
				if (curPoint == null)
					partialResultOutput("simpt,null");
				else
					partialResultOutput("simpt," + curPoint.x + "," + curPoint.y);
			}
		}
		
		partialResultOutput("simflush");
		flushSocket();
	}
	
	
	/**
	 * Save the initial states for a discrete mode to the results directory. This
	 * corresponds to an option in model options.
	 * 
	 * They will be saved using initial-#-<modeName>.hrt
	 * @param init the states to save
	 */
	public static void saveInitialStates(Collection<HyperRectangleTime> init)
	{
		// save to saveDir
		String filename = "initialStates-" + 
				(numInitialStatesSaved++) + "-" + modeName + ".txt";
		
		System.out.println("Saving initial states to " 
				+ filename);
		try
		{
			String path = saveDir + File.separator + filename;
			BufferedWriter out = new BufferedWriter(new FileWriter(path));
			
			for (HyperRectangleTime hrt : init)
			{
				HrmFormat.writeRect(out, hrt.rect, modeName);
			}
			
			out.close();
		}
		catch (IOException e)
		{
			System.out.println("Error writing initial states: " + e);
		}
	}
	
	private class SaveThread extends Thread
	{
		private boolean exit = false;
		public boolean exited = false;
		private BufferedWriter reachsetWriter;
		
		LinkedList <HyperRectangle> outputBuffer = new LinkedList <HyperRectangle>(); 
		
		public SaveThread(String path) 
				throws IOException
		{
			if (reachParams.saveReachSet)
			{
				reachsetWriter = new BufferedWriter(new FileWriter(path));
				HrmFormat.addHeaders(reachsetWriter);
			}
		}
		
		/**
		 * Stall the current thread until the buffer is empty
		 */
		public void flushBuffer()
		{
			while (outputBuffer.size() > 0)
			{
				try
				{
					Thread.sleep(10);
				}
				catch (InterruptedException e)
				{
					System.out.println("Interrupted when sleeping" + e);
				}
			}
		}

		/**
		 * Add some states to be printed out
		 * @param buf the states to add
		 */
		public synchronized void dumpBuffer(Collection<HyperRectangle> buf)
		{
			outputBuffer.addAll(buf);
		}

		public void run()
		{
			while (!exit)
			{
				try
				{
					outputSomeRects();
				}
				catch (IOException e)
				{
					System.out.println("IOEXCEPTION when writing output: " + e);
					hadError = true;
					break;
				}
				catch (Exception e)
				{
					System.out.println("EXCEPTION in file-saving thread: " + e);
					e.printStackTrace();
					hadError = true;
					break;
				}
				
				try
				{
					if (outputBuffer.size() == 0)
						Thread.sleep(10);
				}
				catch (InterruptedException e)
				{
					hadError = true;
					System.out.println("InterruptedException in SaveThread: " + e);
				}
			}
			
			try
			{
				if (reachParams.saveReachSet)
					reachsetWriter.close();
			}
			catch (IOException e)
			{
				System.out.println("EXCEPTION when closing output file: " + e);
				hadError = true;
			}
			
			// nothing should be added or read if we encountered an error
			if (hadError == true)
				outputBuffer = null;
			
			exited = true;
		}
		
		/**
		 * Output some of the states from outputBuffer to the file
		 * @throws IOException if a file error occurs
		 */
		private synchronized void outputSomeRects() throws IOException
		{
			final int RECTS_PER_ITERATION = 500;
			
			socketNeedsFlush = false;
			
			for (int i = 0; i < RECTS_PER_ITERATION; ++i)
			{
				if (outputBuffer.size() == 0)
					break;
				
				HyperRectangle hr = outputBuffer.removeFirst();
				
				if (reachParams.saveReachSet)
					HrmFormat.writeRect(reachsetWriter, hr, modeName);
				
				if (reachParams.saveVisualization)
					populateMatrix(hr);
			}
			
			if (socketNeedsFlush)
			{
				partialResultOutput("flush");
				flushSocket();
			}
		}

		public void doExit()
		{
			exit = true;
		}
	}

	/**
	 * Send the pseudo-invariant data over the visualize socket
	 * @param simulation the simulation of points used
	 * @param gradiant the gradient at the last point
	 */
	public static void sendPseudoInvariant(Collection <HyperPoint> simulation, double[] gradient)
	{
		if (partialResultSocket != null)
		{
			StringBuffer line = new StringBuffer();
			
			line.append("pi2"); // 2nd version of this, prevent naming conflicts
			line.append(","+simulation.size());
			
			for (HyperPoint p : simulation)
			{
				double x = p.dims[xDim];
				double y = p.dims[yDim];
				
				line.append("," + x + "," + y);
			}
			
			double xDer = gradient[xDim];
			double yDer = gradient[yDim];
			
			line.append("," + xDer + "," + yDer);
			
			partialResultOutput(line.toString());
		}
	}

	public static void updateCurrentStates(Collection<HyperRectangleTime> states)
	{
		for (HyperRectangleTime hrt : states)
		{
			HyperRectangle r = hrt.rect;
			StringBuffer line = new StringBuffer();
			
			line.append("cur");
			
			for (int d = 0; d < r.dims.length; ++d)
				line.append("," + r.dims[d].min + "," + r.dims[d].max);
			
			partialResultOutput(line.toString());
		}
		
		partialResultOutput("curdone");
	}
}
