package reachability.compute;

import java.util.Collection;
import java.util.Map.Entry;
import java.util.TreeMap;

import com.stanleybak.hycreate.containers.ModelSimulationOptions.EnumDerivativesType;

import reachability.automaton.HybridAutomaton;
import reachability.geometry.HyperPoint;
import reachability.geometry.HyperRectangle;

/**
 * Used to enumerate all possiblities of derivative
 * @author Stanley Bak
 *
 */
public class DerivativeTypeEnumerator
{
	private int numDims;
	private EnumDerivativesType type;
	private int curIteration = 0;
	
	// should this dimension be enumerated over? only if not average derivative
	boolean shouldEnumerateDim[];
	
	public DerivativeTypeEnumerator(HybridAutomaton ha, 
			TreeMap<String, Collection<HyperRectangle>> init, 
			double stepSize, int maxJumps,
			EnumDerivativesType type)
	{
		this.type = type;
		this.numDims = ha.getDimensions();
		
		if (type == EnumDerivativesType.AUTO_ENUMERATE)
		{
			// run a simulation in order to auto-enumerate
			autoDetectEnumeration(ha, init, stepSize, maxJumps);
		}
		else if (type == EnumDerivativesType.ENUMERATE_ALL)
		{
			shouldEnumerateDim = new boolean[ha.getDimensions()];
			
			for (int d = 0; d < shouldEnumerateDim.length; ++d)
				shouldEnumerateDim[d] = true;
		}
	}
	
	/**
	 * Simulate to detect which dimensions we should enumerate
	 * @param ha
	 * @param init
	 * @param stepSize
	 */
	private void autoDetectEnumeration(HybridAutomaton ha,
			TreeMap<String, Collection<HyperRectangle>> init, double stepSize, int maxJumps)
	{
		Entry<String, Collection<HyperRectangle>> e = init.entrySet().iterator().next();
		String modeName = e.getKey();
		HyperPoint startPoint = e.getValue().iterator().next().center();
		
		RungeKutta.startTrackingNondeterminism(numDims);
		Simulator.simulate(ha, stepSize, modeName, startPoint, maxJumps);
		shouldEnumerateDim = RungeKutta.stopTrackingNondeterminism();
	}

	/**
	 * Get the number of points in this enumeration
	 * @return
	 */
	public int getNumEnumPoints()
	{
		int rv = 1;
		
		if (type != EnumDerivativesType.AVERAGE_DERIVATIVE)
		{
			for (int d = 0; d < shouldEnumerateDim.length; ++d)
			{
				if (shouldEnumerateDim[d])
					rv *= 2;
			}
		}
		
		return rv;
	}
	
	/**
	 * Get the next sample strategy being enumerated. This returns null if there are no more
	 * @return
	 */
	public SampleType[] next()
	{
		SampleType[] rv = null;
		int maxIterator = getNumEnumPoints();

		if (curIteration < maxIterator)
		{
			rv = new SampleType[numDims];
			
			if (type == EnumDerivativesType.AVERAGE_DERIVATIVE)
			{
				for (int d = 0; d < numDims; ++d)
					rv[d] = SampleType.SAMPLE_AVERAGE;
			}
			else 
			{
				/*
				 * We do this by considering an integer as a bit array of true/false values, where
				 * 0=false means min, and 1=true means max. The length of the bit array is the number
				 * of dimensions. If we iterate from 0 to 2^dim, we will have iterated all the possibilities.
				 */
				
				// next iterate from 0 to maxIterator (try each bit-array combination)
				
				// extract each dimension's boolean min/max values from curIteration
				int mask = 0x01;
				for (int dimIndex = 0; dimIndex < numDims; ++dimIndex)
				{
					if (shouldEnumerateDim[dimIndex])
					{
						boolean isMin = (curIteration & mask) == 0;
						mask = mask << 1;
						
						// assign the extracted value
						rv[dimIndex] = isMin ? SampleType.SAMPLE_MIN : SampleType.SAMPLE_MAX;
					}
					else
					{
						// it's fixed, just use min
						rv[dimIndex] = SampleType.SAMPLE_MIN;
					}
				}
			}
		}
			
		if (rv != null)
			++curIteration;
		
		return rv;
	}
	
	
}
