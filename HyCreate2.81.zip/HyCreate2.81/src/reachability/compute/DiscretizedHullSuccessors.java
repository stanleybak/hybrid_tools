package reachability.compute;

import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import reachability.geometry.HyperRectangle;
import reachability.geometry.HyperRectangleTime;
import reachability.geometry.Interval;

/**
 * This is used for more accurate successor computation. We use a discretized version of convex
 * hull
 * @author Stan
 *
 */
public class DiscretizedHullSuccessors
{
	// map successor mode -> discrete state (as a string) -> rectangle 
	private Map <String, Map <String, HyperRectangleTime>> discretizedHullData = null;

	public DiscretizedHullSuccessors()
	{
		discretizedHullData = new TreeMap<String, Map <String, HyperRectangleTime>>();
	}
	
	public TreeMap <String, Collection <HyperRectangleTime>> 
		discretizedHullCreateModeSuccessors()
	{
		TreeMap <String, Collection <HyperRectangleTime>> rv = 
				new TreeMap <String, Collection <HyperRectangleTime>>();
		
		for (Entry<String, Map<String, HyperRectangleTime>> e : discretizedHullData.entrySet())
		{
			String name = e.getKey();
			Collection <HyperRectangleTime> rects = e.getValue().values();

			rv.put(name, rects);
		}
		
		return rv;
	}
	
	// Add a rectangle to the successors
	public void discretizedHullAggregate(String mode, HyperRectangleTime hrt, 
			double[] gridSize)
	{
		// first get the set for the mode we're concerned with
		Map <String, HyperRectangleTime> set = discretizedHullData.get(mode);
		
		if (set == null)
		{
			set = new TreeMap <String, HyperRectangleTime>();
			discretizedHullData.put(mode, set);
		}
		
		int maxIterator = 1;
		HyperRectangle hr = hrt.rect;
		int numDims = hr.dims.length;
		
		int ranges[][] = new int[numDims][2];
		
		for (int d = 0; d < numDims; ++d)
		{
			double gridDelta = gridSize[d];
			
			int min = (int)Math.floor(hr.dims[d].min / gridDelta);
			int max = (int)Math.ceil(hr.dims[d].max / gridDelta);
		
			// floor can equal ceil if value is exact
			if (max == min)
				max++;
			
			ranges[d][0] = min;
			ranges[d][1] = max;
			
			maxIterator *= (max - min);
		}
		
		// add all the individual sub-rectangles
		for (int iterator = 0; iterator < maxIterator; ++iterator)
		{
			int[] dimValues = new int[numDims];
			int iteratorCopy = iterator;
			
			for (int d = 0; d < numDims; ++d)
			{
				int dimMod = ranges[d][1] - ranges[d][0];
				dimValues[d] = ranges[d][0] + (iteratorCopy % dimMod);
				
				iteratorCopy /= dimMod;
			}
			
			// ok, dimValues is the current value
			HyperRectangle currentBox = createCurrentBox(dimValues, gridSize);
			
			String keyString = dimToKeyString(dimValues);
			
			HyperRectangleTime current = set.get(keyString);
			
			// inter is the intersection of the current box and the successor rectangle, should be nonnull
			HyperRectangle inter = hr.intersection(currentBox);
			
			if (inter == null)
			{
				for (int i = 0; i < gridSize.length; ++i)
					System.out.println(": Grid Size[" + i + "] = " + gridSize[i]);
				
				throw new RuntimeException("Intersection of hr=" + hr + " and cb=" + currentBox + " was null");
			}
			
			if (current == null)
			{
				HyperRectangleTime newHrt = new HyperRectangleTime(inter, hrt.getTime());
				set.put(keyString, newHrt);
			}
			else
			{
				// there exists a rectangle already, do convex hull here (will be smaller than one grid size)
				double minTime = Math.min(hrt.getTime(), current.getTime());
				
				HyperRectangle hull = HyperRectangle.convexHull(current.rect, inter);
				
				set.put(keyString, new HyperRectangleTime(hull, minTime));
			}
		}
	}
	
	public int getCount()
	{
		int sum = 0;
		
		for (Entry<String, Map<String, HyperRectangleTime>> e : discretizedHullData.entrySet())
			sum += e.getValue().size();
		
		return sum;
	}
		
	/**
	 * Create the box corresponding to these dimension values, using the current gridSize
	 * @param dimValues
	 * @return the corresponding bix
	 */
	private HyperRectangle createCurrentBox(int[] dimValues, double[] gridSize)
	{
		HyperRectangle rv = new HyperRectangle(dimValues.length);
		
		for (int d = 0; d < dimValues.length; ++d)
		{
			double gridDelta = gridSize[d];
			
			double min = dimValues[d] * gridDelta;
			double max = (1 + dimValues[d]) * gridDelta;
			
			rv.dims[d] = new Interval(min, max);
		}
		
		return rv;
	}

	private String dimToKeyString(int[] vals)
	{
		StringBuffer rv = new StringBuffer();
		
		for (int d = 0; d < vals.length; ++d)
			rv.append(vals[d] + ",");
		
		return rv.toString();
	}
}
