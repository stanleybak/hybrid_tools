package reachability.compute;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;

import main.Util;
import reachability.automaton.AutomatonMode;
import reachability.automaton.Dynamics;
import reachability.automaton.HybridAutomaton;
import reachability.automaton.Transition;
import reachability.geometry.HyperRectangle;
import reachability.geometry.HyperRectangleTime;
import reachability.geometry.Interval;

/**
 * Use the a static face lifting approach, parameterized by grid size, face size, and regrid size
 * @author Stanley Bak (sbak2@illinois.edu)
 * 8-2011
 */
public class FaceLift
{
	private static long timerStart = 0;
	private static long statusPrintMs = 100;
	private HybridAutomaton ha;
	private AutomatonMode mode;
	
	// parameters
	public Dynamics dynamics = null;
	private ReachComputer reachComputer = null;
	public double[] baseSize = null; // the base size for the other measurements
	public double desiredTimeStep = 0;
	public int rectSplitLimit = 500; // TODO, make this a parameter
	private double[] splitRatio = null; // the relative (to the grid size) rectangle width before splitting
	private  double[] shouldSplitSize = null; // the absolute rectangle width before splitting
	private Collection <HyperRectangleTime> initialHyperRectangleTimes = null; // initial regions
	public double deltaReachTime = Double.MAX_VALUE; // maximum reach time; if time-based reachability is being done
	private int numDimensions;
	
	PseudoInvariantsChecker piChecker = null;
	
	// computation result
	private Collection <HyperRectangle> reachableStatesBuffer = null;
	public int reachableStatesCount = 0;
	
	/**
	 * Creates a new instance for a FaceLift operation
	 * @param ha the hybrid automaton instance, used for printing output
	 * @param mode the mode we're coming for, used for checking for successors
	 * @param numDimenions the number of real dimensions
	 */
	public FaceLift(HybridAutomaton ha, AutomatonMode mode, int numDimensions) 
	{
		this.ha = ha;
		this.mode = mode;
		this.numDimensions = numDimensions;
		
		switch (ha.reachParams.reachMethod)
		{
			case MFL_RECONSTRUCT:
				System.out.println("Using mixed face lifting with neighborhood reconstruction.");
				reachComputer = new MFL_Reconstruct(this);
			break;
			
			default:
				throw new RuntimeException("Unsupported reachability method: " + ha.reachParams.reachMethod);
		}
	}
	
	/**
	 * Assign the dynamics to use
	 * @param d the Dynamics class to use when performing reachability
	 */
	public void setDynamics(Dynamics d)
	{
		dynamics = d;
	}
	
	/**
	 * Sets the maximum time to perform reachability for, default is infinity
	 * @param t the new time bound
	 */
	public void setDeltaReachTime(double t)
	{
		if (t < 0)
			throw new RuntimeException("Reachability Time < 0!");
		
		deltaReachTime = t;
	}
	
	/**
	 * Sets the size of the grid for the regridding operation
	 * @param g the grid width, for each dimension
	 */
	public void setGridSize(double[] g)
	{
		baseSize = g;
	}
	
	/**
	 * Sets the relative (to the grid size) ratio for doing the regridding operation if a face lifting
	 * rectangle gets to large 
	 * @param r the ratio, for each dimension
	 */
	public void setRegridRatio(double[] r)
	{
		splitRatio = r;
	}
	
	public void setDesiredTimeStep(double ts)
	{
		desiredTimeStep = ts;
	}
	
	/**
	 * Get the number of reachable states during the computation
	 * @return the area of the reachable states
	 */
	public int getReachableStatesCount()
	{
		return reachableStatesCount;
	}
	
	/**
	 * Do the face lifting computation with the parameters set using the set* functions
	 * @param timeoutMs a timeout value (number of milliseconds). 0 means never timeout
	 * @return did the computation converge and finish in the given time?
	 */
	public boolean compute(long timeoutMs)
	{
		if (dynamics == null)
			throw new RuntimeException("Dynamics class was not assigned");
		
		if (baseSize == null)
			throw new RuntimeException("Grid Size was not set");
		else if (baseSize.length == 0)
		{
			baseSize = ha.getBaseSize();
			System.out.println("Using hybrid automaton base size of " + Util.doubleArrayString(baseSize));
			
			for (int d = 0; d < baseSize.length; ++d)
			{
				if (baseSize[d] == 0)
					throw new RuntimeException("baseSize[" + d + "] was zero");
			}
		}
		
		if (splitRatio == null)
			throw new RuntimeException("Regrid Ratio was not set");
		
		if (desiredTimeStep == 0)
			throw new RuntimeException("Desired Time Step was not set");
		
		if (initialHyperRectangleTimes == null)
			throw new RuntimeException("Initial States was not set");
		
		if (!validInitialRegionDimensions())
			throw new RuntimeException("Initial hyperrectangle+times dimensions do not all match dynamics dimensions (" 
										+ numDimensions + ") + 1 (for time)");
		
		if (ha.isUsePseudoInvariant())
			piChecker = new PseudoInvariantsChecker(ha, mode.getModeDynamics(), desiredTimeStep, deltaReachTime);
		
		boolean converged = false;
		
		while (true)
		{
			converged = doGlobalFaceLifting(timeoutMs);
			
			if (!converged) // timeout
				break;
			
			if (piChecker != null && piChecker.hasSuccessorStates())
			{
				ha.output("Pseudo-invariant was reached by all states.");
				
				initialHyperRectangleTimes = piChecker.getAndClearSuccessorStates();
			}
			else
				break;
		}
		
		return converged;
	}

	/**
	 * Checks if the number of dimensions is valid for the initial states
	 * @return true iff there are no issues
	 */
	private boolean validInitialRegionDimensions()
	{
		boolean valid = true;
		
		for (HyperRectangleTime hrt : initialHyperRectangleTimes)
		{
			if (hrt.rect.dims.length != numDimensions)
			{
				valid = false;
				break;
			}
		}
		
		return valid;
	}

	// parameter includes time dimension
	private void initFaceLifting(Collection <HyperRectangleTime> initialHrts)
	{
		final int NUM_DIM = numDimensions;
		
		ComputationResultSaveThread.newMode(mode.name, initialHrts);
		
		reachableStatesBuffer = new ArrayList <HyperRectangle>();
		
		mode.successorAggregator.setGridSize(baseSize);
		
		if (piChecker != null)
		{
			piChecker.setGridSize(baseSize);
			piChecker.setup(PseudoInvariantsChecker.getCenterOfHull(initialHrts), 
								PseudoInvariantsChecker.getMinTime(initialHrts));
		}
		
		shouldSplitSize = new double[NUM_DIM];
		
		for (int d = 0; d < NUM_DIM; ++d)
			shouldSplitSize[d] = splitRatio[d] * baseSize[d];
		
		// insert the initial states
		for (HyperRectangleTime initHrt : initialHrts)
		{			
			HyperRectangle initRect = initHrt.rect; // shallow copy is okay

			Interval tt = dynamics.getTimeTrigger(initRect);
			
			if (tt != null && tt.max <= 0)
			{
				// urgent transition
				addSuccessors(initHrt.rect, initHrt.getTime());
				
				continue;
			}
			else if (!intersectsInvariant(initRect))
				continue;
			
			if (shouldSplit(initRect))
			{
				double time = initHrt.getTime();
				
				LinkedList <HyperRectangle> splitStates = split(initRect);
				
				for (HyperRectangle hr : splitStates)
				{
					HyperRectangleTime hrt = new HyperRectangleTime(hr, time);
					
					if (intersectsInvariant(hrt.rect))
					{
						if (piChecker == null || piChecker.checkAddPseudoInvariant(hrt, 
								reachComputer.getNumRects(), rectSplitLimit))
							reachComputer.addRect(hrt);
					}
				}
			}
			else // insert state
			{
				if (piChecker == null || piChecker.checkAddPseudoInvariant(initHrt, 
						reachComputer.getNumRects(), rectSplitLimit))
					reachComputer.addRect(initHrt);
			}
		}
		
		ha.output("Initialized Face lifting, number of pending Rectangles: " + reachComputer.getNumRects());
		
		if (reachComputer.getNumRects() > rectSplitLimit && piChecker != null)
		{
			ha.output("Initial pending rectangles exceeds limit; disabling pseudo-invariants.");
			piChecker.disableFurtherPseudoInvariants();
		}
		else if (piChecker != null)
		{
			ha.output("Using pseudo-invariants.");
			piChecker.enablePseudoInvariants();
		}
	}

	/**
	 * Do face lifting until it converges, or timeouts
	 * @param timeoutMs the timeout, in milliseconds. If 0 then no timeout
	 * @return true iff converged (no timeout)
	 */
	private boolean doGlobalFaceLifting(long timeoutMs)
	{	
		boolean converged = true;
		
		float operationsPerPollTime = 1.0f;
		
		// initialize the internal data structures
		initFaceLifting(initialHyperRectangleTimes);
		
		long nextPrintMs = System.currentTimeMillis() + statusPrintMs;
		
		// while there are steps left to process
		while (reachComputer.hasRemainingStates())
		{
			int numOps = (int)operationsPerPollTime;
			
			for (int x = 0; x < numOps && reachComputer.hasRemainingStates(); ++x)
			{
				HyperRectangleTime q = reachComputer.removeFirstState();
				faceLiftSingleOperation(q);
			}
			
			// pass the current reachable set to the save thread
			ComputationResultSaveThread.dumpBuffer(reachableStatesBuffer);
			reachableStatesBuffer.clear();
			
			long now = System.currentTimeMillis();
			
			if (timeoutMs > 0 && (now - FaceLift.timerStart) > timeoutMs)
			{
				converged = false;
				break;
			}

			if (now >= nextPrintMs && reachComputer.hasRemainingStates())
			{
				// update visualizer current rects
				ComputationResultSaveThread.updateCurrentStates(reachComputer.getStates());
				
				// periodic printing
				double time = reachComputer.peakTime();
				long difMs = now - FaceLift.timerStart;
				
				ha.output(difMs + " ms - Pending rectangles: " + reachComputer.getNumRects() + 
						", reach time: " + Util.doubleToString(time));
				
				// repoll time since dumpBuffer may take time if partial visualization needs to be saved
				nextPrintMs = System.currentTimeMillis() + statusPrintMs;
				operationsPerPollTime = 1.0f;
			}
			else
			{
				operationsPerPollTime *= 1.2;
			}
		}
		
		// save the remaining states
		ComputationResultSaveThread.updateCurrentStates(reachComputer.getStates());
		ComputationResultSaveThread.dumpBuffer(reachableStatesBuffer);
		ComputationResultSaveThread.flushBuffer();
		
		return converged;
	}

	/**
	 * Apply the reachability method to q. States reached are inserted back into Q
	 * @param q the rectangle to apply the reachability method to
	 */
	private void faceLiftSingleOperation(HyperRectangleTime q)
	{
		double originalTime = q.getTime();
		
		if (originalTime <= deltaReachTime && // within the time bound
			intersectsInvariant(q.rect) && // within the mode invariant
			(piChecker == null || piChecker.isInsidePseudoInvariant(q.rect))) // within pseudo-invariant
		{
			// prepare for the lifting operation by setting max encountered to the current rect
			HyperRectangle originalRect = new HyperRectangle(q.rect);
			
			// perform the continuous successor operation, q becomes the successor state
			boolean converged = reachComputer.doSingleOperation(q);
			
			HyperRectangle encountered = HyperRectangle.convexHull(originalRect, q.rect);
			
			// add all states encountered during lifting (the convex hull of the old and new)
			// into the reachableStates set, using the original time 			
			addNewStates(encountered, originalTime); 
			
			// add possible successors based on the encountered states as well
			addSuccessors(encountered, originalTime);
			
			if (piChecker == null || 
					piChecker.checkAddPseudoInvariant(q, 
					reachComputer.getNumRects(), rectSplitLimit))
			{
				if (!converged)
				{
					if (shouldSplit(q.rect))
					{
						for (HyperRectangle hr : split(q.rect))
							reachComputer.addRect(new HyperRectangleTime(hr, q.getTime()));
					}
					else
						reachComputer.addRect(q);
				}
			}
		}
	}

	/**
	 * Check if any part of this hyperrectangle intersects with the state invariant, and,
	 * if it exists, the pseudo-invariant
	 * 
	 * hr can also be modified in place to restrict it to the invariant region
	 * 
	 * @param hr the rect to check
	 * @return true if any part of the rectangle is in the invariant
	 */
	private boolean intersectsInvariant(HyperRectangle hr)
	{
		return dynamics.intersectsInvariant(hr);
	}

	/**
	 * Add the convex hull of encountered state to the reach set
	 * @param q the new states reached (convex hull of old and new state_)
	 * @param minTime the minimum time present in the convex hull of the encountered state
	 *                this is the initial time before lifting, used for successors
	 */
	private void addNewStates(HyperRectangle hr, double minTime)
	{
		reachableStatesCount++;
		
		reachableStatesBuffer.add(hr);
	}
	
	private void addSuccessors(HyperRectangle hr, double minTime)
	{
		// check for outgoing transitions from this state
		for (Transition t : mode.successors)
		{
			if (t.intersectsGuard(hr)) 
			{
				HyperRectangle copy = new HyperRectangle(hr);
				
				ComputationResultSaveThread.reachedSuccessor(hr);
				
				t.applyReset(copy);
				
				ComputationResultSaveThread.postReset(copy);
				
				HyperRectangleTime hrt = new HyperRectangleTime(copy, minTime);
				
				mode.addSuccessorState(t.getSuccessorMode(), hrt);
			}
		}
	}
	
	/**
	 * Split q and return the resultant states.
	 * @param q the state to split
	 * @return the new states
	 */
	private LinkedList <HyperRectangle> split(HyperRectangle q)
	{
		int splitLimit = Integer.MAX_VALUE;
		
		if (rectSplitLimit > 0)
			splitLimit = rectSplitLimit; 
			
		int curRects = reachComputer.getNumRects() - 1;
		int afterSplitRects = 1;
		
		LinkedList <HyperRectangle> rv = new LinkedList <HyperRectangle>();
		int numDims = q.dims.length;
		
		// first figure out how many times we have to split each dimension
		int[] split = new int[numDims];
		
		for (int d = 0; d < numDims; ++d)
		{
			double width = q.dims[d].max - q.dims[d].min;
			
			if (curRects + afterSplitRects > splitLimit)
				split[d] = 1;
			else
			{
				//split[d] = (int)(Math.ceil(width / baseSize[d]));
				split[d] = (int)(Math.ceil(width / shouldSplitSize[d]));
			}
			
			if (split[d] == 0)
				split[d] = 1;

			// if we're going to go over the limit, only do it by a factor of 2
			while (curRects + afterSplitRects*split[d] > splitLimit && split[d] > 2)
				--split[d];

			afterSplitRects *= split[d];
		}
		
		// next, split every dimension by split[n]
		// this results in PI_n=0_to_numDims(split[n]) states
		int stateIterator = 1;
		
		for (int d = 0; d < numDims; ++d)
			stateIterator *= split[d];

		// iterate all the new states, and accumulate into rv
		for (int s = 0; s < stateIterator; ++s)
		{
			HyperRectangle newRect = new HyperRectangle(numDims);
			
			// extract each dimension's value from numStates
			int div = 1;
			for (int d = 0; d < numDims; ++d)
			{
				double totalWidth = q.dims[d].max - q.dims[d].min;
				double dimWidth = totalWidth / (double)split[d];
				double curDimMin = q.dims[d].min + dimWidth * ((s / div) % split[d]);
				
				div *= split[d];
				
				// assign the current dimension of the point
				newRect.dims[d] = new Interval(curDimMin, curDimMin + dimWidth);
			}
			
			rv.add(newRect);
		}
		
		return rv;
	}

	/**
	 * Should we split q because it's gotten too large?
	 * @param q the rectangle to check
	 * @return true iff a split is necessary
	 */
	private boolean shouldSplit(HyperRectangle q)
	{
		boolean overLimit = false;
		
		if (ha.reachParams.splitLargeRectangles &&
				rectSplitLimit > 0 &&
				reachComputer.getNumRects() < rectSplitLimit)
		{
			for (int d = 0; d < q.dims.length; ++d)
			{
				double length = q.dims[d].max - q.dims[d].min;
				
				if (length > shouldSplitSize[d])
				{
					overLimit = true;
					break;
				}
			}
		}
		
		return overLimit;
	}
	
	/**
	 * Gets the size of the grid for the regridding operation
	 * @return the grid width, for each dimension
	 */
	public double[] getGridSize()
	{
		return baseSize;
	}

	/**
	 * Set the initial states for the computation
	 * @param init the initial hyper rectangles
	 */
	public void setInitialStates(Collection<HyperRectangleTime> init)
	{
		initialHyperRectangleTimes = init;
	}

	public static void startTimer()
	{
		FaceLift.timerStart = System.currentTimeMillis();
	}
}
