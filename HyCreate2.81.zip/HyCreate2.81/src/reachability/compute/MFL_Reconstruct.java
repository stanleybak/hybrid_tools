package reachability.compute;

import reachability.automaton.Dynamics;
import reachability.geometry.HyperRectangle;
import reachability.geometry.HyperRectangleTime;
import reachability.geometry.Interval;

/**
 * Mixed face lifting with neighborhood reconstruction based on minTime
 * 
 * @author Stanley Bak
 *
 */
public class MFL_Reconstruct extends ReachComputer
{
	private FaceLift parent;
	
	public MFL_Reconstruct(FaceLift parent)
	{
		this.parent = parent;
	}

	public boolean doSingleOperation(HyperRectangleTime from)
	{
		return flReconstructRectangle(from, parent);
	}
	
	/**
	 * Perform one step of face lifting for one hyperrectangle. Do the lifting in place
	 * @param q the rectangle to lift
	 * @param fl the FaceLift object containing the faceSize/dynamics
	 * @return if the lifting converged
	 */
	private static boolean flReconstructRectangle(HyperRectangleTime q, FaceLift fl)
	{
		boolean converged = false;
		HyperRectangle r = q.rect;
		
		// get the derivative (min and max) for every face lifting and store it in allDers
		Interval[] faceWidths = extractFaceWidths(r, fl);
		
		Interval[] allDers = getAllDerivatives(fl.dynamics, faceWidths, r);
		
		// minTime stores the minimum time time through each of the lifting regions
		double minTime = computeMinMaxTime(faceWidths, allDers).min;
		
		if (minTime < Double.MAX_VALUE)
		{
			int MAX_ITERATIONS = 7;
			double wantedMinTime = fl.desiredTimeStep;
			Interval wantedMinTimeInterval = new Interval(0.9 * wantedMinTime, 1.1 * wantedMinTime);
			
			Interval[] newFaceWidths = faceWidths;
			
			// reconstruct neighborhoods, try to approximate minTime
			for (int it = 0; it < MAX_ITERATIONS; ++it)
			{
				newFaceWidths = constructNewFaceSize(allDers, wantedMinTime);
				
				// Reconstruct allDers based on minTime
				allDers = getAllDerivatives(fl.dynamics, newFaceWidths, r);
				
				// there may be a new minTime since the neighborhoods are different
				Interval newMinTime = computeMinMaxTime(newFaceWidths, allDers);
				
				//System.out.println("it: " + it + ", time range = [" + newMinTime.min + 
				//		", " + newMinTime.max + " (wanted " + wantedMinTime + ")");
				
				minTime = newMinTime.min;
				
				// if we're within 10%, exit
				if (wantedMinTimeInterval.contains(newMinTime))
				//if (wantedMinTimeInterval.contains(minTime))
				{
					//System.out.println(": close enough, iteration = " + it + ", minTime = " + minTime);
					break;
				}
			}
		}
		
		if (minTime < Double.MAX_VALUE)
		{
			boolean strictlyInward = true;
			
			// time trigger might affect lifting time (minTime)
			Interval timeTrigger = fl.dynamics.getTimeTrigger(r);
			
			if (timeTrigger != null)
			{	
				if (timeTrigger.min > 0 && timeTrigger.min < minTime)
					minTime = timeTrigger.min;
				else if (timeTrigger.max >= 0 && timeTrigger.max < minTime)
					minTime = timeTrigger.max;
			}
						
			if (minTime == 0) // possibly due to time trigger
			{
				converged = true;
			}
			else
			{
				// advance time in place
				q.setTime(q.getTime() + minTime);
				
				// lift each face by minTime
				for (int d = 0; d < r.dims.length; ++d)
				{
					Interval dimDers = allDers[d];
					
					// in-place lifting
					r.dims[d].min += minTime * dimDers.min;
					r.dims[d].max += minTime * dimDers.max;
					
					// if there are outward derivatives
					if (dimDers.min < 0 || dimDers.max > 0)
						strictlyInward = false;
				}
				
				// if all the derivatives are inward, we've converged
				if (strictlyInward)
					converged = true;
			}
		}
		else
			converged = true; // all derivatives are zero
		
		// TODO make this a setting
		/*if (rectTooLarge(r, fl))
		{
			throw new RuntimeException("Error: Rectangle became excessively large, " +
					"likely too much error in approximation.");
		}*/
		
		return converged;
	}

	/**
	 * Construct a new face size based on the time to cross. This will shrink the face size in some of the
	 * dimensions.
	 * @param originalFaceSize the original face widths used (will not be larger)
	 * @param allDers the derivatives in the neighborhoods of the original faces
	 * @param minTime the minimum time needed to cross the neighborhoods
	 * @return new, smaller, face sizes with an approximately similar minTime
	 */
	private static Interval[] constructNewFaceSize(Interval[] allDers,
			double minTime)
	{
		int numDims = allDers.length;
		Interval[] rv = new Interval[numDims];
		
		for (int d = 0; d < numDims; ++d)
		{
			Interval i = new Interval();
			i.min = Math.abs(allDers[d].min) * minTime;
			i.max = Math.abs(allDers[d].max) * minTime;
			
			rv[d] = i;
		}
		
		return rv;
	}

	/**
	 * Compute the min/max time to pass through each of the neighborhoods
	 * @param faceWidths the face-lifting width for each face
	 * @param allDers the derivatives for reach face
	 * @return
	 */
	private static Interval computeMinMaxTime(Interval[] faceWidths, Interval[] allDers)
	{
		Interval rv = new Interval(Double.MAX_VALUE, -Double.MAX_VALUE);
		
		// compute minTime
		for (int d = 0; d < allDers.length; ++d)
		{
			Interval dimDers = allDers[d];
			double[] ders = {Math.abs(dimDers.min), Math.abs(dimDers.max)};
			double[] widths = {faceWidths[d].min, faceWidths[d].max};
			// we want time at this step, so use the absolute value of the derivative here
			
			for (int i = 0; i < ders.length; ++i)
			{
				double der = ders[i];
				double width = widths[i];
					
				if (der <= 0.00000001) // if derivative is zero, time is infinite
					continue;
				
				double time = width / der;
				
				if (time < rv.min)
					rv.min = time;
				
				if (time > rv.max)
					rv.max = time;
			}
		}
		return rv;
	}

	private static Interval[] getAllDerivatives(Dynamics dy, Interval[] faceWidths, HyperRectangle r)
	{
		Interval allDers[] = new Interval[r.dims.length];
		
		for (int d = 0; d < r.dims.length; ++d)
		{
			// get the derivative in both the minimum and maximum direction for each dimension
			double minDer = getDerInNeighborhood(d, false, r, faceWidths, dy);
			double maxDer = getDerInNeighborhood(d, true, r, faceWidths, dy);
			
			allDers[d] = new Interval(minDer, maxDer);
		}
		return allDers;
	}
	
	/**
	 * Extract the face widths from a FaceLift object
	 * @param fl
	 * @return
	 */
	private static Interval[] extractFaceWidths(HyperRectangle r, FaceLift fl)
	{
		double SMALL_FACE_WIDTH = 0.00001;
		int numDims = r.dims.length;
		Interval[] rv = new Interval[numDims];
		
		for (int d = 0; d < numDims; ++d)
		{
			Interval derInt = fl.dynamics.getDerivative(d, r);
			Interval i = new Interval();
			rv[d] = i;
			
			if (derInt.min == 0)
				i.min = SMALL_FACE_WIDTH;
			else
				i.min = Math.abs(derInt.min) * fl.desiredTimeStep;
			
			if (derInt.max == 0)
				i.max = SMALL_FACE_WIDTH;
			else
				i.max = Math.abs(derInt.max) * fl.desiredTimeStep;
		}
		
		return rv;
	}

	/**
	 * Get the (min or max) derivative, in a neighborhood of a face
	 * @param dim the dimension number
	 * @param isMax do we want the maximum face or the minimum face
	 * @param i the concrete state to consider
	 * @param faceSize the face width for each face (min is minFace, max is maxFace)
	 * @param dynamics the dynamics to use
	 * @return the minimum or maximum derivative within the neighborhood of the face
	 */
	private static double getDerInNeighborhood(int dim, boolean isMax, HyperRectangle i, 
			Interval[] faceSize, Dynamics dynamics)
	{
		HyperRectangle neighborhood = new HyperRectangle(i);
	
		// which direction in the dimension are we interested in?
		if (isMax)
			neighborhood.dims[dim].min = neighborhood.dims[dim].max;
		else
			neighborhood.dims[dim].max = neighborhood.dims[dim].min;

		// now, we get the derivative along the flat face in order to determine on which side the 
		// face region should lie on
		
		// first we construct the (flat) face neighborhood
		for (int d = 0; d < i.dims.length; ++d)
		{
			// grow in all directions except dim
			if (d == dim)
				continue;
			
			neighborhood.dims[d].min -= faceSize[d].min;
			neighborhood.dims[d].max += faceSize[d].max;
		}
		
		Interval faceDerInterval = dynamics.getDerivative(dim, neighborhood);
		
		double faceDer = isMax ? faceDerInterval.max : faceDerInterval.min;
		
		// next construct the face on the proper side of neighborhood
		double faceWidth = isMax ? faceSize[dim].max : faceSize[dim].min;
		
		if (faceDer > 0)
			neighborhood.dims[dim].max += faceWidth;			
		else
			neighborhood.dims[dim].min -= faceWidth;
		
		Interval neiDerInterval = dynamics.getDerivative(dim, neighborhood);
		
		return isMax ? neiDerInterval.max : neiDerInterval.min;
	}
}
