package reachability.compute;

import java.util.AbstractMap.SimpleEntry;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;

public class MultiMap<T1 extends Comparable <T1>, T2>
{
	// value is either T2 (single entry) or LinkedList <T2>
	private TreeMap<T1, Object> map = new TreeMap<T1, Object>();
	private int count = 0;
	private Class<T2> valueClass;
	
	/**
	 * Create a new multimap with the given value class.
	 * @param valueClass the class object of the values, used for cast checking
	 */
	public MultiMap(Class <T2> valueClass)
	{
		this.valueClass  = valueClass; 
	}
	
	@SuppressWarnings("unchecked")
	public void put(T1 key, T2 val)
	{
		Object obj = map.get(key);
		
		if (obj == null)
		{
			map.put(key, val);
		}
		else if (valueClass.isAssignableFrom(obj.getClass()))
		{
			// was single entry, make it a list
			LinkedList <T2> list = new LinkedList <T2>();
			T2 existingVal = (T2)obj;
			
			list.add(existingVal);
			list.add(val);
			
			map.put(key, list);
		}
		else
		{
			// was already a list, add to it
			LinkedList <T2> l = (LinkedList <T2>)obj;
			l.add(val);
		}
		
		
		++count;
	}
	
	@SuppressWarnings("unchecked")
	public Entry<T1, T2> removeFirst()
	{
		Entry<T1, Object> e = map.firstEntry();
		
		T1 key = e.getKey();
		Object obj = e.getValue();
		
		SimpleEntry<T1, T2> rv = new SimpleEntry<T1, T2>(key, null);
		
		if (valueClass.isAssignableFrom(obj.getClass()))
		{
			// single object
			map.remove(key);
			
			T2 val = (T2)obj;
			rv.setValue(val);
		}
		else
		{
			// list
			LinkedList <T2> list = (LinkedList <T2>)obj;
			
			rv.setValue(list.removeFirst());
			
			// remove it if the list is now empty
			if (list.size() == 0)
				map.remove(key);
		}
		
		--count;
		
		return rv;
	}
	
	@SuppressWarnings("unchecked")
	public Entry<T1, T2> peekFirst()
	{
		Entry<T1, Object> e = map.firstEntry();
		
		T1 key = e.getKey();
		Object obj = e.getValue();
		
		SimpleEntry<T1, T2> rv = new SimpleEntry<T1, T2>(key, null);
		
		if (valueClass.isAssignableFrom(obj.getClass()))
		{
			// single object
			T2 val = (T2)obj;
			rv.setValue(val);
		}
		else
		{
			// list
			LinkedList <T2> list = (LinkedList <T2>)obj;
			
			rv.setValue(list.getFirst());
		}
		
		return rv;
	}
	
	public int size()
	{
		return count;
	}

	/**
	 * Enumerate every object in the set
	 * @param enumerator will be called on each object in the set
	 */
	@SuppressWarnings("unchecked")
	public void enumerate(MultiMapEnumerator<T1, T2> enumerator)
	{
		for (Entry<T1, Object> e : map.entrySet())
		{
			T1 key = e.getKey();
			Object obj = e.getValue();
			
			if (valueClass.isAssignableFrom(obj.getClass()))
			{
				// was single entry
				T2 existingVal = (T2)obj;
				
				enumerator.enumerate(key, existingVal);
			}
			else
			{
				// was a list
				LinkedList <T2> list = (LinkedList <T2>)obj;
				
				for (T2 existingVal : list)
					enumerator.enumerate(key, existingVal);
			}
		}
	}

	public boolean isEmpty()
	{
		return map.isEmpty();
	}

	public List<Entry<T1,T2>> entryList()
	{
		// Not the most efficient way to do it: 
		// first construct a linked list, then return the iterator to that
		
		final LinkedList <Entry<T1,T2>> list = new LinkedList <Entry<T1,T2>>();
		
		enumerate(new MultiMapEnumerator<T1,T2>(){
			@Override
			public void enumerate(T1 a, T2 b)
			{
				list.add(new SimpleEntry<T1,T2>(a, b));
			}		
		});
		
		return list;
	}
}
