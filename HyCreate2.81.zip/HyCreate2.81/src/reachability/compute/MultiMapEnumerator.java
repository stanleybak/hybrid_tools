package reachability.compute;


public abstract class MultiMapEnumerator<T1, T2>
{
	public abstract void enumerate(T1 a, T2 b);
}
