package reachability.compute;

public class Mutable<T>
{
	private T val;
	
	public Mutable(T init)
	{
		val = init;
	}
	
	public T get()
	{
		return val;
	}
	
	public void set(T newVal)
	{
		val = newVal;
	}
	
	public String toString()
	{
		return val.toString();
	}
}
