package reachability.compute;

import java.util.ArrayList;
import java.util.Collection;
import java.util.TreeMap;

import reachability.automaton.Dynamics;
import reachability.automaton.HybridAutomaton;
import reachability.automaton.SuccessorAggregation;
import reachability.geometry.HyperPoint;
import reachability.geometry.HyperRectangle;
import reachability.geometry.HyperRectangleTime;
import reachability.geometry.Interval;

/**
 * This class does all the checking related to pseudo-invariants
 *
 */
public class PseudoInvariantsChecker 
{
	private HybridAutomaton ha = null;
	private Dynamics dynamics;
	
	// values for the current pseudo-invariant
	private HyperPoint anchor;
	private double[] gradient;
	private boolean[] gradientSign;
	private SuccessorAggregation piAggregator = null;
	
	private double[] gridSize;
	private double timeStep;
	private double simulatedTime = 0;
	HyperPoint pseudoInvariantSetupPoint = null;
	private double deltaReachTime;
	private boolean pseudoInvariantsEnabled = true;
	private boolean shouldDisablePseudoInvariants = true;
	
	ArrayList <HyperRectangleTime> rectsAfterDisabled = new ArrayList <HyperRectangleTime>();

	public PseudoInvariantsChecker(HybridAutomaton ha, Dynamics d, 
			double timeStep, double deltaReachTime) 
	{
		this.ha = ha;
		this.dynamics = d;
		this.timeStep = timeStep;
		this.deltaReachTime = deltaReachTime;
	}
	
	public void setGridSize(double[] gs)
	{
		this.gridSize = gs;
		
		piAggregator = new SuccessorAggregation(ha.reachParams.aggregationMethod);
		piAggregator.setGridSize(gs);
	}

	public boolean hasSuccessorStates()
	{
		return piAggregator.hasSuccessors() || rectsAfterDisabled.size() > 0;
	}

	public Collection<HyperRectangleTime> getAndClearSuccessorStates()
	{
		ArrayList<HyperRectangleTime> init = new ArrayList<HyperRectangleTime>();
		
		// if it was disabled we had an alternate tracking mechanism
		init.addAll(rectsAfterDisabled);
		rectsAfterDisabled.clear();
		
		TreeMap<String, Collection<HyperRectangleTime>> suc = piAggregator.getModeSuccessors();
		
		for (Collection<HyperRectangleTime> faceRects : suc.values())
		{
			for (HyperRectangleTime hrt : faceRects)
			{
				init.add(hrt);
			}
		}
	
		piAggregator = new SuccessorAggregation(ha.reachParams.aggregationMethod);
		piAggregator.setGridSize(gridSize);
		
		if (shouldDisablePseudoInvariants)
			pseudoInvariantsEnabled = false;
		
		return init;
	}
	
	/**
	 * This turns off further pseudo-invariants
	 * Note that it will not turn off the current one, so that the upcoming pseudo-invariant will be the last one
	 */
	public void disableFurtherPseudoInvariants()
	{
		shouldDisablePseudoInvariants = true;
		
		if (piAggregator.getSuccessorCount() == 0)
			pseudoInvariantsEnabled = false;
	}
	
	public void enablePseudoInvariants()
	{
		pseudoInvariantsEnabled = true;
		shouldDisablePseudoInvariants = false;
	}

	/**
	 * Set up a pseudo invariant computation
	 * @param p the point to simulate from, use getCenterOfHull
	 */
	public void setup(HyperPoint p, double currentSimTime)
	{
		HyperPoint start = new HyperPoint(p);
		
		ArrayList <HyperPoint> simulation = Simulator.simulateContinuous(
				start, dynamics, timeStep/10, timeStep);
		
		anchor = simulation.get(simulation.size() - 1);
		
		gradient = sampleGradient(anchor);
		
		gradientSign = new boolean[gradient.length];
		
		for (int d = 0; d < gradient.length; ++d)
			gradientSign[d] = gradient[d] >= 0;
			
		// update partial results viewer
		ComputationResultSaveThread.sendPseudoInvariant(simulation, gradient);
		
		pseudoInvariantSetupPoint = start;
		simulatedTime = currentSimTime + timeStep;
		
		if (simulatedTime >= deltaReachTime)
		{
			System.out.println("Pseudo invariant simulation reached desired reach time; " + 
					"ignoring further pseudo-invariants.");
			pseudoInvariantsEnabled = false;
		}
	}

	private double[] sampleGradient(HyperPoint p)
	{
		double[] rv = new double[p.dims.length];
		
		for (int d = 0; d < p.dims.length; ++d)
		{
			Interval i = dynamics.getDerivative(d, p);
			rv[d] = i.middle();
		}
		
		return rv;
	}

	/**
	 * Get the center of the bounding box
	 * @param init the states we're taking the bounding box of
	 * @return the center point
	 */
	public static HyperPoint getCenterOfHull(Collection<HyperRectangleTime> init)
	{
		HyperRectangle hull = null;
		
		for (HyperRectangleTime hrt : init)
		{
			if (hull == null)
				hull = new HyperRectangle(hrt.rect);
			else
				hull = HyperRectangle.convexHull(hull, hrt.rect);
		}
		
		return hull.center();
	}
	
	/**
	 * Get the minimum time of the passed-in states
	 * @param init the states we're looking at
	 * @return the minimum time
	 */
	public static double getMinTime(Collection<HyperRectangleTime> init)
	{
		double min = Double.MAX_VALUE;
		
		for (HyperRectangleTime hrt : init)
		{
			double t = hrt.getTime();
			
			if (t < min)
				min = t;
		}
		
		return min;
	}

	private double computeDotProduct(double[] a, double[] b)
	{
		double rv = 0;
		
		for (int d = 0; d < a.length; ++d)
			rv += a[d] * b[d];
		
		return rv;
	}

	/**
	 * check if pseudo-invariants are enabled or any part of the rect is inside of the pseudo-invariant region
	 * @param r the rect to check
	 * @return true if any part of rect is inside pseudo-invariant
	 */
	public boolean isInsidePseudoInvariant(HyperRectangle r)
	{
		boolean rv = true;
		
		if (!pseudoInvariantsEnabled)
			rv = true;
		else if (shouldDisablePseudoInvariants)
			rv = false;
		else 
		{
			rv = false;
			
			// use gradientSign to check if all points in r < pi
			double[] sampleMostInside = new double[r.dims.length];
			
			for (int d = 0; d < r.dims.length; ++d)
			{
				if (gradientSign[d])
					sampleMostInside[d] = r.dims[d].min;
				else 
					sampleMostInside[d] = r.dims[d].max;
			}
			
			// translate by anchor
			for (int d = 0; d < sampleMostInside.length; ++d)
				sampleMostInside[d] -= anchor.dims[d];
			
			// states exist inside of the pseudo-invariant
			double dotProduct = computeDotProduct(gradient, sampleMostInside);
			
			if (dotProduct <= 0)
				rv = true;
		}
		
		return rv;
	}
	
	private boolean isOutsidePseudoInvariant(HyperRectangle r)
	{
		boolean rv = false;
		
		if (pseudoInvariantsEnabled)
		{
			// use gradientSign to check if all points in r < pi
			double[] sampleMostOutside = new double[r.dims.length];
			
			for (int d = 0; d < r.dims.length; ++d)
			{
				if (gradientSign[d])
					sampleMostOutside[d] = r.dims[d].max;
				else 
					sampleMostOutside[d] = r.dims[d].min;
			}
			
			// translate by anchor
			for (int d = 0; d < sampleMostOutside.length; ++d)
				sampleMostOutside[d] -= anchor.dims[d];
			
			double dotProduct = computeDotProduct(gradient, sampleMostOutside);
			
			if (dotProduct >= 0)
				rv = true;
		}
		
		return rv;
	}

	/**
	 * Check if this state should be retained (it is within the current pseudo-invariant). Also,
	 * this may add the state to the successor states of the pseudo-invariant
	 * @param rect the rectangle / time to check
	 * @param atRectLimit at we currently at or above the rectangle tracking limit?
	 * @return true iff the state should be retained in the working set
	 */
	public boolean checkAddPseudoInvariant(HyperRectangleTime hrt, 
			int currentRects, int rectLimit)
	{
		boolean atRectLimit = currentRects >= rectLimit;
		
		boolean added = false;
		
		while ((shouldDisablePseudoInvariants && pseudoInvariantsEnabled) // we're disabling it
				|| isOutsidePseudoInvariant(hrt.rect)) 
		{
			if (shouldDisablePseudoInvariants || piAggregator.hasSuccessors() || atRectLimit)
			{
				added = true;
				
				if (shouldDisablePseudoInvariants)
					rectsAfterDisabled.add(new HyperRectangleTime(hrt));
				else
					piAggregator.addSuccessorRect("", new HyperRectangleTime(hrt));
				
				if (!shouldDisablePseudoInvariants && 
						piAggregator.getSuccessorCount() > rectLimit)
				{
					shouldDisablePseudoInvariants = true;
					
					System.out.println("Pseudo-invariants seem to be hurting more than helping;" +
							" disabling.");
				}
				
				break;
			}
			
			// advance the pseudo-invariant and then recheck (loop condition)
			setup(pseudoInvariantSetupPoint, simulatedTime);
		}
		
		boolean shouldBeRetained = !added;
		shouldBeRetained = shouldBeRetained || isInsidePseudoInvariant(hrt.rect);
		
		return shouldBeRetained;
	}

}
