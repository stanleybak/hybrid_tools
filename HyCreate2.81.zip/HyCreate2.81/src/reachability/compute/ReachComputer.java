package reachability.compute;

import java.util.Collection;
import java.util.LinkedList;

import reachability.geometry.HyperRectangleTime;

public abstract class ReachComputer
{
	private MultiMap<Double, HyperRectangleTime> Q = 
			new MultiMap<Double, HyperRectangleTime>(HyperRectangleTime.class);
	
	public boolean hasRemainingStates()
	{
		return getNumRects() > 0;
	}
	
	public void addRect(HyperRectangleTime hrt)
	{
		Q.put(hrt.getTime(), hrt);
	}
	
	public HyperRectangleTime removeFirstState()
	{
		return Q.removeFirst().getValue();
	}

	public double peakTime()
	{
		return Q.peekFirst().getValue().getTime();
	}

	public int getNumRects()
	{
		return Q.size();
	}

	public Collection<HyperRectangleTime> getStates()
	{
		final LinkedList <HyperRectangleTime> list = new LinkedList <HyperRectangleTime>(); 
		
		Q.enumerate(
			new MultiMapEnumerator<Double, HyperRectangleTime>()
			{
				@Override
				public void enumerate(Double d, HyperRectangleTime r)
				{
					list.add(r);
				}
			}
		);
		
		return list;
	}

	public abstract boolean doSingleOperation(HyperRectangleTime q);
}
