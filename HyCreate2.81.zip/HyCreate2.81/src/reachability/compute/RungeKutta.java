package reachability.compute;

import java.util.Random;

import reachability.automaton.Dynamics;
import reachability.geometry.HyperPoint;
import reachability.geometry.Interval;

/**
 * Solver using the 4th order Runge-Kutta method
 * @author Stanley Bak (sbak2@illinois.edu)
 *
 */
public class RungeKutta 
{
	public static Random rand = new Random(0);
	
	// used to track which dimensions are nondeterministic
	private static boolean trackingNondeterminism = false;
	private static boolean[] dimIsNondeterministic;
	
	private static Dynamics dynamics = null;
	private static SampleType derivativeSampleType[] = null; // for each dimension
	
	/**
	 * Do a single step of the Runge-Kutta method
	 * @param dy the dynamics to use
	 * @param st the sample type to use for each dimension (min der / max der / avg der), or null for avg all
	 * @param hp the point where to start, this is modified during the function call to be the result
	 * @param h the time step to use
	 * @param st how we should sample the derivative
	 */
	public static void stepRK(Dynamics dy, SampleType[] st, HyperPoint hp, double h)
	{
		dynamics = dy;
		derivativeSampleType = st;
		
		HyperPoint k_1 = new HyperPoint(hp.dims.length);
		HyperPoint k_2 = new HyperPoint(hp.dims.length);
		HyperPoint k_3 = new HyperPoint(hp.dims.length);
		HyperPoint k_4 = new HyperPoint(hp.dims.length);
		HyperPoint rv = new HyperPoint(hp.dims.length);
		
		k_1 = multiplyDerivative(h, hp);
		k_2 = multiplyDerivative(h, addVector(hp, divVector(k_1, 2)));
		k_3 = multiplyDerivative(h, addVector(hp, divVector(k_2, 2)));
		k_4 = multiplyDerivative(h, addVector(hp,k_3));
		
		// rv = y + 1/6 * (k_1 + 2*k_2 + 2*k_3 + k_4) 
		rv = addVector(addVector(k_1, multVector(k_2, 2)),addVector(multVector(k_3, 2), k_4));
		rv = divVector(rv, 6);
		rv = addVector(rv, hp);
		
		/*
		System.out.println("Doing Step RK");
		System.out.println("start = " + hp);
		System.out.println("k_1 = " + k_1);
		System.out.println("k_2 = " + k_2);
		System.out.println("k_3 = " + k_3);
		System.out.println("k_4 = " + k_4);
		System.out.println("rv(end) = " + rv);
		*/
		
		// return result in the passed-in point
		
		for (int d = 0; d < hp.dims.length; ++d)
			hp.dims[d] = rv.dims[d];
	}
	
	/**
	 * Divide a vector by a constant
	 * @param vec the vector to divide
	 * @param divisor the constant to divide by
	 * @return the resultant vector
	 */
	private static HyperPoint divVector(HyperPoint vec, double divisor)
	{
		HyperPoint rv = new HyperPoint(vec.dims.length);
		
		for (int d = 0; d < vec.dims.length; ++d)
			rv.dims[d] = vec.dims[d] / divisor;
		
		return rv;
	}
	
	/**
	 * Multiply a vector by a constant
	 * @param vec the vector to multiply
	 * @param m the constant to multiply by
	 * @return the resultant vector
	 */
	private static HyperPoint multVector(HyperPoint vec, double m)
	{
		HyperPoint rv = new HyperPoint(vec.dims.length);
		
		for (int d = 0; d < vec.dims.length; ++d)
			rv.dims[d] = vec.dims[d] * m;
		
		return rv;
	}
	
	/**
	 * Add a vector to a hyperpoint
	 * @param pt the point to sum
	 * @param vec the vector to sum
	 * @return the resultant point
	 */
	private static HyperPoint addVector(HyperPoint pt, HyperPoint vec)
	{
		HyperPoint rv = new HyperPoint(pt.dims.length);
		
		for (int d = 0; d < pt.dims.length; ++d)
			rv.dims[d] = pt.dims[d] + vec.dims[d]; 
		
		return rv;
	}
	
	/**
	 * Multiply a constant times a derivative at a point
	 * @param t the constant to multiplyBy
	 * @param derivativePoint the point where to take the derivative
	 * @return the point representing the resultant vector
	 */
	private static HyperPoint multiplyDerivative(double t, HyperPoint derivativePoint)
	{
		HyperPoint rv = new HyperPoint(derivativePoint.dims.length);
		
		for (int dim = 0; dim < derivativePoint.dims.length; ++dim) 
		{
			Interval i = dynamics.getDerivative(dim, derivativePoint);
			double d = 0;
			
			if (derivativeSampleType == null)
				d = i.middle();
			else
			{
				if (derivativeSampleType[dim] == SampleType.SAMPLE_AVERAGE)
					d = i.middle();
				else if (derivativeSampleType[dim] == SampleType.SAMPLE_MAX)
					d = i.max;
				else if (derivativeSampleType[dim] == SampleType.SAMPLE_MIN)
					d = i.min;
				else if (derivativeSampleType[dim] == SampleType.SAMPLE_RANDOM_EXTREME)
				{
					if (rand.nextBoolean() == true)
						d = i.min;
					else
						d = i.max;
				}
				else
					throw new RuntimeException("Unsupported Sample type");
			}
			
			if (trackingNondeterminism)
				dimIsNondeterministic[dim] = dimIsNondeterministic[dim] || (i.max != i.min); 
				
			rv.dims[dim] = t * d;
		}
		
		return rv;
	}
	
	/**
	 * Start track which dimensions have non-deterministic dynamics in upcoming stepRK calls
	 */
	public static void startTrackingNondeterminism(int numDims)
	{
		trackingNondeterminism = true;
		dimIsNondeterministic = new boolean[numDims];
	}
	
	/**
	 * Stop tracking which dimensions have non-deterministic dynamics.
	 * @return which dimensions had non-deterministic dynamics in previous calls
	 */
	public static boolean[] stopTrackingNondeterminism()
	{
		trackingNondeterminism = false;
		
		return dimIsNondeterministic;
	}
}
