package reachability.compute;

/**
 * Sample type enumeration for each dimension (for simulating, or getting a point
 * from a hyperrectangle)
 *
 */
public enum SampleType
{
	SAMPLE_AVERAGE,
	SAMPLE_MIN,
	SAMPLE_MAX,
	SAMPLE_RANDOM_EXTREME,
}
