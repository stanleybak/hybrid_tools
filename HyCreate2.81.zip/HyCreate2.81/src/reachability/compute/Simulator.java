package reachability.compute;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map.Entry;
import java.util.TreeMap;

import com.stanleybak.hycreate.containers.ReachParams;
import com.stanleybak.hycreate.containers.ModelSimulationOptions.EnumDerivativesType;
import com.stanleybak.hycreate.containers.ModelSimulationOptions.StartingPositionsType;

import reachability.automaton.AutomatonMode;
import reachability.automaton.Dynamics;
import reachability.automaton.HybridAutomaton;
import reachability.automaton.Transition;
import reachability.geometry.HyperPoint;
import reachability.geometry.HyperRectangle;
import reachability.geometry.HyperRectangleCornerEnumerator;
import reachability.geometry.Interval;

public class Simulator
{
	public static final String SIMULATION_FILENAME = "simulation.txt";
	private static int numDims = 0;
	private static boolean printedStepSize = false;
	
	// used during simulation enumeration
	private static int simNum;
	private static long nextPrintMs;
	private static final long PRINT_PERIOD_MS = 1000;
	
	private static int simulationErrorsPrinted = 0;
	
	enum TransitionType
	{
		EARLIEST,
		LATEST,
	};
	
	static TransitionType transitionStrategy = TransitionType.LATEST;
	static SampleType sampleStrategy[] = null; // derivative sample strategy for each dimension
	
	/**
	 * Get the range of a simulation from a set of rectangles, scaled by a constant
	 * @param ha the hybrid automaton
	 * @param scale the constant to scale the result by
	 * @param init the initial states
	 * @return the scaled range encountered in simulations
	 */
	public static double[] getScaledSimulationRange(HybridAutomaton ha, double scale,
			TreeMap <String, Collection <HyperRectangle> > init, 
			int xDim, int yDim, double stepSize, int maxJumps)
	{
		double rv[] = new double[4];
		rv[0] = rv[2] = Double.MAX_VALUE;
		rv[1] = rv[3] = -Double.MAX_VALUE;
		
		numDims = ha.getDimensions();
		
		for (Entry<String, Collection<HyperRectangle>> entry : init.entrySet())
		{
			String mode = entry.getKey();
			Collection<HyperRectangle> rects = entry.getValue(); 
			
			for (HyperRectangle r : rects)
			{
				// simulate center, min, and max points for each rect
				
				for (SampleType s : SampleType.values())
				{
					HyperPoint start = getPoint(r,s);
					
					sampleStrategy = new SampleType[start.dims.length];
					
					for (int d = 0; d < start.dims.length; ++d)
						sampleStrategy[d] = s;
					
					double[] range = getSimulationRange(ha, stepSize, mode, start, xDim, yDim, maxJumps);
					
					if (range[0] < rv[0])
						rv[0] = range[0];
					
					if (range[2] < rv[2])
						rv[2] = range[2];
					
					if (range[1] > rv[1])
						rv[1] = range[1];
					
					if (range[3] > rv[3])
						rv[3] = range[3];
				}
			}
		}
		
		return scaleRanges(rv, scale);
	}
	
	
	/**
	 * Get the range of a simulation from a single point
	 * @param ha the hybrid automaton
	 * @param stepSize the step size to use, or <=0 to auto-detect
	 * @param ms the milliseconds to run the simulation for
	 * @param initMode
	 * @return the scaled range encountered in simulation
	 */
	private static double[] getSimulationRange(HybridAutomaton ha, double stepSize,
			String initMode, HyperPoint initPoint, int xDim, int yDim, int maxJumps)
	{
		double rv[] = new double[4];
		rv[0] = rv[2] = Double.MAX_VALUE;
		rv[1] = rv[3] = -Double.MAX_VALUE;
		
		Collection <HyperPoint> simPoints = simulate(ha, stepSize, initMode, initPoint, maxJumps);
		
		for (HyperPoint p : simPoints)
		{
			if (p == null)
				continue;
			
			if (p.dims[xDim] < rv[0])
				rv[0] = p.dims[xDim];
			
			if (p.dims[yDim] < rv[2])
				rv[2] = p.dims[yDim];
			
			if (p.dims[xDim] > rv[1])
				rv[1] = p.dims[xDim];
			
			if (p.dims[yDim] > rv[3])
				rv[3] = p.dims[yDim];
		}
		
		return rv;
	}
	
	/**
	 * Get a set of points in a simulation of a hybrid automaton. Null is used to indicate
	 * discrete jumps
	 * @param ha the hybrid automaton
	 * @param stepSize the step size to use, or -1 to auto-detect
	 * @param initMode
	 * @return the scaled range encountered in simulation
	 */
	static ArrayList<HyperPoint> simulate(HybridAutomaton ha, double stepSize,
			String initMode, HyperPoint initPoint, int maxJumps)
	{
		ArrayList <HyperPoint> rv = new ArrayList <HyperPoint>(); 
		
		double simulationTime = ha.getDeltaReachTime();
		AutomatonMode curMode = getMode(ha, initMode);
		
		if (simulationTime == Double.MAX_VALUE) // unbounded reach time
		{
			// sample the derivative at the start point, and then take that
			double mag = magnitude(sampleMaxMagDerivative(curMode.getModeDynamics(), initPoint));

			if (mag == 0) // ugg, derivative is zero at start state,
				mag = 1;
			
			simulationTime = 10 * mag; 
		}
		
		if (stepSize <= 0)
		{
			// auto-compute the step size
			stepSize = simulationTime / 100;
		}
		
		if (!printedStepSize)
		{
			printedStepSize = true;
			System.out.println("Using simulation step size: " + stepSize);
		}

		// simulate from 0 to simulationTime using stepSize
		
		HyperPoint p = new HyperPoint(initPoint);
		long maxDiscreteTransition = maxJumps;
		rv.add(new HyperPoint(initPoint));
		
		for (double time = 0; time < simulationTime; /* increment in loop */)
		{
			Dynamics dy = curMode.getModeDynamics();
			Collection <Transition> successors = curMode.getSuccessors();
			boolean didDiscreteTransition = false;
			HyperRectangle rectPoint = new HyperRectangle(p);
			
			boolean insideInvariant = dy.intersectsInvariant(rectPoint);
			boolean reachedTimeTrigger = false;

			Interval timeTrigger = dy.getTimeTrigger(rectPoint);
			
			// add extra condition on invariant if time trigger exists
			if (timeTrigger != null && timeTrigger.max <= 0)
				insideInvariant = false;
			
			// variable step size if time trigger exists
			double step = stepSize;

			if (timeTrigger != null && timeTrigger.max < stepSize)
			{
				reachedTimeTrigger = true;
				
				if (timeTrigger.max > 0)
					step = timeTrigger.max;
			}
			
			if (transitionStrategy == TransitionType.LATEST)
			{
				// strategy: switch to new modes as late as possible
				
				if (insideInvariant)
				{
					// do continuous evolution
					RungeKutta.stepRK(dy, sampleStrategy, p, step);
					
					rv.add(new HyperPoint(p));
					
					time += step;
				}
				else
				{					
					if (reachedTimeTrigger)
						timeTrigger.set(0);
					
					// not inside invariant, try discrete transitions
					for (Transition t : successors)
					{
						if (t.intersectsGuard(rectPoint))
						{
							t.applyReset(rectPoint);
						
							p = getPoint(rectPoint, sampleStrategy);
							
							rv.add(null); // discrete jump
							rv.add(new HyperPoint(p));
	
							curMode = getMode(ha, t.getSuccessorMode());
							
							didDiscreteTransition = true;
							break;
						}
					}
					
					if (didDiscreteTransition)
					{
						--maxDiscreteTransition;
						
						if (maxDiscreteTransition <= 0)
						{
							if (++ simulationErrorsPrinted < 5)
								System.out.println("Warning: simulation reached discrete transition limit");
							else if (simulationErrorsPrinted == 5)
								System.out.println("Suppressing further simulation error messages.");
							
							break;
						}
						
						continue;
					}
					else
					{
						if (++simulationErrorsPrinted < 5)
						{
							System.out.print("Warning: simulation ends at time " + time + 
									" (invariant became false with no valid discrete successor)");
							
							System.out.println("Simulation intial state: " + initPoint);
							System.out.println("Simulation final (out of bounds) state: " + p );
						}
						else if ( simulationErrorsPrinted == 5)
							System.out.println("Suppressing further simulation error messages.");
						
						break; // execution ends? left invariant
					}
				}
			}
			else if (transitionStrategy == TransitionType.EARLIEST)
			{
				// strategy: switch to new modes as early as possible
				if (reachedTimeTrigger)
					timeTrigger.set(0);
				
				for (Transition t : successors)
				{
					if (t.intersectsGuard(rectPoint))
					{
						t.applyReset(rectPoint);
						
						p = getPoint(rectPoint, sampleStrategy);
						
						rv.add(null); // discrete jump
						rv.add(new HyperPoint(p));
						curMode = getMode(ha, t.getSuccessorMode());
						
						didDiscreteTransition = true;
						break;
					}
				}
				
				if (didDiscreteTransition)
				{
					--maxDiscreteTransition;
					
					if (maxDiscreteTransition <= 0)
					{
						if (++ simulationErrorsPrinted < 5)
							System.out.println("Warning: simulation reached discrete transition limit");
						else if (simulationErrorsPrinted == 5)
							System.out.println("Suppressing further simulation error messages.");
						
						break;
					}
					
					continue;
				}
				else
				{
					// try continuous evolution

					if (insideInvariant)
					{
						// do continuous evolution
						RungeKutta.stepRK(dy, sampleStrategy, p, step);
						
						rv.add(new HyperPoint(p));
						
						time += step;
					}
					else
					{
						// not inside invariant, error

						if (++simulationErrorsPrinted < 5)
						{
							System.out.println("Warning: simulation ends at time " + time + 
									" (invariant became false with no valid discrete successor)");
							
							System.out.println("Simulation intial state: " + initPoint);
							System.out.println("Simulation final (out of bounds) state: " + p );
						}
						else if ( simulationErrorsPrinted == 5)
							System.out.println("Suppressing further simulation error messages.");
						
						break; // execution ends? left invariant
					}
				}
			}
		}
		
		rv.trimToSize();
		return rv;
	}
	
	/**
	 * Simulate a single mode's dynamics for some fixed time. This ignores discrete transitions.
	 * @param initPoint the point where to start
	 * @param dy the dynamics to use
	 * @param stepSize the step size to use, or negative will use simTime/100
	 * @param simulationTime the simulation time to run
	 * @return the list of points of the simulation
	 */
	public static ArrayList<HyperPoint> simulateContinuous(HyperPoint initPoint, 
			Dynamics dy, double stepSize, double simulationTime)
	{
		ArrayList <HyperPoint> rv = new ArrayList <HyperPoint>(); 
		sampleStrategy = null; // do mid range sampling
		
		if (stepSize <= 0)
		{
			// auto-compute the step size
			stepSize = simulationTime / 100;
		}

		HyperPoint p = initPoint;
		rv.add(new HyperPoint(initPoint));
		
		for (double time = 0; time < simulationTime; time += stepSize)
		{
			double step = stepSize;
			
			// use a smaller step
			if (simulationTime - time < stepSize)
				step = simulationTime - time;
			
			// do continuous evolution
			RungeKutta.stepRK(dy, sampleStrategy, p, step);
			rv.add(new HyperPoint(p));
		}
		
		rv.trimToSize();
		return rv;
	}

	/**
	 * Get a specific point of a hyperrectangle
	 * @param r the hyperrectangle
	 * @param type how to sample each dimension (min/max/center)
	 * @return the point inside this rectangle
	 */
	private static HyperPoint getPoint(HyperRectangle r, SampleType[] type)
	{
		HyperPoint rv = new HyperPoint(r.dims.length);
		
		for (int d = 0; d < rv.dims.length; ++d)
		{
			if (type == null || type[d] == SampleType.SAMPLE_AVERAGE)
				rv.dims[d] = r.dims[d].middle();
			else if (type[d] == SampleType.SAMPLE_MIN)
				rv.dims[d] = r.dims[d].min;
			else if (type[d] == SampleType.SAMPLE_MAX)
				rv.dims[d] = r.dims[d].max;
			else if (type[d] == SampleType.SAMPLE_RANDOM_EXTREME)
				rv.dims[d] = r.dims[d].middle();
			else
				throw new RuntimeException("Unsupported Sample type");
		}
		
		return rv;
	}

	/**
	 * Get a specific point of a hyperrectangle
	 * @param r the hyperrectangle
	 * @param type how to sample each dimension (min/max/center)
	 * @return the point inside this rectangle
	 */
	private static HyperPoint getPoint(HyperRectangle r, SampleType type)
	{
		HyperPoint rv = new HyperPoint(r.dims.length);
		
		for (int d = 0; d < rv.dims.length; ++d)
		{
			if (type == null || type == SampleType.SAMPLE_AVERAGE)
				rv.dims[d] = r.dims[d].middle();
			else if (type == SampleType.SAMPLE_MIN)
				rv.dims[d] = r.dims[d].min;
			else if (type == SampleType.SAMPLE_MAX)
				rv.dims[d] = r.dims[d].max;
			else if (type == SampleType.SAMPLE_RANDOM_EXTREME)
				rv.dims[d] = r.dims[d].middle();
			else
				throw new RuntimeException("unsupported sample type " + type);
		}
		
		return rv;
	}

	private static double magnitude(double[] der)
	{
		double sum = 0;
		
		for (double d : der)
			sum += d*d;
		
		return Math.sqrt(sum);
	}

	private static AutomatonMode getMode(HybridAutomaton ha, String name)
	{
		AutomatonMode rv = null;
		ArrayList<AutomatonMode> modes = ha.getModes();
		
		for (AutomatonMode mode : modes)
		{
			if (mode.name.equals(name))
			{
				rv = mode;
				break;
			}
		}
		
		return rv;
	}
	
	private static double[] sampleMaxMagDerivative(Dynamics dy, HyperPoint p)
	{
		double[] rv = new double[numDims];
		
		for (int dim = 0; dim < numDims; ++dim)
		{
			double der = -9999;
			Interval i = dy.getDerivative(dim, p);
			
			if (Math.abs(i.min) > Math.abs(i.max))
				der = i.min;
			else
				der = i.max;
			
			rv[dim] = der;
		}
		
		return rv;
	}


	/**
	 * Scale a range [xmin, xmax, ymin, ymax] by a constant
	 * @param r the range
	 * @param scale the scale, 0.5 = half width
	 * @return the scaled range
	 */
	private static double[] scaleRanges(double[] r, double scale)
	{
		double rv[] = new double[4];
		
		double xWidth = r[1] - r[0];
		double xMid = (r[1] + r[0]) / 2;
		
		double yWidth = r[3] - r[2];
		double yMid = (r[2] + r[3]) / 2;
		
		if (xWidth < 0.0000001)
			xWidth = 0.1;
		
		if (yWidth < 0.0000001)
			yWidth = 0.1;
		
		rv[0] = xMid - (xWidth/2) * scale;
		rv[1] = xMid + (xWidth/2) * scale;
		
		rv[2] = yMid - (yWidth/2) * scale;
		rv[3] = yMid + (yWidth/2) * scale;
		
		return rv;
	}

	/**
	 * Simulate the system, and output the result to a file
	 * @param options the settings, simulation settings are extracted from this
	 * @param ha the automaton
	 * @param init initial states
	 * @param xDim the x dimension we're visualizing
	 * @param yDim the y dimension we're visualizing
	 * @param stepSize the step size to simulate with
	 * @param resultDir where to store the result
	 */
	public static void run(ReachParams options, HybridAutomaton ha,
			TreeMap<String, Collection<HyperRectangle>> init,
			int xDim, int yDim, double stepSize, String resultDir)
	{
		long start = System.currentTimeMillis();
		
		try
		{
			BufferedWriter out = new BufferedWriter(new FileWriter(resultDir + File.separator + SIMULATION_FILENAME));
			
			simulateAll(ha, init, xDim, yDim, stepSize, out, options);
						
			out.close();
			
			long ms = System.currentTimeMillis() - start;
			System.out.println("Simulations finished in " + ms + " milliseconds");
		}
		catch (IOException e)
		{
			System.out.println("ERROR when simulating: " + e);
		}
	}
	
	/**
	 * Simulate from the midpoint of each initial state
	 * @param ha the automaton
	 * @param init the initial states
	 * @param stepSize the step size to use
	 * @param xDim the dimension index for x in the visualization
	 * @param yDim the dimension index for y in the visualization
	 * @param out the output stream to write to
	 * @throws IOException if an I/O error occurs
	 */
	/*private static void simulateMidpoint(HybridAutomaton ha, TreeMap<String, Collection<HyperRectangle>> init,
			int xDim, int yDim, double stepSize, BufferedWriter out) throws IOException
	{
		transitionStrategy = TransitionType.TRANSITION_LATEST;
		sampleStrategy = null;
		numDims = ha.getDimensions();
		
		for (Entry<String, Collection<HyperRectangle>> entry : init.entrySet())
		{
			String mode = entry.getKey();
			Collection<HyperRectangle> rects = entry.getValue(); 
			
			for (HyperRectangle r : rects)
			{
				// simulate from center point
				HyperPoint center = r.center();
				
				ArrayList <HyperPoint> points = simulate(ha, stepSize, mode, center);
				
				ComputationResultSaveThread.socketSendSimulationResult(points);
				
				// output result
				for (HyperPoint p : points)
				{
					if (p == null)
						out.write("\n");
					else
					{
						double x = p.dims[xDim];
						double y = p.dims[yDim];
						
						out.write(x + " " + y + "\n");
					}
				}
				
				out.write("\n");
			}
		}
	}*/
	
	/**
	 * Simulate by enumerating possibilities given by options
	 * @param ha the automaton
	 * @param init the initial states
	 * @param xDim the dimension index for x in the visualization
	 * @param yDim the dimension index for y in the visualization
	 * @param out the output stream to write to
	 * @param options the options to simulate with
	 * @throws IOException if an I/O error occurs
	 */
	private static void simulateAll(final HybridAutomaton ha, 
			TreeMap<String, Collection<HyperRectangle>> init,
			final int xDim, final int yDim, final double stepSize,
			final BufferedWriter out, ReachParams options) throws IOException
	{	
		final int maxJumps = options.maxJumps;
		int simSpots = simulationPointsCount(init, options);
		System.out.println("Number of simulation start points: " + simSpots);
		
		TransitionType[] transitions = getTransitionTypes(ha, options);
			
		if (transitions.length == 1)
			System.out.println("Simulating with lazy discrete transitions.");
		else
			System.out.println("Simulating both lazy and eager discrete transitions.");

		DerivativeTypeEnumerator derEnum = new DerivativeTypeEnumerator(
				ha, init, stepSize, maxJumps, options.enumerateDerivatives); 
		int numEnumPoints = derEnum.getNumEnumPoints();
		
		if (options.enumerateDerivatives.equals(EnumDerivativesType.AVERAGE_DERIVATIVE))
			System.out.println("Simulating with average derivative.");
		else if (options.enumerateDerivatives.equals(EnumDerivativesType.ENUMERATE_ALL))	
			System.out.println("Simulating with derivative enumeration (" + numEnumPoints + " per point)");
		else
			System.out.println("Simulating using auto-detected enumeration (" + numEnumPoints + " per point)");
		
		final int totalSims = simSpots * numEnumPoints * transitions.length;
		System.out.println("Total simulations: " + totalSims);

		nextPrintMs = System.currentTimeMillis() + PRINT_PERIOD_MS;
		simNum = 0;
		
		for (SampleType[] st = derEnum.next(); st != null; st = derEnum.next())
		{
			sampleStrategy = st;
			
			for (TransitionType tt : transitions) 
			{
				transitionStrategy = tt;
			
				for (Entry<String, Collection<HyperRectangle>> entry : init.entrySet())
				{
					final String mode = entry.getKey();
					Collection<HyperRectangle> rects = entry.getValue(); 
					
					for (HyperRectangle r : rects)
					{
						// simulate from each midpoint
						if (options.startingPositions.equals(StartingPositionsType.MIDPOINTS) || 
								options.startingPositions.equals(StartingPositionsType.CORNERS_AND_MIDPOINTS)) 
						{
							simAndSave(ha, xDim, yDim, stepSize, out, maxJumps,
									totalSims, mode, r.center());
						}
						
						// simulate from each corner
						if (options.startingPositions.equals(StartingPositionsType.CORNERS) || 
								options.startingPositions.equals(StartingPositionsType.CORNERS_AND_MIDPOINTS))
						{
							r.enumerateCornersUnique(new HyperRectangleCornerEnumerator()
							{
								@Override
								public void enumerate(HyperPoint startPoint)
								{
									simAndSave(ha, xDim, yDim, stepSize, out, maxJumps,
											totalSims, mode, startPoint);
								}
							});
						}
					}
				}
			}
		}
		
		System.out.println("Completed " + simNum + " simulations.");
	}
	
	private static void simAndSave(final HybridAutomaton ha,
			final int xDim, final int yDim,
			final double stepSize, final BufferedWriter out,
			final int maxJumps, final int totalSims,
			final String mode, HyperPoint startPoint)
	{
		ArrayList <HyperPoint> points = simulate(ha, stepSize, mode, startPoint, maxJumps);
		
		points = ComputationResultSaveThread.downSampleSimulation(points);
		
		ComputationResultSaveThread.socketSendSimulationResult(points);
		
		outputSim(xDim, yDim, out, points);
		long curTime = System.currentTimeMillis(); 
		++simNum;
		
		if (curTime >= nextPrintMs)
		{
			int percentDone = 100 * simNum / totalSims;
			
			System.out.println("Completed " + simNum + "/" + totalSims + " simulations (" +
				percentDone + "%).");
			
			nextPrintMs = curTime + PRINT_PERIOD_MS;
		}
	}
	
	/**
	 * Output a simulation to a buffered writer
	 * @param xDim
	 * @param yDim
	 * @param out
	 * @param points
	 */
	private static void outputSim(final int xDim, final int yDim,
			final BufferedWriter out, ArrayList<HyperPoint> points)
	{
		try
		{
			// output result
			for (HyperPoint p : points)
			{
				if (p == null)
					out.write("\n");
				else
				{
					double x = p.dims[xDim];
					double y = p.dims[yDim];
					
					out.write(x + " " + y + "\n");
				}
			}
		
			out.write("\n"); // end simulation
		}
		catch (IOException e) {} // silently ignore i/o errors
	}

	/**
	 * Extract the simulation transition types desired based on the automaton and settings
	 * @param ha
	 * @param options
	 * @return
	 */
	private static TransitionType[] getTransitionTypes(HybridAutomaton ha, ReachParams options)
	{
		TransitionType[] rv;
		ArrayList<AutomatonMode> modes = ha.getModes();
		
		if (modes.size() == 0)
			throw new RuntimeException("Automaton needs to have at least one discrete mode.");
		else if (modes.size() == 1 && modes.get(0).successors.size() == 0) // nothing to enumerate
			rv = new TransitionType[]{TransitionType.LATEST};
		else if (options.enumerateTransitions)
			rv = new TransitionType[]{TransitionType.EARLIEST, TransitionType.LATEST};
		else
			rv = new TransitionType[]{TransitionType.LATEST};
		
		return rv;
	}


	/**
	 * Get the number of simulation start points
	 * @param init the initial set
	 * @param options the simulation options
	 * @return the number of start points for the simulations
	 */
	private static int simulationPointsCount(
			TreeMap<String, Collection<HyperRectangle>> init,
			ReachParams options)
	{
		int simSpots = 0;

		// if we're simulating midpoints
		if (options.startingPositions.equals(StartingPositionsType.MIDPOINTS) || 
			options.startingPositions.equals(StartingPositionsType.CORNERS_AND_MIDPOINTS)) 
		{
			for (Collection<HyperRectangle> modeRects : init.values())
				simSpots += modeRects.size();
		}
		
		// if we're simulating corners
		if (options.startingPositions.equals(StartingPositionsType.CORNERS) || 
			options.startingPositions.equals(StartingPositionsType.CORNERS_AND_MIDPOINTS)) 
		{
			for (Entry<String, Collection<HyperRectangle>> entry : init.entrySet())
			{
				Collection<HyperRectangle> rects = entry.getValue();
				
				for (HyperRectangle r : rects)
				{
					int corners = 1;
					
					for (int d = 0; d < r.dims.length; ++d)
					{
						if (!r.dims[d].isPoint())
							corners *= 2;
					}
					
					simSpots += corners;
				}
			}
		}
			
		return simSpots;
	}

	public static double[] estimateBaseSize(ReachParams options, HybridAutomaton ha,
						TreeMap<String, Collection<HyperRectangle>> init, double stepSize)
	{
		Entry<String, Collection<HyperRectangle>> startEntry = init.entrySet().iterator().next();
		HyperPoint startPoint = startEntry.getValue().iterator().next().center();
		
		ArrayList<HyperPoint> pts = simulate(ha,  stepSize,
				startEntry.getKey(), startPoint, options.maxJumps);
		
		int numDims = startPoint.dims.length;
		
		sampleStrategy = new SampleType[numDims];
		
		for (int i = 0; i < numDims; ++i)
			sampleStrategy[i] = SampleType.SAMPLE_RANDOM_EXTREME;
		
		int numSteps = 0;
		HyperPoint last = null;
		double[] stepSum = new double[numDims];
		
		for (HyperPoint p : pts)
		{
			if (last != null && p != null)
			{
				++numSteps;
				
				for (int d = 0; d < numDims; ++d)
					stepSum[d] += Math.abs(last.dims[d] - p.dims[d]);
			}
			
			last = p;
		}
		
		// divide stepSum by numSteps, then multiply by 10 to get estimated base size
		double DEFAULT_BASE_SIZE = 0.1;
		
		if (numSteps == 0)
		{
			for (int d = 0; d < numDims ;++d)
				stepSum[d] = DEFAULT_BASE_SIZE;
		}
		else
		{	
			for (int d = 0; d < numDims ;++d)
				stepSum[d] = (10 * stepSum[d]) / numSteps;
		}
		
		// remove zero entries
		double minNonZero = Double.MAX_VALUE;
		
		for (int d = 0; d < numDims; ++d)
		{
			double val = stepSum[d];
			
			if (val != 0 && val < minNonZero)
				minNonZero = val;
		}
		
		if (minNonZero == Double.MAX_VALUE)
			minNonZero = DEFAULT_BASE_SIZE;
		
		for (int d = 0; d < numDims; ++d)
		{
			if (stepSum[d] == 0)
				stepSum[d] = minNonZero;
		}
		
		return stepSum;
	}
}
