package reachability.fileformat;

import reachability.geometry.HyperRectangle;


/**
 * This class is used to enumerate an HRM file. These files can be quite
 * large (for example, the output of reachability, so it's best not to 
 * load them all in memory at once. Instead use HrmFormat.enumerateFile and
 * this class 
 * @author Stanley Bak
 *
 */
public abstract class HrmEnumerator
{
	public abstract void enumerate(String mode, HyperRectangle rect);
}
