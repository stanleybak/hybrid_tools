package reachability.fileformat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.InterruptedIOException;
import java.io.Writer;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.swing.JFrame;
import javax.swing.ProgressMonitor;
import javax.swing.ProgressMonitorInputStream;

import main.Main;
import reachability.geometry.HyperRectangle;
import reachability.geometry.HyperRectangleTime;
import reachability.geometry.Interval;
import untrusted.UntrustedMain;

/**
 * HyperRectangle + Mode Format
 * 
 * @author Stanley Bak
 *
 */
public class HrmFormat
{
	public static final String INPUT_FILENAME = "input.hrm";
	public static final String OUTPUT_FILENAME = "output.hrm";
	
	public static final char COMMENT_CHAR = '#';
	public static final String DIM_SPLIT_CHAR = ";";
	public static final String INTERVAL_SPLIT_CHAR = ",";
	
	/**
	 * Convert a set of states from mode -> list[HR] to mode -> list[HRT]
	 * This uses shallow copies for the hyper rectangles
	 * @param states the states we're converting
	 * @param timeVal the time to set all of them to
	 * @return the converted states
	 */
	public static TreeMap <String, Collection <HyperRectangleTime> >
		shallowConvertToHrt(TreeMap <String, Collection <HyperRectangle> > states, double timeVal)
	{
		TreeMap <String, Collection <HyperRectangleTime> > rv = 
				new TreeMap <String, Collection <HyperRectangleTime> >();
		
		for (Entry<String, Collection <HyperRectangle>> e : states.entrySet())
		{
			LinkedList <HyperRectangleTime> outputList = new LinkedList <HyperRectangleTime>();
			Collection <HyperRectangle> inputList = e.getValue();
			
			for (HyperRectangle hr : inputList)
				outputList.add(new HyperRectangleTime(hr, timeVal));
			
			rv.put(e.getKey(), outputList);
		}
		
		return rv;
	}

	/**
	 * Check to make sure this is a legal mode name
	 * @param mode
	 */
	private static void checkModeName(String mode)
	{
		if (mode.length() < 1)
			throw new RuntimeException("Mode name in file is blank");
		else if (mode.length() > 256)
			throw new RuntimeException("Mode name in file is too long");
		
		for (int i = 0; i < mode.length(); ++i)
		{
			char c = mode.charAt(i);
			
			if (	(c >= 'a' && c <= 'z') || 
					(c >= 'A' && c <= 'Z') ||
					(c >= '0' && c <= '9') ||
					(c == '-' || c == '_' || c == '(' || c == ')' 
					|| c == '[' || c == ']' || c == ' '))
				continue;
				
			throw new RuntimeException("Mode name uses invalid characters: " + mode);
		}
	}

	/**
	 * Save the passed-in states to a file in the .hrm format
	 * @param path the path to save to
	 * @param states the states to encode
	 * @throws IOException if a file error occurs
	 */
	/*public static void save(String path, TreeMap <String, Collection <HyperRectangle>> states) 
			throws IOException
	{
		BufferedWriter bw = new BufferedWriter(new FileWriter(path));
		addHeaders(bw);
		
		for (Entry<String, Collection<HyperRectangle>> e : states.entrySet())
		{
			String mode = e.getKey();
			
			for (HyperRectangle d : e.getValue())
			{
				bw.write(encodeHr(d) + DIM_SPLIT_CHAR + mode + "\n");
			}
		}
		
		bw.close();
	}*/
	
	public static String getOutputPath(String baseDir, String haName)
	{
		return baseDir + File.separator + haName + File.separator + OUTPUT_FILENAME;
	}
	
	/**
	 * Encode a hyperrectangle into a String for file storage
	 * @param hr rectangle to encode
	 * @return the encoded string
	 */
	public static String encodeHr(HyperRectangle hr)
	{
		String s = "";
		
		for (int d = 0; d < hr.dims.length; ++d)
		{
			if (d != 0)
				s += DIM_SPLIT_CHAR;
			
			Interval i = hr.dims[d];
			
			s += i.min + INTERVAL_SPLIT_CHAR + i.max;
		}
		
		return s;
	}

	public static void addHeaders(Writer w) throws IOException
	{
		w.write("# Output of Reachability Computation\n");
		w.write("# " + getTimeString() + "\n");
		w.write("# Performed by " + Main.TOOL_VERSION + "\n\n");
	}
	
	private static String getTimeString()
	{
		Date date = new Date(System.currentTimeMillis());
		String formattedDate = UntrustedMain.dateFormatter.format(date);
		
		return formattedDate;
	}

	public static void writeRect(Writer w, HyperRectangle hr, String mode) throws IOException
	{
		w.write(encodeHr(hr) + DIM_SPLIT_CHAR + mode + "\n");
	}

	/**
	 * Enumerate an .hrm File, calling enumerator.enumerate() on each rectangle
	 * @param hrmPath the path to the file
	 * @param hrmEnumerator the enumerator object
	 * @param progressMonitorText the text to use for the progressMonitor, or null if we 
	 *                            don't want a progress monitor
	 * @throws IOException if the user presses cancel or a file error occurs
	 */
	public static void enumerateFile(String hrmPath, HrmEnumerator hrmEnumerator, 
			String progressMonitorText) 
			throws IOException
	{
		JFrame parent = null;
		
		if (Main.hcf != null)
			parent = Main.hcf.frame;
		
		ProgressMonitor progress = null;
		InputStream is = new FileInputStream(hrmPath);
		ProgressMonitorInputStream pis = null;
		
		if (progressMonitorText != null)
		{
			pis = new ProgressMonitorInputStream(parent, progressMonitorText, is);
			
			progress = pis.getProgressMonitor();
			is = pis;
		}
		
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		
		try
		{
			for (String line = br.readLine(); line != null; line = br.readLine())
			{
				int commentIndex = line.indexOf(COMMENT_CHAR);
				
				if (commentIndex != -1)
					line = line.substring(0,commentIndex);
				
				line = line.trim();
				
				if (line.length() == 0)
					continue;
				
				String[] parts = line.split(DIM_SPLIT_CHAR);
				
				if (parts.length < 2)
					throw new IOException("parts.length() is too small: " + line);
				
				int numDimensions = parts.length - 1;
				HyperRectangle hr = new HyperRectangle(numDimensions);
				
				for (int d = 0; d < numDimensions; ++d)
				{
					String[] interval = parts[d].split(INTERVAL_SPLIT_CHAR);
					
					if (interval.length != 2)
						throw new IOException("Interval in line does not have two parts: " + line);
					
					double min = 0;
					double max = 0;
					
					try
					{
						min = Double.parseDouble(interval[0].trim());
						max = Double.parseDouble(interval[1].trim());
					}
					catch (NumberFormatException e)
					{
						br.close();
						throw new IOException("Error formatting double: " + e);
					}
					
					if (min > max)
					{
						br.close();
						throw new IOException("Min > Max in dimension#" + d + " on line " + line);
					}
					
					// at this point min and max are defined
					hr.dims[d] = new Interval(min, max);
				}
				
				// at this point hr is defined
				String mode = parts[parts.length - 1].trim();
				checkModeName(mode);
				
				// hr and mode are now constructed
				hrmEnumerator.enumerate(mode, hr);
				
			}
			
			if (progress != null)
				progress.close();
			
			br.close();
		}
		catch (InterruptedIOException e)
		{
			br.close();
			throw new IOException("Operation cancelled by user");
		}
	}
}
