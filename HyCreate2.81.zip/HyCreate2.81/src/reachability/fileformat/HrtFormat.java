package reachability.fileformat;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.LinkedList;

import reachability.geometry.HyperRectangle;
import reachability.geometry.Interval;

/**
 * HyperRectangle + Time Format. all hyperrectangles passed around here have an extra time dimension. The format
 * in the file has only one entry in the last (time) dimension, with two entries (a range) for everything else
 * 
 * @author Stanley Bak
 *
 */
public class HrtFormat
{
	public static final String INPUT_FILENAME = "input.hrt";
	
	public static final char COMMENT_CHAR = HrmFormat.COMMENT_CHAR;
	public static final String DIM_SPLIT_CHAR = HrmFormat.DIM_SPLIT_CHAR;
	public static final String INTERVAL_SPLIT_CHAR = HrmFormat.INTERVAL_SPLIT_CHAR;
	
	/**
	 * appends to a .hrt file. This one assumes appending will start on a new line rather
	 * than at the end of the previous line
	 * @param rects
	 * @param path
	 * @throws IOException
	 */
	public static void append(Collection <HyperRectangle> rects, String path) 
			throws IOException
	{
		new File(path).getParentFile().mkdirs();
		
		if (!new File(path).getParentFile().exists())
			throw new IOException("Error creating directories: " + path);
		
		BufferedWriter bw = new BufferedWriter(new FileWriter(path, true));
		
		for (HyperRectangle hr : rects)
			bw.write(encodeHrt(hr) + "\n");
		
		bw.close();
	}

	/**
	 * Encode a hyperrectangle+t into a String for file storage
	 * @param hr
	 * @return
	 */
	public static String encodeHrt(HyperRectangle hr)
	{
		String s = "";
		
		if (hr.dims.length < 2)
			throw new RuntimeException("encodeHrt called but hr's dimensions are less than 2!");
		
		if (hr.dims[hr.dims.length - 1].min != hr.dims[hr.dims.length - 1].max)
			throw new RuntimeException("encodeHrt called but hr's time dimension is not constant");
		
		for (int d = 0; d < hr.dims.length - 1; ++d)
		{
			if (d != 0)
				s += DIM_SPLIT_CHAR;
			
			Interval i = hr.dims[d];
			
			s += i.min + INTERVAL_SPLIT_CHAR + i.max;
		}
		
		// append time dimension
		s += DIM_SPLIT_CHAR;
		s += hr.dims[hr.dims.length - 1].max;
		
		return s;
	}
	
	/**
	 * Clear a file.
	 * @param path
	 * @throws IOException
	 */
	public static void clear(String path) throws IOException
	{
		FileWriter fw = new FileWriter(path);
		fw.close();
	}

	public static Collection <HyperRectangle> load(String path) throws IOException
	{
		LinkedList<HyperRectangle> rv = new LinkedList<HyperRectangle>(); // accumulator variable
		
		if (new File(path).exists())
		{
			BufferedReader br = new BufferedReader(new FileReader(path));
			
			int prevNumDims = -1;
			
			for (String line = br.readLine(); line != null; line = br.readLine())
			{
				int commentIndex = line.indexOf(COMMENT_CHAR);
				
				if (commentIndex != -1)
					line = line.substring(0,commentIndex);
				
				line = line.trim();
				
				if (line.length() == 0)
					continue;
				
				String[] parts = line.split(DIM_SPLIT_CHAR);
				
				int numDimensions = parts.length;
				
				if (prevNumDims == -1)
					prevNumDims = numDimensions;
				
				if (prevNumDims != numDimensions)
				{
					br.close();
					
					throw new IOException("Mismatch in number of dimensions in HrtFormat.load(): " 
								+ line);
				}
				else if (numDimensions == 0)
				{
					br.close();
					throw new IOException("Number of dimensions is zero in a hyperrectangle: " 
							+ line);
				}
				HyperRectangle hr = new HyperRectangle(numDimensions);
				
				for (int d = 0; d < numDimensions - 1; ++d)
				{
					String[] interval = parts[d].split(INTERVAL_SPLIT_CHAR);
					
					if (interval.length != 2)
					{
						br.close();
						throw new IOException("Interval in line does not have two parts: " + line);
					}
					
					double min = 0;
					double max = 0;
					
					try
					{
						min = Double.parseDouble(interval[0].trim());
						max = Double.parseDouble(interval[1].trim());
					}
					catch (NumberFormatException e)
					{
						br.close();
						throw new IOException("Error formatting double: " + e);
					}
					
					if (min > max)
					{
						br.close();
						throw new IOException("Min > Max in dimension#" + d + " on line " + line);
					}
					
					// at this point min and max are defined
					hr.dims[d] = new Interval(min, max);
				}
				
				// last dimension is time dimension
				int timeDim = numDimensions - 1;
				double time = 0;
				
				try
				{
					time = Double.parseDouble(parts[timeDim].trim());
				}
				catch (NumberFormatException e)
				{
					br.close();
					throw new IOException("Error formatting double (time): " + e);
				}
				
				if (time < 0)
				{
					br.close();
					throw new IOException("Time < 0 on line " + line);
				}
				
				// at this point min and max are defined
				hr.dims[timeDim] = new Interval(time, time);
				
				// at this point hr is fully defined
				rv.add(hr);
			}
			
			br.close();
		}
		
		return rv;
	}

}
