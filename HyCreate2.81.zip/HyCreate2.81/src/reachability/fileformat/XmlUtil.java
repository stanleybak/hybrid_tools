package reachability.fileformat;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import main.Main;

/**
 * Utilities for XML Encoding / Decoding of Java Beans
 * @author Stanley Bak (sbak2@illinois.edu)
 *
 */
public class XmlUtil
{

	public static void saveObjectQuitOnError(Object bean, String dir, String filename)
	{
		try
		{
			File f = new File(dir);
			f.mkdirs();
			
			XMLEncoder e = new XMLEncoder(
				    new BufferedOutputStream(
				        new FileOutputStream(dir + File.separator + filename)));
			e.writeObject(bean);
			e.close();
		}
		catch (Exception e)
		{
			
			String text = "Exception while saving XML Bean: " + e + "\nquitting...";
			e.printStackTrace();
			
			Main.error(text);
			System.exit(-1);
		}
	}
	
	public static Object loadObjectQuitOnError(String dir, String filename)
	{
		String path = dir + File.separator + filename;
		Object rv = null;
		
		try
		{
			XMLDecoder d = new XMLDecoder(
				    new BufferedInputStream(
				        new FileInputStream(path)));
			rv = d.readObject();
			d.close();
		}
		catch (Exception e)
		{
			String text = "Exception while loading XML Bean: " + e + "\nquitting...";
			e.printStackTrace();
			
			Main.error(text);
			System.exit(-1);
		}
		
		return rv;
	}

}
