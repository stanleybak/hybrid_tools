package reachability.geometry;

public abstract class BooleanArrayIterator
{
	public abstract void iterate(boolean[] entry);
}
