package reachability.geometry;

public abstract class HyperRectangleCornerEnumerator
{
	public abstract void enumerate(HyperPoint p);
}
