package reachability.geometry;

/**
 * A Hyperrectangle, combined with a time for each face. The "time" of the
 * parent hyperrectangleTime is the minimum time among all the faces
 * @author sbak
 *
 */
public class HyperRectangleFaceTime extends HyperRectangleTime
{
	// index = dimention * 2 + (isMin ? 0 : 1)
	private double[] faceTimes;
	
	/**
	 * Shallow copies the parameters
	 * @param hr the rectangle
	 * @param time the time of all the faces
	 */
	public HyperRectangleFaceTime(HyperRectangle hr, double time)
	{
		super(hr, time);
		
		faceTimes = new double[hr.dims.length * 2];
		
		for (int x = 0; x < faceTimes.length; ++x)
			faceTimes[x] = time;
	}
	
	/**
	 * Deep copies the parameters
	 * @param other the object to deep copy
	 */
	public HyperRectangleFaceTime(HyperRectangleTime other)
	{
		super(other);
		
		if (other instanceof HyperRectangleFaceTime)
		{
			faceTimes = new double[other.rect.dims.length * 2];
			
			for (int x = 0; x < faceTimes.length; ++x)
				faceTimes[x] = ((HyperRectangleFaceTime) other).faceTimes[x];
		}
		else
		{
			faceTimes = new double[other.rect.dims.length * 2];
			
			for (int x = 0; x < faceTimes.length; ++x)
				faceTimes[x] = other.getTime();
		}
	}

	public double getFaceTime(int dim, boolean minFace)
	{
		return faceTimes[2 * dim + (minFace ? 0 : 1)];
	}

	public void setFaceTime(int dim, boolean minFace, double val)
	{
		faceTimes[2 * dim + (minFace ? 0 : 1)] = val;
	}
	
	@Override
	public double getTime()
	{
		double min = Double.MAX_VALUE;
		
		for (double t : faceTimes)
		{
			if (t < min)
				min = t;
		}
		
		return min;
	}
	
	@Override
	public void assign(HyperRectangleTime other)
	{
		HyperRectangleFaceTime r = (HyperRectangleFaceTime)other; 
		
		rect.assign(r.rect);
		
		for (int x = 0; x < faceTimes.length; ++x)
			faceTimes[x] = r.faceTimes[x];
	}
	
	@Override
	public String toString()
	{
		String rv = "[" + rect + " @ facetimes = ";
		
		for (double t : faceTimes)
			rv += t + " ";
		
		rv += "]";
		
		return rv;
	}
}
