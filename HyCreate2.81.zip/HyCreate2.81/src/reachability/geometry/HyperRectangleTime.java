package reachability.geometry;

import java.util.Collection;
import java.util.LinkedList;

public class HyperRectangleTime
{
	private double time;
	public HyperRectangle rect;
	
	/**
	 * Regular constructor, makes a shallow copy
	 * @param hr the rectangle
	 * @param time the time
	 */
	public HyperRectangleTime(HyperRectangle hr, double time)
	{
		this.rect = hr;
		this.time = time;
	}

	/**
	 * Copy constructor, makes a deep copy
	 * @param r the one we're copying
	 */
	public HyperRectangleTime(HyperRectangleTime r)
	{
		rect = new HyperRectangle(r.rect);
		time = r.time;
	}

	/**
	 * Strip the time value from this HRT collection. Uses shallow copy.
	 * @param set the original set
	 * @return the set with the time stripped
	 */
	public static Collection<HyperRectangle> shallowStripTime(Collection<HyperRectangleTime> set)
	{
		Collection<HyperRectangle> rv = new LinkedList<HyperRectangle>();
		
		for (HyperRectangleTime hrt : set)
		{
			rv.add(hrt.rect);
		}
		
		return rv;
	}
	
	public String toString()
	{
		return "[" + rect + " @ time = " + time + "]";
	}

	public void assign(HyperRectangleTime r)
	{
		time = r.time;
		rect.assign(r.rect);
	}
	
	public double getTime()
	{
		return time;
	}
	
	public void setTime(double t)
	{
		time = t;
	}
	
	/**
	 * Get the convex hull of two rectangles. The time will be the minimum.
	 * @param left one rectangle
	 * @param right the other rectangle
	 * @return a new hyperRectangleTime which is the convex hull of the two, time is min of two
	 */
	public static HyperRectangleTime convexHull(HyperRectangleTime left, HyperRectangleTime right)
	{
		HyperRectangle hullRect = HyperRectangle.convexHull(left.rect, right.rect);
		double minTime = Math.min(left.time, right.time);
		
		return new HyperRectangleTime(hullRect, minTime);
	}
}
