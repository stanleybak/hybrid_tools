package reachability.geometry;

public class Interval
{
	public double min = 0, max = 0;
	
	public Interval()
	{
		
	}
	
	public Interval(double val)
	{
		min = max = val;
	}
	
	public Interval(double min, double max)
	{
		this.min = min;
		this.max = max;
	}
	
	/**
	 * Deep copy from another interval
	 * @param i the interval to copy from
	 */
	public Interval(Interval i)
	{
		min = i.min;
		max = i.max;
	}
	
	/**
	 * Expand the interval to include this value
	 * @param pt the value to include
	 */
	public void expand(double pt)
	{
		if (pt > max)
			max = pt;
		
		if (pt < min)
			min = pt;
	}
	
	public void times(double a)
	{
		if (a > 0)
		{
			min *= a;
			max *= a;
		}
		else
		{
			double temp = max;
			max = min * a;
			min = temp * a;
		}
		
		validate();
	}
	
	public void plus(Interval rhs)
	{
		min += rhs.min;
		max += rhs.max;
		
		validate();
	}
	
	/**
	 * Does this interval contain a certain values. This does not count the endpoints as part of 
	 * the interval.
	 * @param d the value to check
	 * @return true iff min < d < max
	 */
	public boolean containsExclusive(double d)
	{
		return min < d && d < max; 
	}
	
	/**
	 * Does this interval contain a certain value? This includes the endpoints as part of the interval.
	 * @param d the value to check
	 * @return true iff min < d < max
	 */
	public boolean contains(double d)
	{
		return min <= d && d <= max; 
	}
	
	@Override
	public String toString()
	{
		return "[Interval: (" + min + ", " + max + ")]";
	}

	/**
	 * get the middle of this interval
	 * @return the average of the two endpoints
	 */
	public double middle()
	{
		return (max + min) / 2.0;
	}
	
	public double width()
	{
		return max - min;
	}
	
	public boolean isPoint()
	{
		boolean rv = false;
		double TOL = 0.0000000001;
		
		if (max >= min && max - min < TOL)
			rv = true;
		
		return rv;
	}

	public boolean isExactly(double val)
	{
		return this.max == val && this.min == val;
	}
	
	public void set(double min, double max)
	{
		this.min = min;
		this.max = max;
	}

	/**
	 * Set the interval to a constant
	 * @param value the value to set both min and max to
	 */
	public void set(double value)
	{
		set(value, value);
	}

	/**
	 * Trim an interval to be restricted to the trimming interval
	 * @param trimmingInterval the interval to trim to
	 * @throws RuntimeException if the intervals are nonoverlapping
	 */
	public void trim(Interval trimmingInterval)
	{
		if (min > trimmingInterval.max || max < trimmingInterval.min)
			throw new RuntimeException("Trim called with nonoverlapping interval: " + this 
					+ " trimmed to " + trimmingInterval);
		
		if (min < trimmingInterval.min)
			min = trimmingInterval.min;
		
		if (max > trimmingInterval.max)
			max = trimmingInterval.max;
	}
	
	/**
	 * Make sure this is a valid interval. Throw runtimeException if not.
	 */
	public void validate()
	{
		if (min > max)
			throw new RuntimeException("Invalid Interval: " + this);
	}

	/**
	 * Compute the intersection of two intervals, returns null if empty
	 * @param other the other interval we're intersecting with
	 * @return the overlap, or null if they are disjoint
	 */
	public Interval intersection(Interval other)
	{
		Interval rv = new Interval();
		
		rv.min = Math.max(other.min, min);
		rv.max = Math.min(other.max, max);
		
		if (rv.max < rv.min)
			rv = null;
		
		return rv;
	}

	public boolean contains(Interval inside)
	{
		return min <= inside.min && max >= inside.max;
	}

}
