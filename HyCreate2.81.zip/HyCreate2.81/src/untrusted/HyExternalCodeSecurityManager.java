package untrusted;

import java.io.File;
import java.io.FilePermission;
import java.io.IOException;
import java.security.Permission;
import java.util.PropertyPermission;

import sun.net.InetAddressCachePolicy;

/**
 * A security manager used to run external, untrusted code. This code will
 * execute in its own JVM, and will enable this security manager before any untrusted
 * code is loaded.
 * 
 * The security manager allows for .class and .jar files to be read
 * from hyCreateDirPath, as well as read operations of any files from
 * tempDirPath. Finally, write operations are permitted only to
 * resultPath, or files in resultPath's directory which
 * end in ".txt", or files in resultPath/partial/ which end in 
 * ".txt"
 * 
 * Additionally, code may call System.exit();
 *  
 * @author Stanley Bak
 *
 */
public class HyExternalCodeSecurityManager extends SecurityManager
{
	private String tempDirPath; 
	private String hyCreateDirPath;
	private String resultPath;
	private String resultDirectory;
			
	/**
	 * Create a new restrictive security manager. 
	 * @param tempDirPath path where any files can be read
	 * @param hyCreateDirPath path where .class and .jar files can be read
	 * @param resultPath path that can be written
	 */
	public HyExternalCodeSecurityManager(String tempDirPath, String hyCreateDirPath,
			String resultPath, int visualizerPort)
	{
		super();
		
		this.tempDirPath = tempDirPath;
		this.hyCreateDirPath = hyCreateDirPath;
		
		try
		{
			this.resultPath = new File(resultPath).getCanonicalPath();
			
			this.resultDirectory = new File(this.resultPath).getParent();
		}
		catch (IOException e)
		{
			// error creating canonical path
			throw new RuntimeException("Exception creating resultPath: " + e);
		}
		
		// hack for bug listed at: http://bugs.sun.com/bugdatabase/view_bug.do;jsessionid=22699f012b6032c18d46d70d915a?bug_id=6513865
		InetAddressCachePolicy.get();
	}
	
	@Override
    public void checkPermission(Permission perm) 
    {
		boolean allowed = false;
		
		if (perm instanceof FilePermission && perm.getActions().equals("read"))
		{
			// all files in tempDirPath can be read, all .class and .jar files in 
			// hyCreateDirPath can be read
			
			try
			{
				String name = new File(perm.getName()).getCanonicalPath();
				
				if (name.startsWith(tempDirPath))
					allowed = true;
				else if (name.startsWith(resultDirectory)) 
					allowed = true; // windows reads before writes
				else if ((name.endsWith(".class") || name.endsWith(".jar")) 
						&& name.startsWith(hyCreateDirPath))
					allowed = true;
			}
			catch (IOException e)
			{
				// error creating canonical path, don't allow
			}
		}
		else if (perm instanceof FilePermission && perm.getActions().equals("write"))
		{
			// only allow writes to resultPath that end in .txt
			
			try
			{
				String name = new File(perm.getName()).getCanonicalPath();
				
				if (resultPath != null && name.equals(resultPath))
					allowed = true;
				else if (name.endsWith(".txt"))
				{
					// check if it's a write to resultDir
					File f = new File(name);
					
					String parentDir = f.getParent();
					
					if (resultDirectory.equals(parentDir))
						allowed = true;
				}
			}
			catch (IOException e)
			{
				// error creating canonical path, don't allow
			}
		}
		else if (perm instanceof PropertyPermission && perm.getActions().equals("read"))
		{
			// allow reading of some properties
			String[] allowedPermissions = 
			{
				"line.separator",
			};
			
			for (String name : allowedPermissions)
			{
				if (name.equals(perm.getName()))
				{
					allowed = true;
					break;
				}
			}
		}
		else if (perm instanceof RuntimePermission && perm.getName().startsWith("exitVM"))
			allowed = true; // exiting is allowed
		else if (perm instanceof RuntimePermission && perm.getName().startsWith("closeClassLoader"))
			allowed = true; // closing class loader is allowed
		
		if (!allowed)
			throw new SecurityException("Permission disabled from external code for security: " 
						+ perm);
    }

	@Override
    public void checkPermission(Permission perm, Object context) 
    {
    	checkPermission(perm);
    }
	
	// the checkAccess methods are overridden to allow a SIGTERM signal handler to close the program
	public void checkAccess(ThreadGroup g) 
	{
		if (!("system".equals(g.getName())))  
			super.checkAccess(g); // will reject
	}

	// the checkAccess methods are overridden to allow a SIGTERM signal handler to close the program
	public void checkAccess(Thread t) 
	{
		if (!("SIGTERM handler".equals(t.getName()))) 
			super.checkAccess(t); // will reject
	}
}
