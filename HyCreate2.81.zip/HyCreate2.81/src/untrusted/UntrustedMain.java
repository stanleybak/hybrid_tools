package untrusted;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.TreeMap;

import com.stanleybak.hycreate.containers.ReachParams;
import com.stanleybak.hycreate.containers.ModelSimulationOptions.SimulationType;

import main.Util;

import reachability.automaton.AutomatonMode;
import reachability.automaton.HybridAutomaton;
import reachability.compute.ComputationResultSaveThread;
import reachability.compute.Simulator;
import reachability.fileformat.HrmFormat;
import reachability.geometry.HyperRectangle;
import reachability.geometry.HyperRectangleTime;
import reachability.geometry.Interval;

public class UntrustedMain
{
	public static final String RESULT_FILENAME = "reachability_result.hrm";
	public static DateFormat dateFormatter = new SimpleDateFormat("MMMMM d, yyyy hh:mm:ss a");
	
	/**
	 * The (almost) main entry point when a new JVM is spawned to run external code
	 * @param compileBaseDir the temporary directory where the untrusted code resides
	 * @param hyCreateDirPath the directory where the original HyCreate code resides
	 * @param resultFilePath the path where we should output reachability
	 * @param paramString the reach parameters, produced by ReachParams.createParamString()
	 */
	public static void begin(String compileBaseDir, String hyCreateDirPath, String resultFilePath,
			String paramString)
	{
		System.out.println("External JVM spawned");
		
		ReachParams params = new ReachParams(paramString);
		
		if (!runReachabilityCode(compileBaseDir, hyCreateDirPath, resultFilePath, params))
			System.exit(1);
		
		System.exit(0);
	}

	/**
	 * Run the external, untrusted code which performs the reachability computation
	 * @param compileBaseDir the temporary directory where the untrusted code resides
	 * @param hyCreateDirPath the directory where the original HyCreate code resides
	 * @param resultFilePath the path where we should output reachability
	 * @param params the reachability parameters (use sandbox / check min/max errors / ect.)
	 * @return true iff no exceptions occurred during the computation
	 */
	private static boolean runReachabilityCode(String compileBaseDir, String hyCreateDirPath, 
			String resultFilePath, ReachParams params)
	{
		boolean noErrors = true;
		Exception traceException = null;
		String computationErrorMsg = null;
		
		URL[] urls;
		URLClassLoader cl = null;
		
		try
		{
			urls = new URL[]{new File(compileBaseDir).toURI().toURL()};
			
			cl = new URLClassLoader(urls);
		}
		catch (MalformedURLException e)
		{
			traceException = e;
			cl = null; // another exception will be raised below, but that's ok
		}
		
		// Start a saving thread, which will write the result to disk as the 
		// computation occurs
		ComputationResultSaveThread.startThread(resultFilePath, params);
		
		// open the port before restricting the security
		if (params.visualizerPort != 0)
    		ComputationResultSaveThread.setVisualizePort(params.visualizerPort);
		
		if (params.useSandbox)
		{
			// start restrictive security manager before running external code
			
			HyExternalCodeSecurityManager rsm = 
					new HyExternalCodeSecurityManager(compileBaseDir, hyCreateDirPath, 
							resultFilePath, params.visualizerPort);
			
			System.setSecurityManager(rsm);
			System.out.println("Successfully started external code sandbox");
		}
		else
			System.out.println("NOT using external code sandbox (don't run with untrusted model files)");
		
		try 
		{
		    Class <?> loadedClass = cl.loadClass("automaton.Automaton");
		    
		    Object obj = loadedClass.getConstructor().newInstance();
		    
	    	HybridAutomaton ha = (HybridAutomaton)obj;
	    	
	    	ha.setReachParams(params);
	    	ha.setUsePseudoInvariant(params.usePseudoInvariant);
	    	
	    	ComputationResultSaveThread.setAutomaton(ha, params);
	    	
	    	// Create blank initial results (overwrites old ones)
	    	TreeMap <String, Collection <HyperRectangle> > initRects = 
	    			parseInitialStates(ha);
	    	
	    	TreeMap <String, Collection <HyperRectangleTime> > init = 
	    			HrmFormat.shallowConvertToHrt(initRects, 0);
	    	
	    	double reachTimeStep = ha.getTimeStep();
	    	double simTimeStep = getStepSize(params, reachTimeStep);

	    	if (params.saveVisualization)
	    	{
		    	double[] range = getPlotRange(params, ha, initRects, simTimeStep, params.maxJumps, params.bloatFactor);
		    	
		    	ComputationResultSaveThread.setVisualizationRanges(
		    			new double[]{range[0], range[1]}, new double[]{range[2], range[3]});
	    	}
	    	
	    	if (params.simulationType != SimulationType.REACHABILITY_ONLY)
	    	{
	    		// run simulation
	    		
	    		String outputDir = new File(resultFilePath).getAbsoluteFile().getParent();
	    		Simulator.run(params, ha, initRects, 
	    				params.visualizeXDim, params.visualizeYDim, simTimeStep, outputDir);
	    	}
	    	
	    	if (params.simulationType != SimulationType.SIMULATION_ONLY)
	    	{
	    		double[] baseSize = Simulator.estimateBaseSize(params, ha, initRects, simTimeStep);
	    		
	    		ha.setBaseSize(baseSize);
	    			
	    		System.out.println("Estimated base grid size from simulation: " + 
	    							Util.doubleArrayString(baseSize));
	    		
	    		computationErrorMsg = ha.compute(compileBaseDir, init);
    		}
		} 
		catch (Exception e)
		{
			// since code is external, it may contain any type of exception, catch them all (like pokemon)
			if (traceException == null)
				traceException = e;
		}
		
		if (traceException != null)
		{
			noErrors = false;
			System.out.println("ERROR: Exception during execution\n" + traceException.toString());
			
			System.out.println("Stack Trace: ");
			
			for (StackTraceElement s : traceException.getStackTrace())
				System.out.println(s.toString());
			
			System.out.println();
			
		}
		else if (computationErrorMsg != null)
		{
			noErrors = false;
    		System.out.println("ERROR: " + computationErrorMsg);
		}
		
		if (noErrors)
		{
			if (ComputationResultSaveThread.hadErrors())
			{
				noErrors = false;
				System.out.println("ERROR occured while saving reachability result.");
			}
		}
		
		ComputationResultSaveThread.closeVisualizeSocket();
		ComputationResultSaveThread.stopThread();
		
		if (cl != null)
		{
			try
			{
				cl.close();
			} 
			catch (IOException e)
			{
				System.out.println("Error closing class loader: " + e);
				noErrors = false;
			}
		}
		
		return noErrors;
	}

	/**
	 * Extract the initial states, checking for errors
	 * @param ha the hybrid automaton we are extracting from
	 * @return the set of initial states
	 */
	private static TreeMap<String, Collection<HyperRectangle>> parseInitialStates(
			HybridAutomaton ha)
	{
		TreeMap<String, Collection<HyperRectangle>> rv = 
				new TreeMap<String, Collection<HyperRectangle>>();
		
		BufferedReader in = new BufferedReader(new StringReader( ha.getInitialStateString()));
		
		try
		{
			ArrayList<AutomatonMode> modes = ha.getModes();
			int numDims = ha.getDimensions();
			
			for (String line = in.readLine(); line != null; line = in.readLine())
			{
				HyperRectangle hr = new HyperRectangle(numDims);
				
				// parse the line, guaranteed no blanks or comments
				String[] parts = line.split(";");
				
				if (parts.length != numDims + 1)
				{
					String msg = "Initial hyperrectangles should have one entry for each dimension " +
							"and one entry for the initial discrete mode.\n" + 
							"Expected " + numDims + " entries, but found " + parts.length + 
							" entries on line:\n" + line;
					
					System.out.println("ERROR: " + msg);
					throw new RuntimeException("Error parsing initial states");
				}
				
				for (int i = 0; i < numDims; ++i)
				{
					String[] range = parts[i].split(",");
					
					if (range.length != 2)
					{
						String msg = 
						"In the initial states, each dimension should be an interval (\"min,max\").\n" + 
						"Problem with entry \"" + parts[i].trim() + "\" on line:\n" + line;
						
						System.out.println("ERROR: " + msg);
						throw new RuntimeException("Error parsing initial states");
					}
					
					try
					{
						double min = Double.parseDouble(range[0].trim());
						double max = Double.parseDouble(range[1].trim());
						
						if (max < min)
						{
							String msg = 
								"In the initial states, max < min for dimension #" + i + 
								".\nProblem with entry \"" + parts[i].trim() + 
								"\" on line:\n" + line;
							
							System.out.println("ERROR: " + msg);
							throw new RuntimeException("Error parsing initial states");
						}
						
						hr.dims[i] = new Interval(min, max);
					}
					catch (NumberFormatException e)
					{
						String msg = 
						"In the initial states, each dimension should be a numeric " +
						"interval (\"min,max\").\nProblem with entry \"" + parts[i].trim() + 
						"\" on line:\n" + line;
						
						System.out.println("ERROR: " + msg);
						throw new RuntimeException("Error parsing initial states");
					}
				}
				
				// check if mode exists
				boolean found = false;
				String modeName = parts[numDims].trim();
				
				for (AutomatonMode am : modes)
				{
					if (am.getName().equals(modeName))
					{
						found = true;
						break;
					}
				}
				
				if (!found)
				{
					String msg = 
					"In the initial states, the mode entry must match a mode's name exactly.\n" + 
					"Problem with entry \"" + modeName + "\" on line:\n" + line;
					
					System.out.println("ERROR: " + msg);
					throw new RuntimeException("Error parsing initial states");
				}
				
				// ok add it to rv
				Collection <HyperRectangle> set = rv.get(modeName);
				
				if (set == null)
				{
					set = new LinkedList<HyperRectangle>();
					rv.put(modeName, set);
				}
				
				set.add(hr);
			}
			
			in.close();
		}
		catch (IOException e)
		{
			throw new RuntimeException(e);
		}
		
		return rv;
	}

	private static double[] getPlotRange(ReachParams params,
			HybridAutomaton ha,
			TreeMap<String, Collection<HyperRectangle>> init,
			double stepSize, int maxJumps, double bloatFactor)
	{
		double[] range = params.getPlotRange();
		
		if (range == null)
		{
			System.out.println("Performing simulation to determine plot range.");
			
			range = Simulator.getScaledSimulationRange(ha, bloatFactor, init, 
					params.visualizeXDim, params.visualizeYDim, stepSize, maxJumps);
			System.out.println("Determined plot range: " + range[0] + "," + range[1] + "   ;   " +
					range[2] + "," + range[3] + "");
		}
		return range;
	}

	private static double getStepSize(ReachParams params, double reachTimeStep)
	{
		double stepSize = -1;
		
		try
		{
			stepSize = Double.parseDouble(params.simulationStep);
		}
		catch (NumberFormatException e)
		{
			stepSize = reachTimeStep;
		}
		return stepSize;
	}
}
