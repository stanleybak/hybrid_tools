// Stanley Bak
// GLPK unit test functions

#ifndef HYLAA_GLPK_TESTS_H_
#define HYLAA_GLPK_TESTS_H_

void hylaa_glpk_unit_test();

#endif
